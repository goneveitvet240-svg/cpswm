def test_live(value):
 assert value == 9
