mkdir -p /Users/pangwei/Documents/ai/continual-personalized-semantic-world-model/output/ci-failure-artifacts-20260930/collection-shell-probe/success/artifacts
git rev-parse HEAD > /Users/pangwei/Documents/ai/continual-personalized-semantic-world-model/output/ci-failure-artifacts-20260930/collection-shell-probe/success/artifacts/source-sha.txt
set +e
/private/tmp/cpswm-pc-a-ci-failure-artifacts-20260930/.venv/bin/python -c 'import sys;print("controlled collection stdout");sys.exit(0)' 2>&1 | tee /Users/pangwei/Documents/ai/continual-personalized-semantic-world-model/output/ci-failure-artifacts-20260930/collection-shell-probe/success/artifacts/collection.log
results=("${PIPESTATUS[@]}")
result=${results[0]}
if [[ "$result" -eq 0 && "${results[1]}" -ne 0 ]]; then
  result=${results[1]}
fi
printf '%s\n' "$result" > /Users/pangwei/Documents/ai/continual-personalized-semantic-world-model/output/ci-failure-artifacts-20260930/collection-shell-probe/success/artifacts/collection-exit-code.txt
exit "$result"
