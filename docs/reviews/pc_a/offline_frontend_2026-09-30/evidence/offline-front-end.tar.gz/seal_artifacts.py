from pathlib import Path
import gzip
import hashlib
import json
import stat
import tarfile

root = Path('/Users/pangwei/Documents/ai/continual-personalized-semantic-world-model/output/offline-front-end-20260930')
dest = Path('/private/tmp/cpswm-pc-a-offline-front-end-20260930/docs/reviews/pc_a/offline_frontend_2026-09-30/evidence')
dest.mkdir(parents=True, exist_ok=True)
rows, exclusions = [], []
for path in sorted(root.rglob('*')):
    mode = path.lstat().st_mode
    if stat.S_ISDIR(mode):
        continue
    relative = path.relative_to(root).as_posix()
    assert stat.S_ISREG(mode), relative
    data = path.read_bytes()
    row = {'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    if any(p in ('__pycache__', '.pytest_cache') for p in path.relative_to(root).parts) or path.suffix == '.pyc':
        exclusions.append({**row, 'reason': 'derived Python cache only'})
    else:
        rows.append(row)
archive = dest / 'offline-front-end.tar.gz'
assert not archive.exists()
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for row in rows:
                path = root / row['path']
                info = tar.gettarinfo(str(path), arcname=row['path'])
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                info.mode = 0o644
                with path.open('rb') as stream:
                    tar.addfile(info, stream)
with tarfile.open(archive, 'r:gz') as tar:
    assert [m.name for m in tar.getmembers()] == [r['path'] for r in rows]
    for row in rows:
        data = tar.extractfile(row['path']).read()
        assert len(data) == row['bytes']
        assert hashlib.sha256(data).hexdigest() == row['sha256']
        assert hashlib.sha256((root / row['path']).read_bytes()).hexdigest() == row['sha256']
metadata = {
    'actual_source_sha': '3babc6d1557b4fe54abc6c8ac1f6054cdeb03e57',
    'input_collection_inventory_sha256': '9791a946543b9158890324d3ff35a80ea04d51c9cabb6e09540f569abd903d47',
    'files': len(rows), 'raw_bytes': sum(r['bytes'] for r in rows),
    'archive': archive.name, 'compressed_bytes': archive.stat().st_size,
    'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'all_members_readback_verified': True, 'originals_unchanged_after_readback': True,
    'excluded_derived_files': exclusions, 'independent_custody': False,
}
assert archive.stat().st_size < 100_000_000, 'split archive before GitHub delivery'
(dest / 'inventory.json').write_text(json.dumps(rows, indent=2) + '\n')
(dest / 'archive.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2))
