def test_version():
 import cpswm
 assert cpswm.__version__ == '9.9.9'
