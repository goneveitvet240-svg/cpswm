"""Configured joint proposal production at the continuous collection boundary.

The dependency receives detached live evidence/ancestry, never a mutable core.
It must supply its selected full-axis kernel and calibrated conditional models.
No default priors, marginal products, neural weights or semantic truth are made
up here. Its declared artifact identity is not independent trust or calibration.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from hashlib import sha256
from typing import TYPE_CHECKING, Any, Protocol
from uuid import UUID

from cpswm.perception_mapping.adapters.rgbd_capture import RawModalityObservation
from cpswm.system.evaluation_operations.structure_two_selected_method import (
    ParticleRevisionBatch,
    ParticleRevisionReceipt,
)
from cpswm.system.structure_two_particle_workspace import (
    ConditionalAnalyticState,
    NativeParticleRecord,
    NativePosteriorSource,
    NativePreviousWeightEvidence,
    native_content_sha256,
)

if TYPE_CHECKING:
    from cpswm.system.native_visual_source import NativeVisualSource


@dataclass(frozen=True)
class NativeObservationUpdate:
    """Original owner acceptance, stable across recomputation generations."""

    logical_key: str
    action_id: UUID
    semantic_revision_id: UUID
    issued_source_id: UUID
    issued_source_body_sha256: str
    original_runtime_id: UUID
    original_parent_cluster: UUID
    original_parent_sha256: str
    command_sha256: str
    delivery_sha256: str
    packet: dict[str, Any]
    decision_time: datetime
    received_at: datetime
    reference: NativeObservationUpdate | None = None


@dataclass(frozen=True)
class NativeJointContext:
    source: NativePosteriorSource
    previous_batch: ParticleRevisionBatch | None
    records: tuple[NativeParticleRecord, ...]
    ledger_head_sha256: str
    visible_prefix: tuple[RawModalityObservation, ...]
    cutoff: datetime
    visual_source: NativeVisualSource | None = None
    previous_weight_evidence: NativePreviousWeightEvidence | None = None
    observation_update: NativeObservationUpdate | None = None

    @property
    def content_sha256(self) -> str:
        return native_content_sha256(
            (
                self.source,
                self.previous_batch,
                self.records,
                self.ledger_head_sha256,
                tuple(
                    (
                        raw.envelope_json,
                        raw.capture_receipt_sha256,
                        sha256(raw.payload_bytes).hexdigest(),
                        raw.depth_unit,
                    )
                    for raw in self.visible_prefix
                ),
                self.cutoff,
                *((self.visual_source,) if self.visual_source is not None else ()),
                *(
                    (self.previous_weight_evidence,)
                    if self.previous_weight_evidence is not None
                    else ()
                ),
                *((self.observation_update,) if self.observation_update is not None else ()),
            )
        )


@dataclass(frozen=True)
class ProducedJointCandidates:
    context_sha256: str
    source_posterior_id: UUID
    source_body_sha256: str
    dependency_sha256: str
    receipts: tuple[ParticleRevisionReceipt, ...]
    statistics: dict[UUID, ConditionalAnalyticState]
    unresolved_log_weight: float
    # An inert proof object, re-executed by the native consumer. A caller's flag
    # or a self-consistent probability trace does not authorize a neural input.
    neural_evidence: Any = None


class NativeJointProducer(Protocol):
    """Stateful inference dependency; must not execute external actions.

    Binding covers model/kernel/calibration artifacts, not mutable RNG state.
    Checkpoint/restore must preserve that RNG and all inference history. Returned
    values pass the existing native source/statistic/ancestry checks before use.
    The existing prepared-candidate consumer still rejects unbound selected
    neural artifacts; this protocol does not remove or replace that restriction.
    """

    @property
    def binding_sha256(self) -> str: ...

    def produce(self, context: NativeJointContext) -> ProducedJointCandidates: ...

    def checkpoint_state(self) -> dict[str, Any]: ...

    def restore_state(self, state: dict[str, Any]) -> None: ...


def producer_binding(producer: NativeJointProducer | None) -> str | None:
    if producer is None:
        return None
    value = producer.binding_sha256
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(c not in "0123456789abcdef" for c in value)
    ):
        raise ValueError("joint producer requires a SHA256 dependency binding")
    return value


def producer_implementation_binding(producer: NativeJointProducer | None) -> str | None:
    return python_dependency_implementation_binding(
        producer, required_methods=("produce", "checkpoint_state", "restore_state")
    )


def python_dependency_implementation_binding(
    producer: Any, *, required_methods: tuple[str, ...]
) -> str | None:
    """Pin Python class implementations, including helpers in the full MRO.

    Mutable external data/weights still need the model's artifact/state contract;
    code identity does not certify measurements, likelihoods, or calibration.
    """
    import inspect
    from pathlib import Path
    from types import CodeType

    from cpswm.system.structure_two_execution import _code_object_sha256

    if producer is None:
        return None
    cls = type(producer)
    source_hashes: dict[str, str] = {}

    def source_hash(path: str | None) -> str:
        if path is None:
            raise ValueError("joint producer implementation has no inspectable source")
        if path not in source_hashes:
            source_hashes[path] = sha256(Path(path).read_bytes()).hexdigest()
        return source_hashes[path]

    def function_identity(function: Any) -> tuple[str, str, str, str]:
        code = getattr(function, "__code__", None)
        if not inspect.isfunction(function) or not isinstance(code, CodeType):
            raise ValueError("joint producer implementation has no inspectable loaded Python code")
        return (
            function.__module__,
            function.__qualname__,
            source_hash(inspect.getsourcefile(function)),
            _code_object_sha256(code),
        )

    for name in required_methods:
        method = getattr(producer, name, None)
        declared = next((vars(c)[name] for c in cls.__mro__ if name in vars(c)), None)
        if (
            name in getattr(producer, "__dict__", {})
            or not inspect.ismethod(method)
            or method.__self__ is not producer
            or method.__func__ is not declared
        ):
            raise ValueError("joint producer implementation must use declared instance methods")

    classes = []
    resolved: set[str] = set()
    for owner in cls.__mro__:
        if owner is object:
            continue
        members = []
        for name, descriptor in sorted(vars(owner).items()):
            functions: tuple[tuple[str, Any], ...]
            if isinstance(descriptor, property):
                functions = tuple(
                    (role, fn)
                    for role, fn in (
                        ("get", descriptor.fget),
                        ("set", descriptor.fset),
                        ("delete", descriptor.fdel),
                    )
                    if fn is not None
                )
            elif isinstance(descriptor, (staticmethod, classmethod)):
                functions = ((type(descriptor).__name__, descriptor.__func__),)
            elif inspect.isfunction(descriptor):
                functions = (("method", descriptor),)
            else:
                resolved.add(name)
                continue
            if name not in resolved and name in getattr(producer, "__dict__", {}):
                raise ValueError("joint producer implementation cannot shadow a declared helper")
            resolved.add(name)
            members.append((name, tuple((role, function_identity(fn)) for role, fn in functions)))
        classes.append(
            (
                owner.__module__,
                owner.__qualname__,
                source_hash(inspect.getsourcefile(owner)),
                tuple(members),
            )
        )
    return native_content_sha256(
        ("python-dependency-implementation@1", required_methods, tuple(classes))
    )
