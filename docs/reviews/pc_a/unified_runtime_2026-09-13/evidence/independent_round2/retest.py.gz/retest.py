import pathlib,importlib.util,json,hashlib,subprocess
R=pathlib.Path('/private/tmp/cpswm-pc-a-unified-runtime-20260913');O=pathlib.Path('/private/tmp/cpswm-unified-review2')
spec=importlib.util.spec_from_file_location('fixture_helpers',O/'fixture_helpers.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);h.ROOT=R
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(); results={'source_sha':sha,'cases':{}}
repo=O/'replacement/archive';old=json.loads((O/'results.json').read_text())['git_replace']['original']
for label,args in [('original_commit_with_replace',(repo,old)),('legal_delayed',(O/'valid_delayed/archive',json.loads((O/'valid_delayed/out/receipt.json').read_text())['source_sha']))]:
 out=O/(label+'_retest_'+sha[:7]);p=h._run(*args,out);d={'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 if (out/'receipt.json').exists():
  receipt=json.loads((out/'receipt.json').read_text());d['receipt']=receipt
  assert receipt['selected_capture_count']==2 and receipt['observation_count']==4
  for f in receipt['output_manifest']:assert hashlib.sha256((out/f['file']).read_bytes()).hexdigest()==f['sha256']
 assert p.returncode==0,d;results['cases'][label]=d
case=O/('blob_'+sha[:7]);case.mkdir();repo,old=h._archive(case)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
p='case/schedule_run/observation_candidates/release_journal.json';blob=git('rev-parse',old+':'+p);journal=json.loads((repo/p).read_text());newdata=case/'new_journal.json';newdata.write_text(json.dumps(journal[:1]));newblob=git('hash-object','-w',str(newdata));git('replace',blob,newblob)
out=case/'out';p=h._run(repo,old,out);receipt=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else None
results['cases']['blob_replace']={'exit_code':p.returncode,'stderr':p.stderr,'receipt':receipt,'original_blob':blob,'replacement_blob':newblob};assert p.returncode==0 and receipt['observation_count']==4
(O/('retest_'+sha[:7]+'.json')).write_text(json.dumps(results,indent=2));print(json.dumps({'source_sha':sha,'cases':{k: v['exit_code'] for k,v in results['cases'].items()}}))
