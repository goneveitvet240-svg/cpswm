import pytest
@pytest.mark.xfail(reason='required case')
def test_live():
 assert False
