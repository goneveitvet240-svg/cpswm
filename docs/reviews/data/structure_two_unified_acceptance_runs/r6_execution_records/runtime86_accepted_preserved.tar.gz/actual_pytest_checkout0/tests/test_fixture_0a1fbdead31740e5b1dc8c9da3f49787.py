def test_live():
 from cpswm import dependency_2366269e97b44f309e3700badc169482
 assert dependency_2366269e97b44f309e3700badc169482.VALUE == 9
