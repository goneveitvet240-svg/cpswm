"""Descriptive aggregation of saved full matrices; never a detection accuracy claim."""
from pathlib import Path
from collections import defaultdict, Counter
from offline_frontend_evaluation import summarize
from cpswm.system.reproducibility import content_sha256
import json, hashlib

ROOT=Path(__file__).resolve().parent
reports={k:json.loads((ROOT/k/'report.json').read_text()) for k in ['fasterrcnn','ssdlite']}
cases=json.loads((ROOT/'case-results.json').read_text())
assert all(c['source_sha']=='3babc6d1557b4fe54abc6c8ac1f6054cdeb03e57' for c in cases)
assert [(r['phase'],r['detector'],r['exit_code']) for r in cases]==[('run','fasterrcnn',0),('run','ssdlite',0),('verify','fasterrcnn',0),('verify','ssdlite',0)]
views={}
for kind,r in reports.items():
    final=next(c for c in cases if c['phase']=='verify' and c['detector']==kind)
    assert all(hashlib.sha256((ROOT/kind/name).read_bytes()).hexdigest()==pin for name,pin in final['output_sha256'].items())
    assert set(final['output_sha256'])=={'public.json','report.json','inputs.json'}
    assert r['detector_kind']==kind
    assert r['collection_inventory_sha256']=='9791a946543b9158890324d3ff35a80ea04d51c9cabb6e09540f569abd903d47'
    assert len(r['frames'])==96 and len({f['action_id'] for f in r['frames']})==96
    assert Counter(f['house_index'] for f in r['frames'])=={h:8 for h in range(1,13)}
    assert all(f['split']==('train' if f['house_index']<=8 else 'validation') for f in r['frames'])
    assert content_sha256(summarize(r['frames']))==content_sha256(r['summary'])
    public=json.loads((ROOT/kind/'public.json').read_text())
    assert content_sha256(public)==r['public_predictions_sha256']
    viewsets=defaultdict(set)
    for f,p in zip(r['frames'],public,strict=True):
        camera=p['frame']['geometry']['camera']
        assert f['action_id']==p['command']['action_id']==camera['action_id']
        view=(tuple(camera['position_m']),camera['yaw_degrees'],camera['pitch_degrees'])
        views[(kind,f['action_id'])]=view
        viewsets[f['house_index']].add(view)
    assert all(len(v)==8 for v in viewsets.values())
assert reports['fasterrcnn']['diagnostic_source_files']==reports['ssdlite']['diagnostic_source_files']
assert reports['fasterrcnn']['capture_source_files']==reports['ssdlite']['capture_source_files']
assert all(a['instances']==b['instances'] for a,b in zip(reports['fasterrcnn']['frames'],reports['ssdlite']['frames'],strict=True))
keys=lambda r:[(f['house_index'],f['action_id'],f['rgb_sha256'],f['depth_sha256'],f['geometry_input_group']) for f in r['frames']]
assert keys(reports['fasterrcnn'])==keys(reports['ssdlite'])
analysis={'scope':'DESCRIPTIVE_PIXEL_COVERAGE_AND_RAW_REFERENCE_DISTANCES_ONLY','paired_public_inputs':96,'methods':{},'report_sha256':{k:hashlib.sha256((ROOT/k/'report.json').read_bytes()).hexdigest() for k in reports}}
for kind,report in reports.items():
    observations=defaultdict(set);boxes=defaultdict(set)
    for f in report['frames']:
        eligible={r['object_id'] for r in f['instances'] if r['eligible']}
        for c in f['candidates']:
            for pair in c['overlaps']:
                if pair['object_id'] in eligible and pair['intersection_pixels']>0:
                    boxes[(f['split'],f['house_index'],pair['object_id'])].add(views[(kind,f['action_id'])])
            for s in c['samples']:
                for identity in set(s['rendered_instance_ids'])&eligible:
                    observations[(f['split'],f['house_index'],identity)].add(views[(kind,f['action_id'])])
    info={}
    for split,group in {'overall':report['summary']['overall'],**report['summary']['by_split']}.items():
        pop=group['eligible_instances'];allpop=group['all_instances']
        select=lambda key:split=='overall' or key[0]==split
        distance=pop['member_surface_to_sdk_pivot_raw_distance']
        aabb=pop['member_surface_to_sdk_aabb_center_raw_distance']
        info[split]={k:pop[k] for k in ['candidates','surface_samples','unique_instances','unique_visible_instances','unique_box_overlapping_instances','unique_sample_hit_instances','visible_instance_frames','box_overlapping_instance_frames','sample_hit_instance_frames','candidate_boxes_with_multiple_selected_instances','multiply_box_overlapped_instance_frames','surface_samples_hitting_selected_instances']}
        info[split].update(frames=group['frames'],frames_without_candidates=pop['frames_without_candidates'],boxes_mixing_any_sdk_instances=allpop['candidate_boxes_with_multiple_selected_instances'],surface_samples_with_no_sdk_mask=allpop['surface_samples_hitting_no_selected_instance'],surface_samples_with_multiple_sdk_masks=allpop['surface_samples_hitting_multiple_selected_instances'],eligible_objects_in_two_or_more_box_overlapped_views=sum(select(k) and len(v)>=2 for k,v in boxes.items()),eligible_objects_in_two_or_more_sample_hit_views=sum(select(k) and len(v)>=2 for k,v in observations.items()),pivot_distance={k:v for k,v in distance.items() if k!='values_m'},aabb_distance={k:v for k,v in aabb.items() if k!='values_m'})
    analysis['methods'][kind]=info
(ROOT/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
print(json.dumps(analysis,indent=2))
