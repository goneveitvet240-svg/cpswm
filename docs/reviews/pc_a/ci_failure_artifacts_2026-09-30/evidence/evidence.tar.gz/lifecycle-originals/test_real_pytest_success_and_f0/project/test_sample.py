from sample import value
def test_value():
    assert value() == 7
