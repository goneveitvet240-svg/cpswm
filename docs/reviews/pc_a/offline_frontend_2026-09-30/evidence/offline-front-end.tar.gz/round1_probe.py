"""A-assisted controlled full-artifact attacks; no real simulator data or fitting."""
import copy
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace

import diagnose_offline_frontend as driver
import offline_frontend_evaluation as evaluation
from test_offline_frontend_diagnostic import (
    complete_batch, decoder_factory_with_empty_first_house, seal, write_json,
)
from cpswm.system.reproducibility import content_sha256


def rejected(call, expected):
    try:
        call()
    except ValueError as error:
        assert expected in str(error), (expected, str(error))
        return str(error)
    raise AssertionError("forgery was accepted: " + expected)


with tempfile.TemporaryDirectory(prefix="cpswm-frontend-r1-full-", dir="/private/tmp") as temporary:
    root = Path(temporary)
    evidence = Path(__file__).parent / "round1-controlled-artifacts"
    evidence.mkdir(exist_ok=False)
    factory = SimpleNamespace(mktemp=lambda name: (root / name))
    (root / "frontend-composed").mkdir()
    batch = complete_batch.__wrapped__(factory)
    inputs = driver.inventory(batch.directory)
    events = []
    original = driver.diagnose(
        batch.directory,
        decoder_factory=decoder_factory_with_empty_first_house(events),
        input_inventory=inputs,
        capture_config=batch.config,
        detector_kind="explicit-controlled-fixture",
    )
    assert len(events) == 96 and len(original["report"]["frames"]) == 96
    output = evidence / "original"
    driver.save_or_verify(output, original, verify=False)
    fresh_events = []
    fresh = driver.diagnose(
        batch.directory,
        decoder_factory=decoder_factory_with_empty_first_house(fresh_events),
        input_inventory=inputs,
        capture_config=batch.config,
        detector_kind="explicit-controlled-fixture",
    )
    assert len(fresh_events) == 96
    driver.save_or_verify(output, fresh, verify=True)
    print(json.dumps(dict(case="controlled_positive_96_then_fresh_96", result="accepted", frames=96)))

    for attack in ("promote_all_ineligible", "coherent_reference_shift", "coherent_zero_candidates", "numeric_boolean"):
        output = evidence / attack
        forged = copy.deepcopy(original)
        if attack == "promote_all_ineligible":
            for frame in forged["report"]["frames"]:
                for instance in frame["instances"]:
                    instance.update(eligible=True, exclusion_reasons=[])
                    instance["eligibility"].update(eligible=True, exclusion_reasons=[])
            forged["report"]["summary"] = evaluation.summarize(forged["report"]["frames"])
            assert forged["report"]["summary"]["overall"]["eligible_instances"]["unique_instances"] == 36
        elif attack == "coherent_reference_shift":
            for frame in forged["report"]["frames"]:
                by_id = {i["object_id"]: i for i in frame["instances"]}
                for instance in frame["instances"]:
                    for reference, auditkey in (("sdk_transform_position_m", "position_m"), ("sdk_aabb_center_m", "aabb_center_m")):
                        instance[reference] = [x + 7 for x in instance[reference]]
                        instance["eligibility"][auditkey] = instance[reference].copy()
                for candidate in frame["candidates"]:
                    for pair in candidate["overlaps"]:
                        instance = by_id[pair["object_id"]]
                        for sample, displacement in zip(candidate["samples"], pair["sample_displacements"], strict=True):
                            for key, reference in (("to_sdk_transform", "sdk_transform_position_m"), ("to_sdk_aabb_center", "sdk_aabb_center_m")):
                                displacement[key] = evaluation._displacement(sample["nominal_world_xyz_m"], instance[reference])
            forged["report"]["summary"] = evaluation.summarize(forged["report"]["frames"])
        elif attack == "coherent_zero_candidates":
            for public, frame in zip(forged["public"], forged["report"]["frames"], strict=True):
                public["frame"]["frame"]["candidates"] = []
                public["frame"]["candidates"] = []
                public["frame"]["geometry"]["candidates"] = []
                frame["candidates"] = []
            forged["report"]["summary"] = evaluation.summarize(forged["report"]["frames"])
            assert forged["report"]["summary"]["overall"]["all_instances"]["frames_without_candidates"] == 96
        else:
            forged["report"]["training_performed"] = 0
            assert forged["report"] == original["report"]
        forged["report"]["public_predictions_sha256"] = content_sha256(forged["public"])
        driver.save_or_verify(output, forged, verify=False)
        expected = "fresh public differs" if attack == "coherent_zero_candidates" else "fresh report differs"
        message = rejected(lambda: driver.save_or_verify(output, fresh, verify=True), expected)
        assert driver._json(output / "report.json") == forged["report"]
        print(json.dumps(dict(case=attack, result="rejected_without_overwriting", error=message)))

    # Coherently replace every house's qualification and re-sign the local inventory.
    # The independent caller's ORIGINAL pin must reject this before historical code runs.
    audit_path = batch.directory / "runtime-partition-audit.json"
    audit = driver._json(audit_path)
    write_json(evidence / "original-runtime-partition-audit.json", audit)
    for row in audit["instances"]:
        row.update(eligible=True, exclusion_reasons=[])
    write_json(audit_path, audit)
    new_pin = seal(batch.directory)
    write_json(evidence / "forged-runtime-partition-audit.json", audit)
    write_json(evidence / "pin-attack.json", dict(original_pin=batch.pin, forged_pin=new_pin, original_inventory=inputs, forged_inventory=driver.inventory(batch.directory)))
    assert new_pin != batch.pin
    error = rejected(
        lambda: driver.verify_historical_collection(
            batch.directory, pin=batch.pin, capture_source=batch.source,
            archive=root / "unused-archive", sdk_python=root / "unused-sdk",
            binary=root / "unused-Unity",
        ),
        "external pin differs",
    )
    print(json.dumps(dict(case="coherent_input_eligibility_and_rehash", result="rejected", error=error)))

print(json.dumps(dict(complete=True, source_sha="3babc6d1557b4fe54abc6c8ac1f6054cdeb03e57", real_simulator_data_used=False)))
