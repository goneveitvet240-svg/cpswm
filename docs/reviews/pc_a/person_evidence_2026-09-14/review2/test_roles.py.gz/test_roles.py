from test_interaction_evidence import frame
from cpswm.perception_mapping.interaction_evidence import CausalInstanceAssociator,role_readout

def test_ordered_role_candidates_never_promote_and_identity_break_clears():
    tracker=CausalInstanceAssociator()
    f=frame(boxes=((0,0,55,90),(45,0,100,90),(40,40,60,55)),categories=('person','person','cup'))
    a=tracker.update(f,sequence_id='independent-role',media_time=0)
    b=tracker.update(frame(f,boxes=tuple(d.box_xyxy for d in f.candidates),categories=('person','person','cup')),sequence_id='independent-role',media_time=.2)
    r=role_readout(a,b)
    assert len(r.role_alternatives)==2 and not r.memory_write_authorized
    assert 'role_likelihood_not_calibrated' in r.unresolved_reasons
    assert {(x.actor_track_id,x.recipient_track_id) for x in r.role_alternatives}=={(x.recipient_track_id,x.actor_track_id) for x in r.role_alternatives}
    c=tracker.update(frame(f,boxes=tuple(d.box_xyxy for d in f.candidates),categories=('person','person','cup')),sequence_id='independent-role',media_time=5)
    assert role_readout(b,c).role_alternatives==()
