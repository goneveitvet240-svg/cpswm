import json,hashlib,pathlib,shutil,subprocess,os
base=pathlib.Path('/private/tmp/cpswm-natural-vision-review2')
repo=pathlib.Path('/private/tmp/cpswm-pc-a-natural-vision-20260914')
archive=base/'mismatched'
shutil.copytree('/private/tmp/cpswm-natural-vision-512-input',archive,dirs_exist_ok=True)
p=archive/'receipt.json'; m=json.loads(p.read_text())
# Preserve every payload and envelope hash; change only manifest capture attribution of paired pixels.
m['output_manifest'][1]['capture_ref']='000001.json'
p.write_text(json.dumps(m))
cmd=[str(repo/'.venv/bin/python'),str(repo/'tools/run_natural_vision_archive.py'),'--archive',str(archive),'--manifest-sha256',hashlib.sha256(p.read_bytes()).hexdigest(),'--weights','/private/tmp/cpswm-natural-vision-models/ssdlite320_mobilenet_v3_large_coco-a79551df.pth','--output',str(base/'mismatched_output')]
shutil.rmtree(pathlib.Path(cmd[cmd.index('--output')+1]),ignore_errors=True)
r=subprocess.run(cmd,cwd='/private/tmp',capture_output=True,text=True,env={**os.environ,'PYTHONPATH':str(repo/'src')})
(base/'cli_stdout.txt').write_text(r.stdout+'\n'+r.stderr)
print('returncode',r.returncode)
print(r.stdout[-300:]);print(r.stderr[-300:])
summary=json.loads((base/'mismatched_output/summary.json').read_text())
assert summary['source_sha']=='a3d1ea6de4db1d1bf9038482abbbefbdf707880c'
assert summary['core_unchanged_verified'] and summary['semantic_transitions']==0 and summary['physical_actions']==0
m['captures'].append(m['captures'][0]);p.write_text(json.dumps(m))
cmd[cmd.index('--manifest-sha256')+1]=hashlib.sha256(p.read_bytes()).hexdigest()
cmd[cmd.index('--output')+1]=str(base/'duplicate_output')
shutil.rmtree(pathlib.Path(cmd[cmd.index('--output')+1]),ignore_errors=True)
r=subprocess.run(cmd,cwd='/private/tmp',capture_output=True,text=True,env={**os.environ,'PYTHONPATH':str(repo/'src')})
(base/'duplicate_stdout.txt').write_text(r.stdout+'\n'+r.stderr)
assert r.returncode!=0 and 'duplicate capture reference' in r.stderr
print('prior two P2 fixes verified: actual source SHA from foreign cwd; duplicate ref rejected')
