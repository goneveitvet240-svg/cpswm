import sys, pathlib, os, subprocess, json, hashlib, io
import numpy as np
R=pathlib.Path('/private/tmp/cpswm-pc-a-unified-runtime-20260913'); O=pathlib.Path('/private/tmp/cpswm-unified-review1'); repo=O/'fixture_repo'; repo.mkdir()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
git('init','-q'); git('config','user.name','Independent local probe');git('config','user.email','probe@example.invalid')
base=repo/'case/schedule_run'; raw=base/'evaluator_only/raw'; obs=raw/'observations';obs.mkdir(parents=True); (base/'observation_candidates').mkdir()
a=io.BytesIO(); np.savez(a,rgb=np.zeros((2,3,3),dtype=np.uint8),depth=np.ones((2,3),dtype=np.float32)); pixels=a.getvalue()
r=dict(run_id='probe',step_index=0,request={'action':'Pass'},request_time='2026-09-12T00:00:00+00:00',received_at='2026-09-12T00:00:01+00:00',last_action_success=True,sensor_file='000000.npz',sensor_sha256=hashlib.sha256(pixels).hexdigest(),depth_unit='m',status='RAW_OBSERVATION_CANDIDATE_NOT_METHOD_AUTHORIZATION')
for n in range(2):
 (obs/f'{n:06}.json').write_text(json.dumps(r));(obs/f'{n:06}.npz').write_bytes(pixels)
(raw/'manifest.json').write_text(json.dumps({'run_id':'probe'}));(base/'observation_candidates/release_journal.json').write_text(json.dumps([{'capture_ref':f'{n:06}.json','event_tick':n,'received_tick':n} for n in range(2)]))
git('add','.');git('commit','-qm','Immutable complete duplicate capture fixture');sha=git('rev-parse','HEAD')
env=os.environ.copy(); env['PYTHONPATH']=str(R/'src')
p=subprocess.run([str(R/'.venv/bin/python'),str(R/'tools/structure_two_rgbd_ingress_replay.py'),'--source-root',str(repo),'--source-sha',sha,'--run-path','case','--output',str(O/'duplicate_output')],env=env,text=True,capture_output=True)
result={'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'actual_json_files':len(list((O/'duplicate_output/observations').glob('*.json'))),'actual_npy_files':len(list((O/'duplicate_output/observations').glob('*.npy'))),'fixture_sha':sha}
(O/'probe_result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
