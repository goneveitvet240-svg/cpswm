import time
def test_first():
    assert True
def test_later():
    time.sleep(60)
