"""Sequential adversarial rounds bound to committed sources; no acceptance shortcut."""
import argparse,hashlib,json,os,subprocess,sys,time,signal
from pathlib import Path
from datetime import datetime,UTC
import xml.etree.ElementTree as ET
root=Path('/private/tmp/cpswm-pc-a-positive-call-observation-20260930')
out=Path(__file__).parent
sys.path.insert(0,str(root/'docs/reviews/pc_a/neural_native_loop_2026-09-29'))
from run_frozen import snapshot
py='/private/tmp/cpswm-ci-full-env-20260930/bin/python'
p=argparse.ArgumentParser();p.add_argument('stage',choices=['reviews','full']);p.add_argument('--attempt',default='attempt01');a=p.parse_args()
d=out/a.attempt
source=snapshot();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
workflow=(root/'.github/workflows/ci.yml').read_bytes();assert workflow==subprocess.check_output(['git','show','HEAD:.github/workflows/ci.yml'],cwd=root)
source['.github/workflows/ci.yml']=hashlib.sha256(workflow).hexdigest()
env=dict(os.environ,PYTHONHASHSEED='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',COVERAGE_FILE=str(d/'.coverage'));env.pop('PYTHONPATH',None)
pytest=[py,'-m','pytest','-o','addopts=','-q']
if a.stage=='reviews':
 d.mkdir(exist_ok=False);(d/'source.json').write_text(json.dumps({'head':head,'files':source},indent=2)+'\n');rows=[]
 commands=[('round1',pytest+['tests/test_structure_two_action_death_test.py','--junitxml',str(d/'round1.xml')],1800),
 ('round2',pytest+['tests/test_structure_two_w3_operator_acceptance.py','tests/test_structure_two_execution_interface.py','tests/test_structure_two_formal_revision_lineage.py','--junitxml',str(d/'round2.xml')],1800),
 ('ruff',[py,'-m','ruff','check','tests/test_structure_two_action_death_test.py'],120),
 ('format',[py,'-m','ruff','format','--check','tests/test_structure_two_action_death_test.py'],120)]
else:
 assert json.loads((d/'source.json').read_text())['files']==source
 rows=json.loads((d/'commands.json').read_text());assert all(r['exit_code']==0 and r['source_unchanged'] for r in rows)
 assert {'round1','round2'}<={r['name'] for r in rows}
 commands=[('full_diagnostic',pytest+['-n','4','--dist=loadscope','--maxfail=20','--durations=30','--cov=src','--cov-report=term-missing','--junitxml',str(d/'full_diagnostic.xml')],5400)]
def same():
 now=snapshot();now['.github/workflows/ci.yml']=hashlib.sha256((root/'.github/workflows/ci.yml').read_bytes()).hexdigest();return now==source
for name,command,timeout in commands:
 assert same();started=datetime.now(UTC).isoformat();start=time.monotonic();timed_out=False
 with (d/(name+'.log')).open('w') as log:
  child=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   code=124
 row=dict(name=name,command=command,source_head=head,started_at=started,seconds=time.monotonic()-start,exit_code=code,timed_out=timed_out,source_unchanged=same())
 if (d/(name+'.xml')).is_file():
  row['junit']={k:sum(int(t.attrib.get(k,0)) for t in ET.parse(d/(name+'.xml')).getroot().iter('testsuite')) for k in ('tests','failures','errors','skipped')}
 rows.append(row);(d/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if code or not row['source_unchanged']:raise SystemExit(code or 2)
 if name.startswith('round'):assert not any(row['junit'][k] for k in ('failures','errors','skipped'))
