def test_live():
 from cpswm import dependency_1a54228ac28b4453af54a24b8f926192
 assert dependency_1a54228ac28b4453af54a24b8f926192.VALUE == 9
