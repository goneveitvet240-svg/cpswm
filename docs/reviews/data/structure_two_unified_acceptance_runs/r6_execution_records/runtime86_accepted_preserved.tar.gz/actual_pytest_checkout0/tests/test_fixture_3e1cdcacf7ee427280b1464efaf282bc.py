def test_live():
 import dependency_ea01caf7c7d6419e973d514099fe962c
 assert dependency_ea01caf7c7d6419e973d514099fe962c.VALUE == 9
