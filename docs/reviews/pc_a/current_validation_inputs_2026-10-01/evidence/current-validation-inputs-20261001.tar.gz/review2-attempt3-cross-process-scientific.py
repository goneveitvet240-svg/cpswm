import os,sys,json,subprocess,time
from pathlib import Path
out=Path(__file__).resolve().parent;root=Path("/private/tmp/cpswm-pc-a-current-validation-inputs-20261001");artifact=out/"review2-attempt3-current-scientific.json"
rows=[]
for phase,seed,args in [("generate","0",["--output",str(artifact)]),("verify","8675309",["--verify",str(artifact)])]:
 cmd=[sys.executable,"apps/evaluation_runner/run_structure_two_full_scientific_loop.py",*args];start=time.monotonic()
 with (out/("review2-attempt3-scientific-"+phase+".log")).open("w") as log:r=subprocess.run(cmd,cwd=root,env=dict(os.environ,PYTHONHASHSEED=seed),stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(phase=phase,argv=cmd,PYTHONHASHSEED=seed,exit_code=r.returncode,seconds=time.monotonic()-start));(out/"review2-attempt3-cross-process-scientific.json").write_text(json.dumps(rows,indent=2)+"\n")
 if r.returncode:raise SystemExit(r.returncode)
print("current scientific result freshly replayed across processes and hash seeds")
