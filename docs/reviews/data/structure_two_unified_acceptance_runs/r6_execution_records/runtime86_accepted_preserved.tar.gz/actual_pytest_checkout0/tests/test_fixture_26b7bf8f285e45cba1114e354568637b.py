def test_live():
 import threading
 def work():
  try:
   import cpswm.thread_bad_cache
  except BaseException:
   pass
 thread = threading.Thread(target=work)
 thread.start()
 thread.join()
 assert True
