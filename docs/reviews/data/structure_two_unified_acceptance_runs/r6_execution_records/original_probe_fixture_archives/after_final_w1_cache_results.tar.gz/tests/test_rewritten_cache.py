def test_live():
 import cpswm
 assert cpswm.__version__ == "9.9.9"
