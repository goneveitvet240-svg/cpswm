def test_live():
 from cpswm import dependency_d64ea8c1fbdf4096a6110b749fa50730
 assert dependency_d64ea8c1fbdf4096a6110b749fa50730.VALUE == 9
