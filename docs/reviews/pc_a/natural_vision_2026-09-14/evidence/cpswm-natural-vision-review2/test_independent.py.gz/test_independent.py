from dataclasses import replace
from datetime import timedelta
from uuid import uuid4
import pytest
from test_structure_two_continuous_input import setup,raw_for
from test_natural_vision import fixture_detector,prediction
from cpswm.perception_mapping.natural_vision import NaturalVisionEvidenceProducer

def prepare():
    p,s,b,t=setup(False)
    raw=raw_for(t)
    d=fixture_detector(raw,prediction())
    return p,t,raw,d,NaturalVisionEvidenceProducer(d)

@pytest.mark.parametrize('attack',['hash','scope','future','duplicate','oracle'])
def test_second_bad_input_commits_no_prefix_or_frames(attack):
    p,t,a,d,producer=prepare(); z=raw_for(t);when=a.envelope().arrival_time
    if attack=='hash':z=replace(z,payload_bytes=b'bad')
    elif attack=='duplicate':z=a
    else:
        env=z.envelope()
        changes={'identity':env.identity.model_copy(update={'session_id':uuid4()})} if attack=='scope' else {'arrival_time':when+timedelta(days=1)} if attack=='future' else {'oracle_channel':True}
        z=replace(z,envelope_json=env.model_copy(update=changes).model_dump_json())
    with pytest.raises(ValueError):producer.infer((a,z),cutoff=when)
    assert producer.frames()==() and producer._prefix==()
    assert producer.infer((a,),cutoff=when) is None
    assert len(producer.frames())==1

def test_model_second_call_failure_is_atomic_and_recoverable():
    p,t,a,d,producer=prepare();b=raw_for(t);when=a.envelope().arrival_time
    original=d.infer; calls=[]
    def flaky(raw,*,cutoff):
        calls.append(raw)
        if len(calls)==2:raise ValueError('independent model failure')
        return original(raw,cutoff=cutoff)
    d.infer=flaky
    with pytest.raises(ValueError):producer.infer((a,b),cutoff=when)
    assert producer.frames()==() and producer._prefix==() and producer._cutoff is None
    producer.infer((a,b),cutoff=when)
    assert len(producer.frames())==2
    detached=producer.frames()[0]
    object.__setattr__(detached,'identity_status','VERIFIED')
    assert producer.frames()[0].identity_status=='UNRESOLVED'
