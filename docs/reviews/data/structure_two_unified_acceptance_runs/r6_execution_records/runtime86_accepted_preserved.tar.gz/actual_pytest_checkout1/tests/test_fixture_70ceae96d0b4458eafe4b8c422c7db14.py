def test_external(tmp_path):
 from pathlib import Path
 assert not tmp_path.is_relative_to(Path('/private/tmp/cpswm-r6-runtime86-accepted/actual_pytest_checkout1'))
