from pathlib import Path
import json,subprocess
from cpswm.system.evaluation_operations import structure_two_comparison_audit as audit,structure_two_comparison_dynamic as dynamic
r=Path('/private/tmp/cpswm-pc-a-positive-call-observation-20260930')
d=audit.D0SyntheticReplayExperimentConfig.load(r/audit.DATA_CONFIG).build_adapter().build();ep=d.visible_episodes(audit.ProjectTwoDatasetSplit.TEST)[0]
x=dynamic.boundary_probes(ep)
(Path(__file__).parent/'revision-boundary.json').write_text(json.dumps(dict(source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),probes=x),indent=2)+'\n')
print(json.dumps({k:{n:v for n,v in p.items() if n in ('status','error_type','error','semantic_unchanged','nonempty_target','operations')} for k,p in x.items() if isinstance(p,dict)}),flush=True)
