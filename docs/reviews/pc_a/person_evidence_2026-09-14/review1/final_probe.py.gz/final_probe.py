import sys,importlib.util,json,hashlib,subprocess
from pathlib import Path
from dataclasses import replace
from datetime import datetime,UTC
from zoneinfo import ZoneInfo
sys.path[:0]=['tests','src']
from test_interaction_evidence import frame
from cpswm.perception_mapping.interaction_evidence import CausalInstanceAssociator,fit_calibration,evaluate_calibration
f=frame();z=ZoneInfo('America/New_York'); a=datetime(2025,11,2,1,30,tzinfo=z,fold=0);c=a.replace(fold=1)
for bad in (replace(f,capture_time=c,arrival_time=a,inference_cutoff=a),replace(f,capture_time=datetime(2025,1,1),arrival_time=datetime(2025,1,1),inference_cutoff=datetime(2025,1,1))):
 tracker=CausalInstanceAssociator()
 try:tracker.update(bad,sequence_id='clip',media_time=0)
 except ValueError:pass
 else:raise AssertionError('invalid time accepted')
 good=tracker.update(f,sequence_id='clip',media_time=0)
 assert len(good.detections)==2
print('PASS DST/naive rejection and atomic legal retry')
source=Path('tools/run_person_interaction_video.py').read_text();assert 'crop={w}:{h}:{x}:{y}:exact=1,fps={fps}' in source
v='/private/tmp/cpswm-hoh-public/01.mp4'
def decode(filter):return subprocess.check_output(['ffmpeg','-v','error','-i',v,'-frames:v','1','-vf',filter,'-f','rawvideo','-pix_fmt','rgb24','pipe:1'])
assert decode('crop=100:100:1:0:exact=1,fps=5')!=decode('crop=100:100:0:0:exact=1,fps=5')
assert len(decode('crop=101:99:1:1:exact=1,fps=5'))==101*99*3
print('PASS exact odd-origin and odd-dimension actual video decode')

spec=importlib.util.spec_from_file_location('cal','tools/calibrate_interaction_scores.py');cal=importlib.util.module_from_spec(spec);spec.loader.exec_module(cal)
b=Path('/private/tmp/cpswm-person-review1/calibration');b.mkdir(exist_ok=True)
vis=dict(model_id='test',weights_sha256='a'*64,torch_version='test',torchvision_version='test',minimum_score=.5,observation_id='obs',input_sha256='b'*64,candidates=[dict(candidate_id=str(i),detector_score=s) for i,s in enumerate((.1,.3,.6,.9,.99))])
r=dict(source_sha256='c'*64,records=[dict(visual=vis)])
ann=dict(source='independent fixture only',annotator='review',items=[dict(observation_id='obs',candidate_id=str(i),correct=i>=2) for i in range(4)])
rp=b/'result.json';ap=b/'annotations.json';rp.write_text(json.dumps(r));ap.write_text(json.dumps(ann));digest=hashlib.sha256(ap.read_bytes()).hexdigest()
e=cal.load_examples(rp,ap,digest);assert len(e)==4
art=fit_calibration(e)
# Renamed/re-cropped visual bytes must not bypass source-video split.
vis['input_sha256']='d'*64;vis['observation_id']='other';r['records'][0]['visual']=vis;rp.write_text(json.dumps(r))
ann['items']=[dict(observation_id='other',candidate_id=str(i),correct=i>=2) for i in range(4)];ap.write_text(json.dumps(ann));digest=hashlib.sha256(ap.read_bytes()).hexdigest()
h=cal.load_examples(rp,ap,digest)
try:evaluate_calibration(art,h)
except ValueError as er:assert 'leakage' in str(er)
else:raise AssertionError('same-video leakage accepted')
r['source_sha256']='e'*64;rp.write_text(json.dumps(r));h=cal.load_examples(rp,ap,digest);assert evaluate_calibration(art,h)['count']==4
print('PASS unlabelled excluded, same-video crop leakage rejected, independent-source math fixture allowed')
