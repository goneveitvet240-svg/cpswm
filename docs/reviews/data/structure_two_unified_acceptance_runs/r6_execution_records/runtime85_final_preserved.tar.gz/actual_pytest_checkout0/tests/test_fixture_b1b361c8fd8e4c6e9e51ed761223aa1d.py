def test_live():
 from cpswm import dependency_07d8cfbfccd44a5e91bde494e432fec2
 assert dependency_07d8cfbfccd44a5e91bde494e432fec2.VALUE == 9
