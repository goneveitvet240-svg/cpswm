exec(open('/private/tmp/cpswm-pose-review1/probe.py').read().split('out={}')[0])
from dataclasses import replace
out={}
def state(q=(0,0,0,1)):
 return PoseState(object_instance_id=UUID(int=1),valid_at=datetime(2026,9,13,tzinfo=UTC),pose=Pose3D(frame_id='world',x=0,y=0,z=0,qx=q[0],qy=q[1],qz=q[2],qw=q[3]))
s=state()
for name,o in [('object',s.model_copy(update={'object_instance_id':UUID(int=2)})),('epoch',s.model_copy(update={'valid_at':s.valid_at+timedelta(microseconds=1)})),('frame',s.model_copy(update={'pose':s.pose.model_copy(update={'frame_id':'camera'})})),('pi',state(q=Rotation.from_rotvec([0,np.pi,0]).as_quat()))]:
 try: pose_residual(s,o); out[name]='ACCEPT'
 except Exception as e: out[name]=type(e).__name__
q=Rotation.from_euler('xyz',[1,.8,-2]).as_quat()
out['q_minus_q_equal']=np.allclose(pose_residual(s,state(q=q)),pose_residual(s,state(q=-q)))
I=lambda n:tuple(map(tuple,np.eye(n)))
p=ConditionalAnalyticState((UUID(int=3),),(1.,),I(2),(0.,0.),I(6),(0.,)*6)
m=ConditionalMeasurement(UUID(int=4),(UUID(int=5),),'synthetic',(0.,),(1.,2.),1.,1.,(1.,2.,3.),tuple(map(tuple,np.ones((3,6)))),I(3),1.)
for name,mm in [('wrong_h',replace(m,observation_matrix=tuple(map(tuple,np.ones((3,2)))))),('wrong_rls',replace(m,rls_features=(1.,)*6)),('nonpd_cov',replace(m,noise_covariance=tuple(map(tuple,-np.eye(3))))),('duplicate',None)]:
 try: rebuild_conditional_state(p,(m,m) if mm is None else (mm,)); out[name]='ACCEPT'
 except Exception as e:out[name]=type(e).__name__
print(json.dumps(out,indent=2))
assert all(v=='ValueError' for k,v in out.items() if k!='q_minus_q_equal')
assert out['q_minus_q_equal']
