def test_live():
 import os
 from pathlib import Path
 p=Path(os.environ['S2_SOURCE_EVIDENCE_DIR'])
 p.mkdir(parents=True)
 (p/'actual.log').write_text('actual evidence')
