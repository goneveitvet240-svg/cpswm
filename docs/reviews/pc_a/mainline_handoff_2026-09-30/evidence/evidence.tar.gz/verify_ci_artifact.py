"""Read-only remote CI evidence inspection; never count anonymous nodes as passes."""
from pathlib import Path, PurePosixPath
import collections, hashlib, json, stat, sys, xml.etree.ElementTree as ET, zipfile
b=Path(__file__).parent
for prefix in sys.argv[1:]:
    index=json.loads((b/(prefix+'-artifacts.json')).read_text())
    status=json.loads((b/(prefix+'-final-status.json')).read_text())
    archive=b/(prefix+'-artifact.zip')
    digest=hashlib.sha256(archive.read_bytes()).hexdigest()
    assert len(index['artifacts'])==1
    assert index['artifacts'][0]['digest']=='sha256:'+digest
    destination=b/prefix
    destination.mkdir(exist_ok=False)
    with zipfile.ZipFile(archive) as z:
        names=set()
        for item in z.infolist():
            path=PurePosixPath(item.filename)
            assert not path.is_absolute() and '..' not in path.parts
            assert item.filename not in names and not stat.S_ISLNK(item.external_attr>>16)
            names.add(item.filename)
            target=destination.joinpath(*path.parts)
            if item.is_dir():target.mkdir(parents=True,exist_ok=True)
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                with target.open('xb') as stream:stream.write(z.read(item))
    source=(destination/'source-sha.txt').read_text().strip()
    assert source==status['headSha']
    result=json.loads((destination/'execution/result.json').read_text())
    assert result['log_sha256']==hashlib.sha256((destination/'execution/pytest.log').read_bytes()).hexdigest()
    xml=ET.parse(destination/'execution/pytest.xml').getroot()
    counts=collections.Counter(); failures=[];skips=[];anonymous=[]
    for node in xml.iter('testcase'):
        if not node.attrib.get('name'):
            counts['unattributed']+=1;anonymous.append(ET.tostring(node,encoding='unicode'));continue
        name=node.attrib.get('classname','')+'::'+node.attrib['name']
        failure=node.find('failure');error=node.find('error');skip=node.find('skipped')
        if failure is not None or error is not None:
            x=failure if failure is not None else error
            counts['failed' if failure is not None else 'errors']+=1
            failures.append({'node':name,'message':x.attrib.get('message'),'detail':x.text})
        elif skip is not None:
            counts['xfailed' if skip.attrib.get('type')=='pytest.xfail' else 'skipped']+=1
            skips.append({'node':name,**skip.attrib})
        else:counts['passed']+=1
    verified={'archive_sha256':digest,'github_digest_matches':True,'source_sha':source,'log_sha_matches':True,'execution':result,'junit_counts':dict(counts),'unattributed_not_counted_as_pass':anonymous,'run_status':status['status'],'run_conclusion':status['conclusion'],'not_scientific_acceptance':True}
    for suffix,data in [('verified',verified),('failure-nodes',failures),('skipped-nodes',skips)]:
        (b/(prefix+'-'+suffix+'.json')).write_text(json.dumps(data,indent=2)+'\n')
    print(prefix,source,result['status'],dict(counts))
    print(dict(collections.Counter(x['node'].split('::')[0] for x in failures)))
