def test_live():
 from cpswm import legal_2fab97b250134280a3cdf569bf977c50
 assert legal_2fab97b250134280a3cdf569bf977c50.VALUE == 7
