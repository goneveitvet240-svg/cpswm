from pathlib import Path
import json,shutil
out=Path(__file__).parent; wt=Path('/private/tmp/cpswm-pc-a-visual-support-20260930')
doc=wt/'docs/reviews/pc_a/visual_support_2026-09-30'; run=out/'attempt01'
s=json.loads((run/'support-summary.json').read_text());cmd=json.loads((run/'commands.json').read_text());fresh=json.loads((run/'fresh-verification-commands.json').read_text());arc=json.loads((doc/'evidence/archive.json').read_text());attack=json.loads((run/'forged-support-attack.json').read_text())
assert len(fresh)==2 and all(r['exit_code']==0 and r['source_unchanged'] for r in fresh)
assert attack['rejected'] and all(r['exit_code']==0 and r['source_unchanged'] for r in cmd)
rounds=[r for r in cmd if r['name'] in ('round1','round2')]
assert [r['tests']['tests'] for r in rounds]==[61,42] and all(r['tests']['skipped']==0 for r in rounds)
table='\n'.join(f"| {r['kind']} | {r['frame_count']} | {r['candidate_count']} | {r['categories'].get('apple',0)} | {r['unique_pixels']} | {r['final_unresolved']:.6%} |" for r in s['histories'])
report=f'''# 相机自然视觉候选同历史接线

已新增生产入口 `ContinuousEvidenceInput.visual_observation_support()`：从实际动作拥有的公共RGB重新推理，返回全部检测框、归一化图像位置、模型来源、纠正代际和相同像素组；恢复后可逐项重建候选。**这是自然观测支持接线，尚未将受控联合候选密度替换成自然模型，也没有取得任务收益。**

分支codex/pc-a-visual-support-20260930；base 1d3538794b8b86d66414255f8d37f64d8ff0d88e；实际功能源码{s['source_head']}。后续仅报告与证据。开工远端集成19ddf26830348a2f0b33f0af54d6ba702c5cfb1c、B fd4ca6ef5e81c90d7cf7987b42c0b2810d8a810a；父分支PR61仍有继承格式检查失败，本轮局部通过不覆盖全仓CI。

## 新增内容与验证

相机链以前只输出“有/无类别候选”，一般视觉模块虽保留检测框，但未与这条实际动作/纠正历史形成统一读出。本轮复用既有VisualFrame与固定检测器，在原运行时拥有者内接通完整逐帧候选；不另建可写轨迹或记忆账本。由原始持久数据重新推理，篡改缓存不能替代真实模型输出。所有类别及空候选帧保留，READY、失败、结果不确定和取消动作分别记录；返回候选仍经过原模型NMS/top-k及0.5开发阈值，不能声称穷尽物理世界假设。

候选UUID只标记某帧检测，归一化框只是图像位置。实例身份、三维位置、朝向及概率明确未知；没有长期记忆写入或负观察权限。相同像素组仅指出重复输入，其他组不因此成为独立样本。旧代际仍可审计，但不会自动作为当前后验的新增独立测量。

顺序两轮A局部对抗自审：61/42 passed，均零跳过；耗时{rounds[0]['seconds']:.2f}/{rounds[1]['seconds']:.2f}秒。Ruff/格式和两个变更生产模块mypy通过。真实固定SSDLite与Faster R-CNN参与检查；没有子审核者或B签收。合法多候选、空帧、持久恢复、相同像素不合并身份和账本不变均有正路径；完整伪造阳性/概率/三维位置、动作遗漏、来源错绑、方法代码漂移以及原相机纠正/恢复攻击覆盖见[双审](REVIEWS.md)。

## 两条实际北侧历史

| 在线前端 | 实际帧 | 返回候选总数 | apple候选数 | 不同像素组 | 最终未决 |
| --- | ---: | ---: | ---: | ---: | ---: |
{table}

北侧是上一轮已见且Faster可以检出的开发场景，本批用于工程正路径而非独立留出。两条均沿用受控12源语义日程、1次合法受控撤回、11源神经重放和原两步后续预算；保持同一Unity进程。纠正后数据库恢复读出与纠正前候选历史一致，后续实际观测保留旧帧，并新增本代来源。另两个新Python进程2/2完整重建状态、候选、原后验/动作及同图双前端评价。候选读出没有进入目标密度，不能把未改变的任务结果说成自然联合推断成功；原分类对照保留，其相关回归已跑，本批未另跑分类物理对照。

另在Faster完整真实归档副本中伪造高分apple阳性，同时重建派生候选和图像位置，验证器从原像素重推后以 `fresh owned visual support differs` 拒绝。原件未修改；该完整路径攻击是新增接口复核，仍非外部真实性认证。

SDK27个Python文件、Unity166个文件运行前后摘要不变。两次启动不构成完全配对初始世界；均同房屋北侧，不能算独立泛化。部分复算与下一历史采集并行，不把本轮耗时用作实时性能指标。复用本机环境；跨机器及独立环境验收未完成。

## 证据与下一步

原件{arc['files']}文件、{arc['raw_bytes']:,}字节，压缩{arc['compressed_bytes']:,}字节，逐文件读回核验通过；包SHA256 `{arc['sha256']}`。见[清单](evidence/inventory.json)、[原件包](evidence/visual-support.tar.gz)、[复现说明](REPRODUCE.md)。持久本机位置output/visual-support-20260930。开发阶段出现的摘要序列化/测试接口/类型错误均修正并单列，不混入冻结通过计数；冻结后的实际失败试次以commands.json为准。

下一主项仍为自然实例/位置候选密度、观测模型与自然纠正。现有ProposalPixelObservation可承接帧，但其IoU关联不能直接授权相机转动后的世界身份；仅增加提议q训练也不会改变精确枚举目标密度。详见[下一实现单元](NEXT_STEP.md)。新增RGB-D与相机自身位姿的开发观测权限已向用户提出具体选择，尚未收到答复时维持现有纯RGB权限；物体真值只做评价。完整H/R/I/C/Z/r/V、三RB blocks、七算子和已批准澄清/原分类对照均保留。
'''
review='''# 两轮局部对抗自审

实际功能源码d699b90db2b0cfa719be7f44f8c7128d27c08780；A本机顺序执行，无独立审核者。各命令、全源码映射和JUnit见原件attempt01/source.json、commands.json、round1.xml、round2.xml。

第一轮61项零跳过：新候选接口30项及真实模型2项；完整多候选/空结果、图像位置、因果时间/拥有者/来源/状态覆盖；从SQLite恢复后读出一致，伪造完整高分输出与派生项被拒绝；概率/三维位置注入、遗漏动作、相同像素误合并和加载方法替换均检查。原后验反馈、澄清效用、同历史纠正以及连续采集也保留合法正路径和账本/动作后果。

第二轮42项零跳过：完整实例伪造/重封、真实两模型的resize/ROI/RPN/stride/anchor/box-coder漂移、原历史状态重建/神经重放/纠正回滚、相机断链/分叉/来源遗漏。该轮绑定相同新源码；没有把上轮旧SHA审查直接当本轮验收。

两轮后固定两条实际北侧历史与新进程2/2重建。新增归档攻击用真实Faster完整副本伪造一致阳性和派生候选，被真实原图重推拒绝。Hash/复算不代表第三方观测真实性；检查没有覆盖自然联合目标密度、跨世界身份与6D位姿、人工事件监督、独立校准、全部状态空间或B验收。完整仓库CI未由局部通过替代。
'''
reproduce='''# 复现边界

从功能源码d699b90db2b0cfa719be7f44f8c7128d27c08780复现；base 1d3538794b8b86d66414255f8d37f64d8ff0d88e。源码映射包含所有Python文件、pyproject.toml与uv.lock，改测试文件也会使旧归档源码校验不一致。后续文档/压缩包不改变该映射。

按锁文件独立创建环境；本次复用本机环境，实际版本见python-environment.json。设置PYTHONPATH=src:tests:tools、PYTHONHASHSEED=0、OMP_NUM_THREADS=2、MKL_NUM_THREADS=2，真实测试还须显式指定CPSWM_SSDLITE_WEIGHTS和CPSWM_FASTERRCNN_WEIGHTS。模型文件本身未打入原件包，官方固定全摘要由已有解码器校验。缺依赖/权重造成的skip不可当模型通过；本次冻结双审零跳过。

共享原件内run_frozen_support.py记录顺序reviews/run命令，verify_completed.py记录每条完成后另进程验证。修改外部编排脚本的root/output路径只用于新运行；实际命令、完整路径、退出码、时间、源码前后摘要在attempt01/commands.json与fresh-verification-commands.json。新运行使用新目录，不覆盖失败试次。run_history_action_loop.py与history_visual_evidence.py均有run/verify模式，verify重算历史且不再启动Unity。

旧神经证据仍保存绝对checkpoint_directory，本轮未做跨平台定位适配。仅把归档解压到新目录不等于旧神经证据可在Windows上直接重跑，不能编辑已绑定路径冒充原身份；可在正确源码/权重/SDK环境新建实际历史，或后续实现正式定位适配。另进程通过不等于B独立验收。

before-visual-support.json是纠正前原动作候选，visual-support.json是最终完整动作历史候选；两者均由运行时只接受原始公共图像的接口生成。验证会恢复原SQLite并真实复推比较，不信任导出的候选/身份/概率声明。私有instances/sdk-events仅作原有完整仿真核查，不是该接口参数。图像框不提供公制位置或朝向，也不能代替接触/释放和自然语义写入。
'''
for name,text in [('REPORT.md',report),('REVIEWS.md',review),('REPRODUCE.md',reproduce)]:
 (doc/name).write_text(text);(out/name).write_text(text)
shutil.copy2(out/'NEXT_STEP.md',doc/'NEXT_STEP.md')
print('Wrote reports bound to actual completed outputs')
