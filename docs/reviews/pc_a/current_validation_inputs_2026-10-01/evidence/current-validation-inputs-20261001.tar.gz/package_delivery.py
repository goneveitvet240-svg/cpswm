"""Package selected execution records, verifying every archived byte."""
from pathlib import Path
import hashlib, json, tarfile

root = Path(__file__).parent
destination = Path('/private/tmp/cpswm-pc-a-current-validation-inputs-20261001/docs/reviews/pc_a/current_validation_inputs_2026-10-01/evidence')
result = json.loads((root/'full-regression/execution/result.json').read_text())
assert result['status'] != 'RUNNING', 'Do not package a running result as final'
assert (root/'full-regression/source-after.json').is_file()
destination.mkdir(exist_ok=True)
archive = destination/'current-validation-inputs-20261001.tar.gz'
assert not archive.exists()
directories = (
    'prepared-attempt3', 'prepared-attempt3-execution', 'full-regression',
    'review2-forgery-evidence', 'review2-forgery-source',
    'foreign-worker-original-failed-journal', 'pr82-ci-36836009498',
    'current-ci-36847860851', 'root-test-journals',
    'source-execution-test-logs',
)
paths = [p for p in root.iterdir() if p.is_file() and p.suffix in ('.json','.log','.txt','.py')
         and p.name != 'review1-repeat-cases-inventory.json']
for directory in directories:
    paths.extend(p for p in (root/directory).rglob('*') if p.is_file())
rows = []
with tarfile.open(archive,'w:gz') as target:
    for path in sorted(paths):
        assert not path.is_symlink()
        name = str(path.relative_to(root))
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        rows.append(dict(path=name,bytes=path.stat().st_size,sha256=digest))
        target.add(path,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as target:
    members = target.getmembers()
    assert len(members)==len(rows)
    for row in rows:
        stream = target.extractfile(row['path'])
        assert stream is not None
        data = stream.read()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
        assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
(destination/'inventory.json').write_text(json.dumps(rows,indent=2)+'\n')
record = dict(scope='SELECTED_RECORD_INTEGRITY_NOT_EXECUTION_AUTHENTICATION',
              functional_source='fd08b59bdc01ca9ffe4e9b159cb1393052711d15',
              archive=archive.name,bytes=archive.stat().st_size,
              sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(rows),
              all_members_read_back=True,
              omitted='Temporary virtualenvs, complete test scratch directories, duplicate portable copies, 1GB local R1 scratch archive, and cloud-only old output records. Original failed journal and command logs are included; other originals remain local.')
(destination/'archive.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
