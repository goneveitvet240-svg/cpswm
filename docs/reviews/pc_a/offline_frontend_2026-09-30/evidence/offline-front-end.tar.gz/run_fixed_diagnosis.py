from pathlib import Path
from datetime import datetime, timezone
import json, os, subprocess, time, hashlib

W=Path('/private/tmp/cpswm-pc-a-offline-front-end-20260930')
O=Path('/Users/pangwei/Documents/ai/continual-personalized-semantic-world-model/output/offline-front-end-20260930')
PY='/private/tmp/cpswm-pc-a-camera-checkpoint-fixture-20260930/.venv/bin/python'
B=Path('/Users/pangwei/Documents/ai/continual-personalized-semantic-world-model')
models={'fasterrcnn':'fasterrcnn_resnet50_fpn_v2_coco-dd69338a.pth','ssdlite':'ssdlite320_mobilenet_v3_large_coco-a79551df.pth'}
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
env=os.environ.copy();env['PYTHONPATH']='src:tests:tools'
results=[]
for verify in [False, True]:
 for kind,name in models.items():
  phase='verify' if verify else 'run'
  argv=[PY,'tools/diagnose_offline_frontend.py','--collection',str(B/'output/offline-factor-data-20260930/collection-attempt02'),'--capture-source','/private/tmp/cpswm-pc-a-offline-factor-data-20260930','--archive','/Users/pangwei/.prior/datasets/allenai/procthor-10k/439193522244720b86d8c81cde2e51e3a4d150cf/train.jsonl.gz','--sdk-python',str(B/'.venv-ai2thor/bin/python'),'--binary','/Users/pangwei/.ai2thor/releases/thor-OSXIntel64-f0825767cd50d69f666c7f282e54abfe58f1e917/thor-OSXIntel64-f0825767cd50d69f666c7f282e54abfe58f1e917.app/Contents/MacOS/AI2-THOR','--weights',str(B/'output/models/torchvision'/name),'--output',str(O/kind),'--inventory-sha256','9791a946543b9158890324d3ff35a80ea04d51c9cabb6e09540f569abd903d47','--detector',kind]
  if verify:argv+=['--verify']
  row=dict(detector=kind,phase=phase,argv=argv,source_sha=sha,started_at=datetime.now(timezone.utc).isoformat())
  print(json.dumps(dict(detector=kind,phase=phase,status='started')),flush=True)
  start=time.monotonic()
  with (O/f'{kind}-{phase}.log').open('x') as stream:
   try:row['exit_code']=subprocess.run(argv,cwd=W,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=900).returncode
   except subprocess.TimeoutExpired:row['exit_code']=124;row['timeout']=True
  row.update(elapsed_seconds=time.monotonic()-start,finished_at=datetime.now(timezone.utc).isoformat())
  if row['exit_code']==0:
   row['output_sha256']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((O/kind).iterdir())}
  results.append(row);(O/'case-results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps({k:v for k,v in row.items() if k!='argv'}),flush=True)
  if row['exit_code']!=0:raise SystemExit(row['exit_code'])
