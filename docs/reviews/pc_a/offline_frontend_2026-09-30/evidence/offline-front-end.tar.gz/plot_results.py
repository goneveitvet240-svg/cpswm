from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'analysis.json').read_text())
kinds=['fasterrcnn','ssdlite'];labels=['Faster R-CNN','SSDLite']
rows=[r['methods'][k]['overall'] for k in kinds]
fig,axs=plt.subplots(1,2,figsize=(11,4.8),layout='constrained')
x=np.arange(2);width=.34
for offset,key,color,label in [(-width/2,'unique_box_overlapping_instances','#5477ba','Any box-mask overlap'),(width/2,'unique_sample_hit_instances','#329f89','A sampled pixel in mask')]:
 vals=[q[key] for q in rows]
 bars=axs[0].bar(x+offset,vals,width,color=color,label=label)
 axs[0].bar_label(bars,padding=3)
axs[0].axhline(159,color='#888888',linestyle='--',linewidth=1,label='159 visible eligible objects')
axs[0].set_xticks(x,labels);axs[0].set_ylabel('Distinct eligible objects (across 12 houses)');axs[0].set_ylim(0,185)
axs[0].set_title('Geometric coverage, independent of class')
axs[0].legend(loc='upper center',fontsize=8)
vals=[q['boxes_mixing_any_sdk_instances'] for q in rows]
total=[q['candidates'] for q in rows]
bars=axs[1].bar(x,vals,color=['#5477ba','#329f89'],width=.48)
axs[1].bar_label(bars,labels=[f'{n} / {d} boxes' for n,d in zip(vals,total)],padding=4)
axs[1].set_xticks(x,labels);axs[1].set_ylabel('Boxes overlapping more than one SDK instance')
axs[1].set_ylim(0,max(total+[1])*1.2)
axs[1].set_title('Mixed-object boxes')
for ax in axs:
 ax.spines[['top','right']].set_visible(False);ax.set_axisbelow(True);ax.yaxis.grid(True,alpha=.15)
fig.suptitle('Frozen frontends on the same 96 archived RGB-D frames',fontsize=14)
fig.supxlabel('Descriptive pixel coverage only: not correct identity, calibrated position, or task success.',fontsize=9)
fig.savefig(ROOT/'frontend-coverage.png',dpi=180)
