import pytest
def test_fixture_incomplete():
    pytest.xfail('fixture xfail')
