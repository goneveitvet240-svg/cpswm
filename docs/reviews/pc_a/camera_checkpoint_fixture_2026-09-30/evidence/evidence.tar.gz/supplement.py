from pathlib import Path
import os,sys,json,shutil,subprocess,hashlib,xml.etree.ElementTree as ET
root=Path('/private/tmp/cpswm-pc-a-camera-checkpoint-fixture-20260930');out=Path(__file__).parent
os.chdir(root);sys.path[:0]=[str(root/'src'),str(root/'tests'),str(root/'tools')]
from run_ci_regression import run
from run_camera_policy_identifiability import ARMS,checkpoint_for,run_case
import torch
torch.set_num_threads(2)
source='14409b3beabbd298196ea8f65c4e4f7a0cf719f2'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
bad=out/'wrong-arm-checkpoints';shutil.copytree(out/'relocated-checkpoints',bad)
p=checkpoint_for(bad,ARMS[0])/'manifest.json';data=json.loads(p.read_text());data['arm']=ARMS[1];p.write_text(json.dumps(data,indent=2)+'\n')
os.environ['CPSWM_CHECKPOINTS']=str(bad)
cmd=[str(root/'.venv/bin/python'),'-m','pytest','-o','addopts=','-q','--tb=short','tests/test_camera_policy_identifiability_artifacts.py::test_actual_three_checkpoints_are_legal_and_keep_same_enumerated_prior','--basetemp',str(out/'wrong-arm-originals'),'--junitxml',str(out/'round2-wrong-arm/pytest.xml')]
r=run(cmd,cwd=root,output=out/'round2-wrong-arm',budget_seconds=120,grace_seconds=20)
assert r['exit_code']==1 and 'checkpoint arm differs from method' in (out/'round2-wrong-arm/pytest.log').read_text()
suites=list(ET.parse(out/'round2-wrong-arm/pytest.xml').getroot().iter('testsuite'));assert sum(int(s.attrib['errors']) for s in suites)==1
rows={arm:run_case(out/'actual-output'/arm,pattern='01',method=arm,checkpoint=checkpoint_for(out/'relocated-checkpoints',arm)) for arm in ARMS}
assert len(rows)==3 and all(row['neural_calls']>0 and row['checkpoint_arm']==arm for arm,row in rows.items())
(out/'actual-neural-rows.json').write_text(json.dumps({'actual_source':source,'rows':rows},indent=2)+'\n')
subprocess.run(['git','diff','--exit-code',source,'--','src','tests','apps','tools','.github','pyproject.toml','uv.lock'],check=True)
(out/'supplement-result.json').write_text(json.dumps({'actual_source':source,'wrong_arm_expected_exit':1,'wrong_arm_execution':r,'forged_manifest_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'legal_rows':len(rows),'source_unchanged':True},indent=2)+'\n')
print('SUPPLEMENT_COMPLETE',flush=True)
