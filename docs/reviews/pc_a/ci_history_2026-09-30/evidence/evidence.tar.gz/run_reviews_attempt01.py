from pathlib import Path
import sys,subprocess,os,json,hashlib,time
from datetime import datetime,UTC
import xml.etree.ElementTree as ET
root=Path('/private/tmp/cpswm-pc-a-ci-history-20260930');out=Path(__file__).parent/'attempt01'
sys.path.insert(0,str(root/'docs/reviews/pc_a/neural_native_loop_2026-09-29'))
from run_frozen import snapshot as python_snapshot
def snapshot():
 d=python_snapshot();p=root/'.github/workflows/ci.yml';raw=p.read_bytes();assert raw==subprocess.check_output(['git','show','HEAD:.github/workflows/ci.yml'],cwd=root);d['.github/workflows/ci.yml']=hashlib.sha256(raw).hexdigest();return d
source=snapshot();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();out.mkdir(exist_ok=False)
(out/'source.json').write_text(json.dumps(dict(head=head,files=source),indent=2)+'\n')
py=str(root/'.venv/bin/python');common=[py,'-m','pytest','-o','addopts=','-q'];rows=[]
commands=[('round1',common+['tests/test_structure_two_evidence_versions.py','--junitxml',str(out/'round1.xml')]),('round2',common+['tests/test_structure_two_entry_portability.py','--junitxml',str(out/'round2.xml')])]
for n,cmd in commands:
 assert snapshot()==source;env=dict(os.environ,PYTHONHASHSEED='123' if n=='round2' else '0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2');env.pop('PYTHONPATH',None);started=datetime.now(UTC).isoformat();t=time.monotonic()
 with (out/(n+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
 row=dict(name=n,command=cmd,started_at=started,seconds=time.monotonic()-t,exit_code=r.returncode,source_unchanged=snapshot()==source)
 if n.startswith('round'):
  row['junit']={k:sum(int(s.attrib.get(k,0)) for s in ET.parse(out/(n+'.xml')).getroot().iter('testsuite')) for k in ('tests','failures','errors','skipped')}
 rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert not row['exit_code'] and row['source_unchanged']
 if n.startswith('round'):assert row['junit']['tests'] and not any(row['junit'][k] for k in ('failures','errors','skipped'))
