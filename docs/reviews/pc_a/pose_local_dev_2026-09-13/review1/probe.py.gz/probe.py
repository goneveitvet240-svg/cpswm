import json, subprocess
from datetime import datetime, UTC, timedelta, timezone
from zoneinfo import ZoneInfo
from uuid import UUID
import numpy as np
from scipy.spatial.transform import Rotation
from cpswm.contracts.likelihoods import Pose3D
from cpswm.system.structure_two_pose import PoseState, pose_residual, apply_pose_delta
from cpswm.system.structure_two_particle_workspace import ConditionalAnalyticState
from cpswm.system.structure_two_conditional_updates import ConditionalMeasurement,rebuild_conditional_state
out={}
def state(t=None,q=(0,0,0,1)):
 return PoseState(object_instance_id=UUID(int=1),valid_at=t or datetime(2026,9,13,tzinfo=UTC),pose=Pose3D(frame_id='world',x=0,y=0,z=0,qx=q[0],qy=q[1],qz=q[2],qw=q[3]))
rng=np.random.default_rng(81022)
errs=[]
for i in range(1000):
 r=Rotation.random(random_state=rng); s=state(q=r.as_quat()); axis=rng.normal(size=3); axis*=rng.uniform(0,np.pi-1e-8)/np.linalg.norm(axis); d=tuple(np.r_[rng.normal(size=3),axis]); o=apply_pose_delta(s,d); errs.append(float(np.max(np.abs(np.asarray(pose_residual(s,o))-d))))
out['random_roundtrip_1000_max_error']=max(errs)
t0=datetime(2026,11,1,1,30,tzinfo=ZoneInfo('America/New_York'),fold=0)
t1=t0.replace(fold=1)
out['dst_fold']={'first':t0.isoformat(),'second':t1.isoformat(),'timestamp_delta':t1.timestamp()-t0.timestamp(),'python_equality':t0==t1}
try: out['dst_fold']['accepted_residual']=pose_residual(state(t0),state(t1))
except Exception as e: out['dst_fold']['rejected']=repr(e)
out['same_instant_timezone']=pose_residual(state(),state(datetime(2026,9,13,8,tzinfo=timezone(timedelta(hours=8)))))
for key, pose in [('huge_quaternion', state().pose.model_copy(update={'qx':1e308})),('nan', state().pose.model_copy(update={'x':float('nan')})),('unknown_field',state().pose.model_copy(update={'evil':1}))]:
 try: apply_pose_delta(state().model_copy(update={'pose':pose}), (0,)*6); out[key]='ACCEPT'
 except Exception as e: out[key]=type(e).__name__+': '+str(e)
for rd,gd,md in [(1,6,3),(7,2,4),(2,6,6)]:
 mat=lambda n:tuple(map(tuple,np.eye(n)))
 prior=ConditionalAnalyticState((UUID(int=9),),(1.,),mat(rd),(0.,)*rd,mat(gd),(0.,)*gd)
 h=rng.normal(size=(md,gd)); z=rng.normal(size=md); c=rng.normal(size=(md,md)); cov=c@c.T+np.eye(md); x=rng.normal(size=rd)
 m=ConditionalMeasurement(UUID(int=8),(UUID(int=7),),'probe',(0.,),tuple(x),2.,.7,tuple(z),tuple(map(tuple,h)),tuple(map(tuple,cov)),.8)
 p=rebuild_conditional_state(prior,(m,)); assert np.allclose(p.information,np.eye(gd)+.8*h.T@np.linalg.solve(cov,h)); assert np.allclose(p.information_vector,.8*h.T@np.linalg.solve(cov,z)); assert np.allclose(p.a,np.eye(rd)+.7*np.outer(x,x)); assert np.allclose(p.b,1.4*x); assert rebuild_conditional_state(prior,())==prior
out['independent_dimension_positive_cases']=3
out['source_sha']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
print(json.dumps(out,indent=2))
