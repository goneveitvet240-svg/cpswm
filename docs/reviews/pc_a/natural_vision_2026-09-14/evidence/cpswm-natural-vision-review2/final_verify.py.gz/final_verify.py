import json,hashlib,pathlib,shutil,subprocess,os
base=pathlib.Path('/private/tmp/cpswm-natural-vision-review2')
repo=pathlib.Path('/private/tmp/cpswm-pc-a-natural-vision-20260914')
source=pathlib.Path('/private/tmp/cpswm-natural-vision-512-input')
results=[]
for attack in ['paired','unknown','duplicate','orphan','observation','legal']:
    archive=base/('final_archive_'+attack);shutil.copytree(source,archive,dirs_exist_ok=True)
    p=archive/'receipt.json';m=json.loads(p.read_text())
    if attack=='paired':m['output_manifest'][1]['capture_ref']='000001.json'
    elif attack=='unknown':m['output_manifest'][1]['capture_ref']='missing'
    elif attack=='duplicate':m['captures'].append(m['captures'][0])
    elif attack=='orphan':m['output_manifest'].pop(1)
    elif attack=='observation':m['output_manifest'][1]['observation_id']='00000000-0000-0000-0000-000000000000'
    p.write_text(json.dumps(m));out=base/('final_output_'+attack)
    cmd=[str(repo/'.venv/bin/python'),str(repo/'tools/run_natural_vision_archive.py'),'--archive',str(archive),'--manifest-sha256',hashlib.sha256(p.read_bytes()).hexdigest(),'--weights','/private/tmp/cpswm-natural-vision-models/ssdlite320_mobilenet_v3_large_coco-a79551df.pth','--output',str(out)]
    r=subprocess.run(cmd,cwd='/private/tmp',capture_output=True,text=True,env={**os.environ,'PYTHONPATH':str(repo/'src')})
    (base/('final_'+attack+'.txt')).write_text(r.stdout+'\n'+r.stderr)
    if attack!='legal':assert r.returncode!=0 and not out.exists(),(attack,r.stdout,r.stderr)
    else:
        assert r.returncode==0,r.stderr
        summary=json.loads((out/'summary.json').read_text())
        assert summary['source_sha']=='6bb72386d588c82f0e264afa1dadd51306c1cada'
        assert summary['frames']==4 and summary['raw_observations']==8
        assert summary['semantic_transitions']==0 and summary['physical_actions']==0 and summary['core_unchanged_verified']
    results.append({'case':attack,'exit':r.returncode,'passed':True})
(base/'final_cli_checks.json').write_text(json.dumps(results,indent=2))
print(results)
