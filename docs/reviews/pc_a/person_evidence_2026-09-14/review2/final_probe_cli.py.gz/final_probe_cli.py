from pathlib import Path
import subprocess,hashlib,json,os
base=Path('/private/tmp/cpswm-person-review2');repo=Path('/private/tmp/cpswm-pc-a-person-evidence-20260914');video=Path('/private/tmp/cpswm-hoh-public/01.mp4')
cmd=[str(repo/'.venv/bin/python'),str(repo/'tools/run_person_interaction_video.py'),'--video',str(video),'--sha256',hashlib.sha256(video.read_bytes()).hexdigest(),'--source-url','https://example.org/explicitly-supplied-source-label','--crop','0','0','201','199','--duration','0.2','--fps','5','--weights','/private/tmp/cpswm-natural-vision-models/ssdlite320_mobilenet_v3_large_coco-a79551df.pth','--output',str(base/'final_cli_output')]
r=subprocess.run(cmd,cwd='/private/tmp',env={**os.environ,'PYTHONPATH':str(repo/'src'),'OMP_NUM_THREADS':'2'},capture_output=True,text=True)
(base/'final_cli_stdout.txt').write_text(r.stdout+'\n'+r.stderr)
print(r.returncode,r.stdout[-1500:],r.stderr[-500:])
if r.returncode==0:
    result=json.loads((base/'final_cli_output/result.json').read_text());assert result['core_unchanged_verified'] and result['memory_writes']==0 and result['executed_actions']==0
    print('keys',list(result))

assert result['code_sha']=='6f142dbf732009a82e08cd882b62f55708dfdd6d'
assert len(result['source_files'])==3
assert not result['git_dirty']
