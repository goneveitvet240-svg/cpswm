from pathlib import Path
import os,sys,subprocess,json,hashlib,shutil,xml.etree.ElementTree as ET
root=Path('/private/tmp/cpswm-pc-a-camera-checkpoint-fixture-20260930');out=Path(__file__).parent
os.chdir(root);sys.path.insert(0,str(root/'tools'))
from run_ci_regression import run
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
paths=subprocess.check_output(['git','ls-files','-z','src','tests','apps','tools','.github','pyproject.toml','uv.lock'],text=True).strip('\0').split('\0')
def snapshot():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
 subprocess.run(['git','diff','--exit-code',source,'--',*['src','tests','apps','tools','.github','pyproject.toml','uv.lock']],check=True,stdout=subprocess.PIPE)
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
files=snapshot();(out/'source.json').write_text(json.dumps({'actual_source':source,'files':files},indent=2)+'\n')
checkpoint=root/'docs/reviews/pc_a/neural_native_loop_2026-09-29/evidence/development-checkpoints'
original={str(p.relative_to(checkpoint)):hashlib.sha256(p.read_bytes()).hexdigest() for p in checkpoint.rglob('*') if p.is_file()}
(out/'checkpoint-hashes.json').write_text(json.dumps(original,indent=2)+'\n')
os.environ.update(PYTHONHASHSEED='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2');os.environ.pop('CPSWM_CHECKPOINTS',None);os.environ.pop('PYTHONPATH',None)
py=str(root/'.venv/bin/python');test='tests/test_camera_policy_identifiability_artifacts.py';commands=[]
def stage(name,node,expected=0,pattern=None):
 assert snapshot()==files
 cmd=[py,'-m','pytest','-o','addopts=','-q','--tb=short',node,'--basetemp',str(out/(name+'-originals')),'--junitxml',str(out/name/'pytest.xml')]
 result=run(cmd,cwd=root,output=out/name,budget_seconds=480,grace_seconds=20)
 suites=list(ET.parse(out/name/'pytest.xml').getroot().iter('testsuite'));counts={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ['tests','failures','errors','skipped']}
 row={'name':name,'source_sha':source,'execution':result,'junit':counts,'expected_exit':expected,'checkpoint_override':os.environ.get('CPSWM_CHECKPOINTS'),'source_unchanged':snapshot()==files}
 commands.append(row);(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert result['exit_code']==expected and row['source_unchanged'] and counts['skipped']==0
 if expected==0:assert counts['tests']==13 and counts['failures']==counts['errors']==0
 else:
  assert counts['tests']==1 and counts['errors']==1 and counts['failures']==0
  assert pattern in (out/name/'pytest.log').read_text()
 assert original=={str(p.relative_to(checkpoint)):hashlib.sha256(p.read_bytes()).hexdigest() for p in checkpoint.rglob('*') if p.is_file()}
stage('round1-default',test)
relocated=out/'relocated-checkpoints';shutil.copytree(checkpoint,relocated)
assert original=={str(p.relative_to(relocated)):hashlib.sha256(p.read_bytes()).hexdigest() for p in relocated.rglob('*') if p.is_file()}
os.environ.update(PYTHONHASHSEED='123',CPSWM_CHECKPOINTS=str(relocated))
stage('round2-relocated',test)
os.environ['CPSWM_CHECKPOINTS']=str(out/'missing-explicit-checkpoints')
stage('round2-missing-override',test+'::test_actual_three_checkpoints_are_legal_and_keep_same_enumerated_prior',1,'FileNotFoundError')
os.environ['CPSWM_CHECKPOINTS']=''
stage('round2-empty-override',test+'::test_actual_three_checkpoints_are_legal_and_keep_same_enumerated_prior',1,'FileNotFoundError')
print('TWO_REVIEWS_COMPLETED',flush=True)
