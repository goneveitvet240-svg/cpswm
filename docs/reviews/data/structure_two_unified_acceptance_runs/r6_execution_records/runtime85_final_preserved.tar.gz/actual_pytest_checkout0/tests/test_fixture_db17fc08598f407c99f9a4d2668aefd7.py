def test_live():
 import dependency_f11246b5d69544bba026ab364999d1b1
 assert dependency_f11246b5d69544bba026ab364999d1b1.VALUE == 9
