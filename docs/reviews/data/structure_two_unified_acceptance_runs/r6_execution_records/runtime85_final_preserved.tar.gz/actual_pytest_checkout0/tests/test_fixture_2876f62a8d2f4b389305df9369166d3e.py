def test_live():
 from cpswm import legal_0f610b2fae524555b3a5d2ba14d97ea5
 assert legal_0f610b2fae524555b3a5d2ba14d97ea5.VALUE == 7
