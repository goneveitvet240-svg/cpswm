def test_live():
 import dependency_f0136d69631f401b9717f18f8398db66
 assert dependency_f0136d69631f401b9717f18f8398db66.VALUE == 9
