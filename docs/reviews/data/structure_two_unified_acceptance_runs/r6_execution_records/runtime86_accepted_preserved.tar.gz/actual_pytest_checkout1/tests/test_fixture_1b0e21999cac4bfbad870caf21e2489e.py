def test_foreign():
 import importlib.util, sys
 spec=importlib.util.spec_from_file_location('cpswm', '/private/tmp/cpswm-r6-runtime86-accepted/test_real_foreign_module_loade0/cpswm.py')
 loaded=importlib.util.module_from_spec(spec)
 spec.loader.exec_module(loaded)
 sys.modules['cpswm']=loaded
 assert loaded.VALUE == 99
