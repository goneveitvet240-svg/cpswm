def test_fixture_arithmetic():
    assert 2 + 3 == 5
