import pytest
@pytest.mark.parametrize('n', range(4))
def test_live(n):
 import cpswm
 assert cpswm.VALUE == 7
