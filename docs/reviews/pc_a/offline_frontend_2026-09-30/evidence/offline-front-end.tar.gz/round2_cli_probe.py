"""Frozen-source R2 subprocess CLI probe with explicit detector/SDK stand-ins.

Public transport, RGB-D geometry, evaluator, summary, source/inventory binding,
CLI argument handling and saved-result verification are the real frozen code.
No empirical capture, model training or independent archive qualification claim.
"""
import copy
import json
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

import diagnose_offline_frontend as driver
import offline_frontend_evaluation as evaluation
from test_offline_frontend_diagnostic import complete_batch, seal, write_json
from cpswm.perception_mapping.unity_rgbd import CameraSelfPose
from cpswm.system.reproducibility import content_sha256


SHA = "3babc6d1557b4fe54abc6c8ac1f6054cdeb03e57"
SOURCE = Path("/private/tmp/cpswm-pc-a-offline-front-end-20260930")
OUT = Path(__file__).parent
EVIDENCE = OUT / "round2-controlled-artifacts"
EVIDENCE.mkdir(exist_ok=False)
START_SOURCE = driver.source_identity(SOURCE)
RESULTS = []

WRAPPER = '''import atexit, json
from dataclasses import replace
import diagnose_offline_frontend as driver
from test_owned_rgbd_support import RGBDSupportDecoder

counts = dict(houses=0, inferred=0, evaluated=0)
read_json, evaluate = driver._json, driver.evaluate_frame
def factory(weights, kind, scope):
    counts['houses'] += 1
    empty = counts['houses'] == 1
    class Fixture(RGBDSupportDecoder):
        def measurements(self, observations, *, cutoff):
            assert len(observations) == 3
            for raw in observations:
                e = raw.envelope()
                assert (e.identity.household_id, e.identity.session_id, e.identity.trace_id) == scope
            frames = super().measurements(observations, cutoff=cutoff)
            counts['inferred'] += 1
            return tuple(replace(f, candidates=()) for f in frames) if empty else frames
    return Fixture()
def check_read(path):
    if path.name == 'runtime-partition-audit.json' or 'evaluator_only' in path.parts:
        assert counts['inferred'] == 96
    return read_json(path)
def check_evaluate(*args, **kwargs):
    assert counts['inferred'] == 96
    result = evaluate(*args, **kwargs)
    counts['evaluated'] += 1
    return result
driver.make_decoder = factory
driver._json = check_read
driver.evaluate_frame = check_evaluate
atexit.register(lambda: print('R2_COUNTS=' + json.dumps(counts, sort_keys=True)))
driver.main()
'''

HISTORICAL_STANDIN = '''# Explicit controlled substitute for historical SDK runtime qualification.
import json, os, sys
status = dict(complete_twelve_house_runtime_audit=True,
              complete_asset_exposure_audit=True,
              supervision_export_performed=False, training_performed=False)
if os.environ.get('R2_HISTORY_NUMERIC'):
    status = {key: int(value) for key, value in status.items()}
print(json.dumps(status))
raise SystemExit(int(os.environ.get('R2_HISTORY_EXIT', '0')))
'''


def run(case, batch, output, *, source=SOURCE, verify=True, expected=None, environment=None):
    env = os.environ.copy()
    env['PYTHONPATH'] = os.pathsep.join(str(source / name) for name in ('src', 'tests', 'tools'))
    env.update(environment or {})
    command = [sys.executable, str(wrapper)]
    for key, value in dict(collection=batch.directory, capture_source=batch.source,
                           archive=temporary / 'controlled-unused-archive',
                           sdk_python=temporary / 'sdk-venv/bin/python',
                           binary=temporary / 'controlled-unused-Unity',
                           weights=temporary / 'controlled-decoder-no-weights',
                           output=output, detector='ssdlite', inventory_sha256=batch.pin).items():
        command.extend(['--' + key.replace('_', '-'), str(value)])
    if verify:
        command.append('--verify')
    result = subprocess.run(command, cwd=source, env=env, capture_output=True, text=True, timeout=180)
    (EVIDENCE / (case + '.stdout.log')).write_text(result.stdout)
    (EVIDENCE / (case + '.stderr.log')).write_text(result.stderr)
    marker = [line for line in result.stdout.splitlines() if line.startswith('R2_COUNTS=')]
    assert len(marker) == 1, (case, result.stdout, result.stderr)
    counts = json.loads(marker[0].split('=', 1)[1])
    if expected is None:
        assert result.returncode == 0, (case, result.stderr)
        assert counts == dict(houses=12, inferred=96, evaluated=96), counts
    else:
        assert result.returncode != 0 and expected in result.stderr, (case, result.stderr)
        if expected.startswith('fresh '):
            assert counts == dict(houses=12, inferred=96, evaluated=96), counts
        else:
            assert counts == dict(houses=0, inferred=0, evaluated=0), counts
    row = dict(case=case, command=command, cwd=str(source), returncode=result.returncode,
               counts=counts, expected_error=expected, result='accepted' if expected is None else 'rejected')
    RESULTS.append(row)
    print(json.dumps(row), flush=True)


def save_forgery(name, value):
    output = EVIDENCE / name
    driver.save_or_verify(output, value, verify=False)
    return output


with tempfile.TemporaryDirectory(prefix='cpswm-frontend-r2-cli-', dir='/private/tmp') as temporary_name:
    temporary = Path(temporary_name)
    root = temporary / 'frontend-composed'
    root.mkdir()
    batch = complete_batch.__wrapped__(SimpleNamespace(mktemp=lambda name: root))
    (batch.source / 'tools/collect_offline_factor_data.py').write_text(HISTORICAL_STANDIN)
    batch.config['source_files'] = driver.source_identity(batch.source)
    write_json(batch.directory / 'configuration.json', batch.config)
    batch.pin = seal(batch.directory)
    wrapper = temporary / 'controlled_cli_entry.py'
    wrapper.write_text(WRAPPER)
    (EVIDENCE / 'controlled_cli_entry.py').write_text(WRAPPER)
    (EVIDENCE / 'historical_sdk_standin.py').write_text(HISTORICAL_STANDIN)
    output = EVIDENCE / 'original'
    run('01_original_write', batch, output, verify=False)
    run('02_original_verify', batch, output)
    original = {name: driver._json(output / (name + '.json')) for name in ('public', 'report', 'inputs')}
    assert original['report']['diagnostic_source_files'] == START_SOURCE
    assert original['report']['capture_source_files'] == driver.source_identity(batch.source)
    assert original['report']['summary']['overall']['all_instances']['candidate_instance_pairs'] == 792
    assert original['report']['summary']['overall']['all_instances']['frames_without_candidates'] == 8
    original_inputs = driver.inventory(batch.directory)
    write_json(EVIDENCE / 'source-and-input-pins.json', dict(source_sha=SHA, diagnostic_files=START_SOURCE,
               historical_source_files=batch.config['source_files'], inventory_sha256=batch.pin,
               inputs=original_inputs, explicit_runtime_substitute=True, explicit_detector_substitute=True))

    # Move every path without changing any bytes; source identity remains path-independent.
    moved = temporary / 'moved'
    moved.mkdir()
    shutil.move(str(batch.directory), moved / 'inputs-renamed')
    shutil.move(str(batch.source), moved / 'historical-renamed')
    batch.directory, batch.source = moved / 'inputs-renamed', moved / 'historical-renamed'
    moved_output = EVIDENCE / 'moved-output'
    shutil.copytree(output, moved_output)
    run('03_moved_input_output_historical', batch, moved_output)

    source_copy = moved / 'current-code-renamed'
    for folder in ('src', 'tests', 'tools'):
        shutil.copytree(SOURCE / folder, source_copy / folder, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    assert driver.source_identity(source_copy) == START_SOURCE
    run('04_all_paths_moved_same_current_code', batch, moved_output, source=source_copy)

    # Current loaded diagnostic source changes even though its numerical algorithm does not.
    source_file = source_copy / 'tools/diagnose_offline_frontend.py'
    source_file.write_text(source_file.read_text() + '\n# controlled source-identity mutation\n')
    run('05_current_source_comment_change', batch, moved_output, source=source_copy, expected='fresh report differs')

    for attack in ('coherent_camera_and_geometry', 'coherent_time_and_action_owner',
                   'coherent_partition_swap', 'coherent_asset_alias',
                   'semantic_authority', 'source_binding_forgery', 'strict_public_boolean'):
        forged = copy.deepcopy(original)
        if attack == 'coherent_camera_and_geometry':
            for public, frame in zip(forged['public'], forged['report']['frames'], strict=True):
                geometry = public['frame']['geometry']
                geometry['camera']['position_m'][0] += 3.0
                geometry['camera']['yaw_degrees'] = (geometry['camera']['yaw_degrees'] + 45) % 360
                camera = CameraSelfPose.model_validate(geometry['camera'])
                for candidate, evaluated in zip(geometry['candidates'], frame['candidates'], strict=True):
                    for sample, esample in zip(candidate['samples'], evaluated['samples'], strict=True):
                        u, v = sample['pixel_uv']
                        point = list(camera.world_point(u, v, sample['rendered_depth_m']))
                        sample['nominal_world_xyz_m'] = esample['nominal_world_xyz_m'] = point
                    objects = {row['object_id']: row for row in frame['instances']}
                    for pair in evaluated['overlaps']:
                        obj = objects[pair['object_id']]
                        for esample, displacement in zip(evaluated['samples'], pair['sample_displacements'], strict=True):
                            for key, reference in (('to_sdk_transform', 'sdk_transform_position_m'),
                                                   ('to_sdk_aabb_center', 'sdk_aabb_center_m')):
                                displacement[key] = evaluation._displacement(esample['nominal_world_xyz_m'], obj[reference])
                frame['geometry_input_group'] = content_sha256((camera.rgb_sha256, camera.depth_sha256,
                    camera.position_m, camera.yaw_degrees, camera.pitch_degrees, camera.width,
                    camera.height, camera.vertical_fov_degrees, camera.near_plane_m, camera.far_plane_m))
        elif attack == 'coherent_time_and_action_owner':
            for public, frame in zip(forged['public'], forged['report']['frames'], strict=True):
                owner = str(uuid4())
                public['command']['action_id'] = public['frame']['geometry']['camera']['action_id'] = frame['action_id'] = owner
                for parent, key in ((public['command'], 'decision_time'),
                    (public['frame']['geometry']['camera'], 'capture_time'),
                    *[(public['frame']['frame'], name) for name in ('capture_time', 'arrival_time', 'inference_cutoff')]):
                    parent[key] = (datetime.fromisoformat(parent[key]) + timedelta(days=3650)).isoformat()
        elif attack == 'coherent_partition_swap':
            for frame in forged['report']['frames']:
                if frame['house_index'] in (1, 9):
                    frame['house_index'] = 10 - frame['house_index']
                    frame['split'] = 'train' if frame['house_index'] <= 8 else 'validation'
                    for obj in frame['instances']:
                        obj['eligibility'].update(house_index=frame['house_index'], split=frame['split'])
        elif attack == 'coherent_asset_alias':
            for frame in forged['report']['frames']:
                for obj in frame['instances']:
                    if obj['object_id'] == 'a':
                        obj['asset_id'] = obj['eligibility']['asset_id'] = 'invented_validation_only_asset'
                        obj['eligibility']['eligible'] = obj['eligible'] = False
                        obj['eligibility']['exclusion_reasons'] = obj['exclusion_reasons'] = ['invented_cross_partition_exposure']
        elif attack == 'semantic_authority':
            for key in ('automatic_identity_assignment', 'semantic_category_mapping',
                        'formal_position_reference_selected', 'observation_likelihood_written', 'online_memory_write'):
                forged['report'][key] = True
        elif attack == 'source_binding_forgery':
            forged['report']['diagnostic_source_files']['tools/diagnose_offline_frontend.py'] = '0' * 64
        else:
            for public in forged['public']:
                public['frame']['geometry']['memory_write_authorized'] = 0
            assert forged['public'] == original['public']
        forged['report']['summary'] = evaluation.summarize(forged['report']['frames'])
        forged['report']['public_predictions_sha256'] = content_sha256(forged['public'])
        path = save_forgery(attack, forged)
        before = driver.inventory(path)
        expected = 'fresh public differs' if attack in ('coherent_camera_and_geometry', 'coherent_time_and_action_owner', 'strict_public_boolean') else 'fresh report differs'
        run('attack_' + attack, batch, path, expected=expected)
        assert driver.inventory(path) == before

    run('historical_nonzero_with_complete_stdout', batch, moved_output,
        expected='historical collection verifier failed', environment={'R2_HISTORY_EXIT': '7'})
    run('historical_numeric_success_flags', batch, moved_output,
        expected='historical collection is not a complete eligible', environment={'R2_HISTORY_NUMERIC': '1'})
    historical_file = batch.source / 'tools/collect_offline_factor_data.py'
    saved_historical = historical_file.read_bytes()
    historical_file.write_bytes(saved_historical + b'\n# altered source\n')
    run('historical_source_changed', batch, moved_output, expected='historical capture source bytes differ')
    historical_file.write_bytes(saved_historical)
    old_pin = batch.pin
    batch.pin = '0' * 64
    run('external_pin_changed', batch, moved_output, expected='collection external pin differs')
    batch.pin = old_pin
    run('restored_positive', batch, moved_output)
    assert driver.inventory(batch.directory) == original_inputs

assert driver.source_identity(SOURCE) == START_SOURCE
write_json(EVIDENCE / 'results.json', dict(source_sha=SHA, source_unchanged=True, cases=RESULTS,
           real_simulator_data_used=False, historical_sdk_process_replaced=True,
           controlled_detector=True, geometry_evaluation_summary_replaced=False))
print(json.dumps(dict(complete=True, cases=len(RESULTS), source_sha=SHA, source_unchanged=True)))
