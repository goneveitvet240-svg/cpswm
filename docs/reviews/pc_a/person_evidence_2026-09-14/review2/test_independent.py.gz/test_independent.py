from dataclasses import replace
from datetime import datetime, timedelta, UTC
from zoneinfo import ZoneInfo
import pytest
from test_interaction_evidence import frame, examples
from cpswm.perception_mapping.interaction_evidence import CausalInstanceAssociator,fit_calibration,evaluate_calibration

@pytest.mark.parametrize('attack',['naive','dst'])
def test_invalid_visual_time_rejected_before_association(attack):
    f=frame();t=CausalInstanceAssociator()
    if attack=='naive':
        when=datetime(2026,1,1)
        bad=replace(f,capture_time=when,arrival_time=when,inference_cutoff=when)
    else:
        zone=ZoneInfo('America/New_York')
        capture=datetime(2026,11,1,1,30,tzinfo=zone,fold=1)
        arrival=datetime(2026,11,1,1,30,tzinfo=zone,fold=0)
        assert capture.astimezone(UTC)>arrival.astimezone(UTC)
        bad=replace(f,capture_time=capture,arrival_time=arrival,inference_cutoff=capture+timedelta(hours=2))
    with pytest.raises(ValueError):t.update(bad,sequence_id='review',media_time=0)
    assert t._last is None

def test_forged_calibration_source_revalidated_at_fit():
    rows=examples()
    for row in rows:object.__setattr__(row,'annotation_source','prediction')
    with pytest.raises(ValueError):fit_calibration(rows)

def test_geometric_ambiguity_and_gap_no_silent_identity_merge():
    t=CausalInstanceAssociator();f=frame(boxes=((0,0,60,90),(40,0,100,90)))
    a=t.update(f,sequence_id='review',media_time=0)
    b=t.update(frame(f,boxes=((20,0,80,90),)*2),sequence_id='review',media_time=.1)
    assert all(d.status=='AMBIGUOUS_NEW_BRANCH' and len(d.alternatives)==2 for d in b.detections)
    assert not {d.track_id for d in a.detections}&{d.track_id for d in b.detections}
    c=t.update(frame(f),sequence_id='review',media_time=5)
    assert all(d.status=='NEW_UNVERIFIED' for d in c.detections)

def test_real_holdout_input_leakage_rejected_even_renamed_sequence():
    a=fit_calibration(examples())
    with pytest.raises(ValueError,match='leakage'):evaluate_calibration(a,examples('new-sequence','a'))
    assert evaluate_calibration(a,examples('new-sequence','b'))['count']==4
