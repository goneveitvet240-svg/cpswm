def test_live():
 from pathlib import Path
 Path('src/actual_new_dependency.py').write_text('VALUE = 2\n')
