import hashlib,json,sys
from pathlib import Path
import yaml
ROOT=Path('/private/tmp/cpswm-pc-a-regression-completion-20261001')
EVID=Path('/private/tmp/cpswm-regression-completion-evidence-20261001')
sys.path.insert(0,str(ROOT/'tools'))
from reconcile_ci_regression import reconcile
from prepare_current_validation_inputs import source_inventory
old=Path('/private/tmp/cpswm-current-validation-evidence-20261001/full-regression')
result=json.loads((old/'execution/result.json').read_text())
a=reconcile((old/'collection.log').read_bytes(),0,(old/'execution/pytest.xml').read_bytes(),result,source_unchanged=True)
assert a['collection_valid'] and a['collected_count']==6758
assert len(a['missing_nodes'])==2040
assert len(a['unmatched_or_ambiguous_records'])==4
assert a['outcomes']=={'passed':4687,'failure':1,'skipped':29,'xfailed':1,'unidentified':4}
assert not a['all_nodes_have_one_terminal_result']
assert not a['ordinary_regression_passed'] and not a['strict_all_nodes_passed']
original=json.loads((old.parent/'full-regression-summary.json').read_text())
assert a['missing_nodes']==original['missing_nodes']
assert a['multiple_records']==original['multiple_junit_records']=={}
(EVID/'historical-accounting.json').write_text(json.dumps(a,indent=2)+'\n')
wf=yaml.safe_load((ROOT/'.github/workflows/ci.yml').read_text())
job=wf['jobs']['test']
assert job['timeout-minutes']==200 and job['needs']=='current-inputs'
cmd=next(x['run'] for x in job['steps'] if 'run_ci_regression.py' in x.get('run',''))
for token in ('--budget-seconds 10800','--grace-seconds 60','--collection-log output/ci-regression/collection.log','--collection-exit-code-file output/ci-regression/collection-exit-code.txt','--inputs output/ci-validation-inputs'):
 assert token in cmd
assert wf['jobs']['current-inputs']['timeout-minutes']==140
assert '--budget-seconds 7200' in next(x['run'] for x in wf['jobs']['current-inputs']['steps'] if 'prepare_current_validation_inputs.py' in x.get('run',''))
assert any(x.get('if')=='always()' and 'upload-artifact@' in x.get('uses','') for x in job['steps'])
assert source_inventory(ROOT)==json.loads((EVID/'frozen-source-reviewed.json').read_text())
summary={'historical_missing_exact_match':True,'historical_source':'fd08b59bdc01ca9ffe4e9b159cb1393052711d15','historical_execution_exit_code':result['exit_code'],'current_tool_source':'d9d409bedd1cae074ef5459307c236de0a872b46','frozen_files':1120,'current_source_unchanged':True,'workflow_actual_configuration_checked':True,'independent_execution_authentication':False}
(EVID/'review2-historical-workflow.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
