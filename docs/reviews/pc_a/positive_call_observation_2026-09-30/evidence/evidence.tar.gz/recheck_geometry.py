"""Matrix re-evaluation of archived public depth; private rays stay evaluation-only."""
from pathlib import Path
import hashlib,io,json,math,tarfile
import numpy as np
root=Path('/private/tmp/cpswm-pc-a-positive-call-observation-20260930')
a=next((root/'docs/reviews/pc_a/rgbd_camera_geometry_2026-09-30/evidence').glob('*.tar.gz'))
rows=[];max_stored_delta=0.
with tarfile.open(a) as tar:
 def read(name):return tar.extractfile('attempt01/geometry/'+name).read()
 evaluation=json.loads(read('evaluator_only.json'));old=json.loads(read('evaluation.json'))
 for frame in evaluation:
  i=frame['index'];response=json.loads(read(f'{i:03d}-response.json'));c=response['camera'];depth=np.load(io.BytesIO(read(f'{i:03d}-depth.npy')),allow_pickle=False)
  pitch,yaw=map(math.radians,(c['pitch_degrees'],c['yaw_degrees']))
  rx=np.array([[1,0,0],[0,math.cos(pitch),-math.sin(pitch)],[0,math.sin(pitch),math.cos(pitch)]])
  ry=np.array([[math.cos(yaw),0,math.sin(yaw)],[0,1,0],[-math.sin(yaw),0,math.cos(yaw)]])
  f=c['height']/(2*math.tan(math.radians(c['vertical_fov_degrees'])/2));origin=np.array(c['position_m'])
  assert len(frame['rays'])==9
  for ray in frame['rays']:
   u,v=ray['pixel'];z=float(depth[v,u])*c['far_plane_m']/(c['far_plane_m']-c['near_plane_m'])
   local=z*np.array([(u+.5-c['width']/2)/f,-(v+.5-c['height']/2)/f,1.])
   predicted=origin+ry@rx@local;truth=np.array([ray['world'][k] for k in 'xyz']);direction=(truth-origin)/np.linalg.norm(truth-origin)
   delta=predicted-truth;parallel=float(delta@direction);perp=float(np.linalg.norm(delta-parallel*direction))
   prior=next(r for r in old['residuals'] if r['frame']==i and r['pixel']==ray['pixel']);max_stored_delta=max(max_stored_delta,float(np.max(np.abs(predicted-prior['corrected']))))
   rows.append(dict(frame=i,pixel=[u,v],error_m=float(np.linalg.norm(delta)),render_minus_collider_along_ray_m=parallel,perpendicular_m=perp))
assert len(rows)==54 and max_stored_delta<1e-12
result=dict(scope='ARCHIVE_RECOMPUTATION_NOT_NEW_CAPTURE_OR_CALIBRATION',archive_sha256=hashlib.sha256(a.read_bytes()).hexdigest(),public_inputs_used=['raw_depth','camera_self_pose','pinhole_intrinsics'],private_inputs_used_only_for_comparison=['saved_raycast_world'],rows=rows,max_difference_from_stored_projection_m=max_stored_delta,max_perpendicular_m=max(r['perpendicular_m'] for r in rows),outliers_over_1cm=[r for r in rows if r['error_m']>.01],not_independent_ground_truth_acceptance=True)
p=Path(__file__).parent/'geometry-recheck.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
