"""Same public Unity RGB-D boundary; complete instance masks stay evaluator-only."""

import json

import numpy as np
from unity_history_loop_worker import main
from unity_target_sequence_worker import TargetSequenceRecorder


class SurfacePipelineRecorder(TargetSequenceRecorder):
    def record(self, event, request, owner):
        super().record(event, request, owner)
        index = len(self.events) - 1
        ids = sorted(event.instance_masks)
        np.savez_compressed(
            self.private / "sdk-events" / f"{index:03d}-instances.npz",
            masks=np.asarray([event.instance_masks[k] for k in ids], dtype=bool),
        )
        (self.private / "sdk-events" / f"{index:03d}-instances.json").write_text(
            json.dumps(ids) + "\n"
        )


if __name__ == "__main__":
    main(SurfacePipelineRecorder)
