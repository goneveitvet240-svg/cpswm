import sys, pathlib, json, subprocess, os, hashlib, importlib.util
R=pathlib.Path('/private/tmp/cpswm-pc-a-unified-runtime-20260913'); O=pathlib.Path('/private/tmp/cpswm-unified-review2')
spec=importlib.util.spec_from_file_location('fixture_helpers',O/'fixture_helpers.py'); h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);h.ROOT=R
results={}
for name, defect in [('valid_delayed',None),('first_round_collision','duplicate_internal'),('late_bad_hash','late_bad_hash')]:
 case=O/name; case.mkdir(); repo,sha=h._archive(case,defect=defect); out=case/'out';p=h._run(repo,sha,out)
 results[name]={'code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'success_receipt':(out/'receipt.json').exists(),'json_files':len(list((out/'observations').glob('*.json')))}
 if p.returncode==0:
  receipt=json.loads((out/'receipt.json').read_text());results[name]['receipt']=receipt
  assert receipt['observation_count']==4 and len(receipt['output_manifest'])==8
  for x in receipt['output_manifest']:assert hashlib.sha256((out/x['file']).read_bytes()).hexdigest()==x['sha256']
case=O/'replacement';case.mkdir();repo,original=h._archive(case)
def git(*a,**kw):return subprocess.check_output(['git',*a],cwd=repo,text=True,**kw).strip()
original_journal=git('show',original+':case/schedule_run/observation_candidates/release_journal.json')
p=repo/'case/schedule_run/observation_candidates/release_journal.json';p.write_text(json.dumps([json.loads(p.read_text())[0]]))
git('add','.');git('-c','user.name=Probe','-c','user.email=probe@example.invalid','-c','commit.gpgsign=false','commit','-qm','Changed archive'); replacement=git('rev-parse','HEAD');git('replace',original,replacement)
out=case/'out';p=h._run(repo,original,out)
results['git_replace']={'original':original,'replacement':replacement,'code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'original_journal':original_journal,'git_actual_unreplaced_journal':git('--no-replace-objects','show',original+':case/schedule_run/observation_candidates/release_journal.json'),'success_receipt':(out/'receipt.json').exists()}
if (out/'receipt.json').exists():results['git_replace']['receipt']=json.loads((out/'receipt.json').read_text())
(O/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps({k:{p:v for p,v in x.items() if p not in ('receipt','stderr','original_journal','git_actual_unreplaced_journal')} for k,x in results.items()},indent=2))
