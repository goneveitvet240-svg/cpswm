import sys
from dataclasses import replace
from datetime import datetime
from zoneinfo import ZoneInfo
sys.path[:0]=['tests','src']
from test_interaction_evidence import frame
from cpswm.perception_mapping.interaction_evidence import CausalInstanceAssociator
f=frame(); zone=ZoneInfo('America/New_York')
c=datetime(2025,11,2,1,30,tzinfo=zone,fold=1)
a=datetime(2025,11,2,1,30,tzinfo=zone,fold=0)
bad=replace(f,capture_time=c,arrival_time=a,inference_cutoff=a)
r=CausalInstanceAssociator().update(bad,sequence_id='clip',media_time=0)
print('DST_REVERSED_TIME_ACCEPTED',c.timestamp()-a.timestamp(),r.observation_id)
n=datetime(2025,1,1)
r=CausalInstanceAssociator().update(replace(f,capture_time=n,arrival_time=n,inference_cutoff=n),sequence_id='clip',media_time=0)
print('NAIVE_TIMES_ACCEPTED',r.observation_id)
