from pathlib import Path
import subprocess,json,shlex,hashlib
import yaml
root=Path('/private/tmp/cpswm-pc-a-ci-failure-artifacts-20260930');out=Path(__file__).parent/'collection-shell-probe';out.mkdir(exist_ok=False)
raw=(root/'.github/workflows/ci.yml').read_bytes();wf=yaml.safe_load(raw)
step=next(s for s in wf['jobs']['test']['steps'] if s.get('name')=='Collect every test before starting the long regression')
command='uv run --frozen --extra dev --extra perception --extra hand-perception pytest --collect-only -q'
assert step['run'].count(command)==1
rows=[]
for name,child_code,expected,writer_fails in [('success',0,0,False),('collection_failure',3,3,False),('writer_failure',0,1,True)]:
 case=out/name;case.mkdir();dest=case/'artifacts'
 if writer_fails:(dest/'collection.log').mkdir(parents=True)
 fixture_command=shlex.join([str(root/'.venv/bin/python'),'-c',f'import sys;print("controlled collection stdout");sys.exit({child_code})'])
 body=step['run'].replace(command,fixture_command).replace('output/ci-regression',str(dest))
 script=case/'body.sh';script.write_text(body)
 r=subprocess.run(['/bin/bash','--noprofile','--norc','-eo','pipefail',str(script)],cwd=root,text=True,capture_output=True)
 (case/'stdout.log').write_text(r.stdout);(case/'stderr.log').write_text(r.stderr)
 saved=int((dest/'collection-exit-code.txt').read_text());assert r.returncode==saved==expected,(name,r)
 rows.append(dict(name=name,child_code=child_code,shell_exit=r.returncode,saved_exit=saved,writer_fails=writer_fails,source_sha=(dest/'source-sha.txt').read_text().strip()))
assert raw==(root/'.github/workflows/ci.yml').read_bytes()
(out/'result.json').write_text(json.dumps(dict(scope='CONTROLLED_SHELL_EXIT_PROPAGATION_NOT_FULL_REGRESSION',workflow_sha256=hashlib.sha256(raw).hexdigest(),cases=rows),indent=2)+'\n');print(rows)
