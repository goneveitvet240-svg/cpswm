import sys,json,collections,hashlib
from pathlib import Path
root=Path('/private/tmp/cpswm-pc-a-visual-support-20260930')
sys.path[:0]=[str(root/'src'),str(root/'tests'),str(root/'tools')]
from run_history_action_loop import load
from cpswm.system.joint_camera_feedback import JointObservationUpdate
out=Path(__file__).parent/'attempt01'
rows=[]
for kind in ('ssdlite','fasterrcnn'):
 d=out/(kind+'-north')
 support=load(d/'visual-support.json')
 frames=[f for a in support.actions for f in a.frames]
 states=collections.Counter(a.status for a in support.actions)
 before=load(d/'before-visual-support.json')
 prior_frames=[f for a in before.actions for f in a.frames]
 by_id={f.frame.observation_id:f for f in frames}
 assert all(by_id[f.frame.observation_id]==f for f in prior_frames)
 assert all(c.world_instance_id is c.world_position_m is c.orientation is c.probability is None
            for f in frames for c in f.candidates)
 view=load(d/'final-view.json')
 result=json.loads((d/'result.json').read_text())
 rows.append(dict(kind=kind,actions=result['executed_actions'],journal_statuses=dict(states),
  frame_count=len(frames),candidate_count=sum(len(f.candidates) for f in frames),
  categories=dict(collections.Counter(c.category for f in frames for c in f.candidates)),
  unique_pixels=len(set(f.identical_pixel_group for f in frames)),
  prior_observations_unchanged=len(prior_frames),
  native_origins=len(set(a.native_origin_sha256 for a in support.actions if a.frames)),
  final_unresolved=view.unresolved_probability,task_complete=False,
  calibration=False,automatic_world_identity=False,metric_pose=False,
  result=result,
  frames=[dict(observation_id=str(f.frame.observation_id),pixel_group=f.identical_pixel_group,
               candidates=[dict(id=str(c.candidate_id),category=c.category,score=c.detector_score_uncalibrated,
                                box=c.box_xyxy,image_position=c.normalized_box_xyxy) for c in f.candidates])
          for f in frames]))
summary=dict(source_head=json.loads((out/'source.json').read_text())['head'],histories=rows,
             status='ENGINEERING_READOUT_ONLY_NOT_NATURAL_JOINT_DENSITY')
(out/'support-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({r['kind']:{k:v for k,v in r.items() if k not in ('frames','result')} for r in rows},indent=2))
