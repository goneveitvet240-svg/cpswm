import sys,os,json,hashlib,importlib.util,subprocess
from pathlib import Path
ROOT=Path('/private/tmp/cpswm-pc-a-natural-vision-20260914')
sys.path.insert(0,str(ROOT/'src'))
base=Path('/private/tmp/cpswm-natural-vision-review1')
spec=importlib.util.spec_from_file_location('runner',ROOT/'tools/run_natural_vision_archive.py'); runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
os.chdir(base/'foreign')
a=base/'archive'

def invoke(archive,out):
 raw=(archive/'receipt.json').read_bytes()
 sys.argv=['runner','--archive',str(archive),'--manifest-sha256',hashlib.sha256(raw).hexdigest(),'--weights','/private/tmp/cpswm-natural-vision-models/ssdlite320_mobilenet_v3_large_coco-a79551df.pth','--output',str(base/out)]
 runner.main()
try:invoke(a,'closure_final_bad_output')
except ValueError as e: assert 'duplicate capture reference' in str(e); print('PASS duplicate capture rejected')
else: raise AssertionError('duplicate accepted')

clean=base/'closure_final_archive';clean.mkdir(exist_ok=True)
for name in ('rgb.json','rgb.npy'): (clean/name).write_bytes((a/name).read_bytes())
m=json.loads((a/'receipt.json').read_text());m['captures']=m['captures'][:1]
(clean/'receipt.json').write_text(json.dumps(m))
invoke(clean,'closure_final_output')
s=json.loads((base/'closure_final_output/summary.json').read_text())
expected=subprocess.check_output(['git','--no-replace-objects','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
assert s['source_sha']==expected=='6bb72386d588c82f0e264afa1dadd51306c1cada'
assert s['semantic_transitions']==0 and s['physical_actions']==0
print('PASS correct source SHA from foreign cwd; real detector invoked without semantic/action authority')

for name in ('rgb.json','rgb.npy'):
 p=clean/('dup'+Path(name).suffix);v=(clean/name).read_bytes();p.write_bytes(v)
 m['output_manifest'].append(dict(file=p.name,size_bytes=len(v),sha256=hashlib.sha256(v).hexdigest(),capture_ref='capture1'))
(clean/'receipt.json').write_text(json.dumps(m))
try:invoke(clean,'closure_final_dup_observation')
except ValueError as e:assert 'duplicate observation identity' in str(e);print('PASS duplicate observation under distinct files rejected')
else:raise AssertionError('duplicate observation accepted')
