def test_live():
 from cpswm import dependency_80d114da492b47088c15b5d25adca3ff
 assert dependency_80d114da492b47088c15b5d25adca3ff.VALUE == 9
