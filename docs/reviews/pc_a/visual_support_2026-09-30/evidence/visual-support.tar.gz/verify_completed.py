import sys,os,json,time,subprocess
from pathlib import Path
root=Path('/private/tmp/cpswm-pc-a-visual-support-20260930');main=Path('/Users/pangwei/Documents/ai/continual-personalized-semantic-world-model');out=Path(__file__).parent/'attempt01'
sys.path.insert(0,str(root/'docs/reviews/pc_a/neural_native_loop_2026-09-29'));from run_frozen import snapshot
source=json.loads((out/'source.json').read_text())['files'];records=[]
py=str(root/'.venv/bin/python');deadline=time.monotonic()+3600
env=dict(os.environ,PYTHONPATH='src:tests:tools',PYTHONHASHSEED='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
for name in ('ssdlite-north','fasterrcnn-north'):
 while True:
  try:rows=json.loads((out/'commands.json').read_text())
  except json.JSONDecodeError:rows=[]
  assert not any(r['exit_code'] for r in rows), 'run failed; do not continue review'
  if any(r['name']=='visual_run_'+name and r['exit_code']==0 for r in rows):break
  if time.monotonic()>deadline:raise TimeoutError(name)
  time.sleep(5)
 assert snapshot()==source
 cmd=[py,'-u','tools/history_visual_evidence.py','--mode','verify','--output',str(out/name),'--ssdlite-weights',str(main/'output/models/torchvision/ssdlite320_mobilenet_v3_large_coco-a79551df.pth'),'--fasterrcnn-weights',str(main/'output/models/torchvision/fasterrcnn_resnet50_fpn_v2_coco-dd69338a.pth'),'--checkpoint',str(root/'docs/reviews/pc_a/neural_native_loop_2026-09-29/evidence/development-checkpoints/typed_factor_graph_transformer/checkpoint')]
 start=time.monotonic()
 with (out/('fresh-'+name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 row=dict(name=name,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start,source_unchanged=snapshot()==source)
 records.append(row);(out/'fresh-verification-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert r.returncode==0 and row['source_unchanged']
