import sys, subprocess, os, json, time, argparse, shutil
from datetime import datetime, UTC
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path('/private/tmp/cpswm-pc-a-visual-support-20260930')
main=Path('/Users/pangwei/Documents/ai/continual-personalized-semantic-world-model')
sys.path.insert(0,str(root/'docs/reviews/pc_a/neural_native_loop_2026-09-29'))
from run_frozen import snapshot
p=argparse.ArgumentParser();p.add_argument('stage',choices=['reviews','run','verify']);p.add_argument('--attempt',default='attempt01');a=p.parse_args()
out=Path(__file__).parent/a.attempt
py=str(root/'.venv/bin/python');sdk=main/'.venv-ai2thor/bin/python'
ssd=main/'output/models/torchvision/ssdlite320_mobilenet_v3_large_coco-a79551df.pth'
faster=main/'output/models/torchvision/fasterrcnn_resnet50_fpn_v2_coco-dd69338a.pth'
checkpoint=root/'docs/reviews/pc_a/neural_native_loop_2026-09-29/evidence/development-checkpoints/typed_factor_graph_transformer/checkpoint'
binary=Path('/Users/pangwei/.ai2thor/releases/thor-OSXIntel64-f0825767cd50d69f666c7f282e54abfe58f1e917/thor-OSXIntel64-f0825767cd50d69f666c7f282e54abfe58f1e917.app/Contents/MacOS/AI2-THOR')
shared=['--sdk-python',str(sdk),'--binary',str(binary),'--weights',str(ssd),'--checkpoint',str(checkpoint)]
env=dict(os.environ,PYTHONPATH='src:tests:tools',PYTHONHASHSEED='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',CPSWM_SSDLITE_WEIGHTS=str(ssd),CPSWM_FASTERRCNN_WEIGHTS=str(faster))
source=snapshot();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
if a.stage=='reviews':
 out.mkdir(exist_ok=False)
 (out/'source.json').write_text(json.dumps(dict(head=head,files=source),indent=2)+'\n')
 pytest=[py,'-m','pytest','-o','addopts=','-q']
 changed=subprocess.check_output(['git','diff','--name-only','1d3538794b8b86d66414255f8d37f64d8ff0d88e','HEAD'],cwd=root,text=True).splitlines();changed=[n for n in changed if n.endswith('.py')]
 commands=[
 ('round1',pytest+['tests/test_owned_visual_support.py','tests/test_owned_visual_support_real.py','tests/test_joint_camera_feedback.py','tests/test_clarification_camera_model.py','tests/test_revised_camera_collection.py','tests/test_history_camera_worker.py','tests/test_continuous_camera_collection.py','--junitxml',str(out/'round1.xml')]),
 ('round2',pytest+['tests/test_instance_correspondence.py','tests/test_pixel_camera_detector_binding.py','tests/test_revised_camera_attacks.py','tests/test_history_reconstruction.py','tests/test_native_neural_recovery.py','tests/test_joint_camera_feedback_recovery.py','--junitxml',str(out/'round2.xml')]),
 ('mypy',[py,'-m','mypy','--no-incremental','src/cpswm/system/owned_visual_support.py','src/cpswm/system/structure_two_continuous_input.py']),
 ('ruff',[py,'-m','ruff','check',*changed]),
 ('ruff_format',[py,'-m','ruff','format','--check',*changed])]
 rows=[]
else:
 saved=json.loads((out/'source.json').read_text());assert saved['files']==source
 rows=json.loads((out/'commands.json').read_text())
 assert all(r['exit_code']==0 and r['source_unchanged'] for r in rows)
 assert all(any(r['name']==n for r in rows) for n in ('round1','round2','ruff','ruff_format'))
 commands=[]
 for kind,site in [('ssdlite','north'),('fasterrcnn','north')]:
  name=kind+'-'+site
  options=['--sdk-python',str(sdk),'--binary',str(binary),'--weights',str(ssd if kind=='ssdlite' else faster),'--checkpoint',str(checkpoint)]
  if a.stage=='run':
   commands.append(('run_'+name,[py,'-u','tools/run_history_action_loop.py','--mode','run','--site',site,'--task','clarification','--detector-kind',kind,'--output',str(out/name),*options]))
  commands.append(('visual_'+a.stage+'_'+name,[py,'-u','tools/history_visual_evidence.py','--mode',a.stage,'--output',str(out/name),'--ssdlite-weights',str(ssd),'--fasterrcnn-weights',str(faster),'--checkpoint',str(checkpoint)]))
 if a.stage=='run':
  runtime=Path(__file__).parent/'runtime_manifest.py'
  shutil.copyfile(main/'output/sim-timing-control-20260929/runtime_manifest.py',runtime)
  subprocess.run([str(sdk),str(runtime)],check=True)
  (out/'runtime-before.json').write_text((runtime.parent/'runtime-identity.json').read_text())
for name, command in commands:
 assert snapshot()==source
 start=time.monotonic();started=datetime.now(UTC).isoformat()
 with (out/(name+'.log')).open('w') as log:
  result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 row=dict(name=name,command=command,source_head=head,started_at=started,seconds=time.monotonic()-start,exit_code=result.returncode,source_unchanged=snapshot()==source)
 if name.startswith('round') and not row['exit_code']:
  suites=ET.parse(out/(name+'.xml')).getroot().iter('testsuite')
  row['tests']={k:0 for k in ('tests','failures','errors','skipped')}
  for suite in suites:
   for key in row['tests']:row['tests'][key]+=int(suite.attrib.get(key,0))
  assert row['tests']['tests'] and not any(row['tests'][k] for k in ('failures','errors','skipped'))
 rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if row['exit_code'] or not row['source_unchanged']:raise SystemExit(row['exit_code'] or 2)
if a.stage=='run':
 subprocess.run([str(sdk),str(runtime)],check=True)
 (out/'runtime-after.json').write_text((runtime.parent/'runtime-identity.json').read_text())
 before=json.loads((out/'runtime-before.json').read_text());after=json.loads((out/'runtime-after.json').read_text())
 before.pop('recorded_at');after.pop('recorded_at');assert before==after
 (out/'runtime-verification.json').write_text(json.dumps(dict(unchanged=True,sdk_files=len(after['sdk_sources']),unity_files=len(after['unity_bundle'])),indent=2)+'\n')
