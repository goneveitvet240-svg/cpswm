import os,sys,pathlib,subprocess,json,hashlib
R=pathlib.Path('/private/tmp/cpswm-pc-a-unified-runtime-20260913');O=pathlib.Path('/private/tmp/cpswm-unified-review1');repo=O/'fixture_repo';sys.path.insert(0,str(R/'tests'));sys.path.insert(0,str(R/'src'))
from test_structure_two_raw_rgbd_ingress import call, IDENTITY
from uuid import uuid4
base=call();results={}
for key,value in [('sensor_id','different-camera'),('frame_id','different-frame'),('session_id',uuid4()),('household_id',uuid4()),('trace_id',uuid4())]:
 rows=call(**{key:value});results[key]={'same_ids':[r.envelope().identity.observation_id for r in rows]==[r.envelope().identity.observation_id for r in base]}
raw=repo/'case/schedule_run/evaluator_only/raw/observations';r=json.loads((raw/'000001.json').read_text());r['step_index']=1;r['sensor_file']='000001.npz';r['sensor_sha256']='0'*64;(raw/'000001.json').write_text(json.dumps(r))
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
git('add','.');git('commit','-qm','Second capture invalid after valid first');sha=git('rev-parse','HEAD'); env=os.environ.copy();env['PYTHONPATH']=str(R/'src')
p=subprocess.run([str(R/'.venv/bin/python'),str(R/'tools/structure_two_rgbd_ingress_replay.py'),'--source-root',str(repo),'--source-sha',sha,'--run-path','case','--output',str(O/'partial_output')],env=env,text=True,capture_output=True)
results['partial_failure']={'returncode':p.returncode,'receipt_exists':(O/'partial_output/receipt.json').exists(),'observation_files':len(list((O/'partial_output/observations').glob('*'))),'stderr':p.stderr}
(O/'more_results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
