import sys
from datetime import timedelta
sys.path.insert(0, 'tests')
import test_structure_two_continuous_input as fx
import test_structure_two_formal_revision_lineage as old

p,s,b,t=fx.setup()
for d in p.observed_days()[:12]: fx.deliver(s,b,p.transition_for(d))
w=p.observed_days()[12].after.detection_time
rid=next(iter(p.system.core._committed_events))
f,bind,l=old._feedback(p,rid)
s.consume_feedback(feedback=f,binding=bind,likelihood_model=l,received_at=w,policy=old.RETRACTION_POLICY)
s.consume_feedback(feedback=f,binding=bind,likelihood_model=l,received_at=w+timedelta(hours=2),policy=old.RETRACTION_POLICY)
try:
 s.admit((fx.raw_for(t),),received_at=w+timedelta(hours=1))
 print('DUPLICATE_FEEDBACK_BACKDATED_ADMISSION_ACCEPTED')
except ValueError as e: print('rejected',e)

p,s,b,t=fx.setup(); fx.deliver(s,b,t)
w=t.after.detection_time+timedelta(seconds=2)
c=s.prepare_habit_placement(decision_time=w)
world=fx.FixtureWorldExecutor(t.after.metadata)
r=s.execute_placement(c,executor=world)
try:
 c2=s.prepare_habit_placement(decision_time=w)
 print('NEXT_DECISION_BEFORE_RECEIVED_EXECUTION_END_ACCEPTED',r.feedback_json,c2.decision_time)
except ValueError as e: print('rejected',e)

# Full semantically fabricated producer output remains accepted because producer is trusted.
p,s,b,t=fx.setup(); r=fx.deliver(s,b,t)
print('SYNTHETIC_ZERO_PIXELS_WITH_TRUSTED_PRECOMPUTED_SEMANTICS',r.status, len(r.result.event_history.latest.hypotheses))

# Trace-sink failure must not leave partial core mutation and retry should work.
p,s,b,t=fx.setup(); before=p.system.core.current_snapshot
original=s._trace_journal.commit
def broken(trace): raise OSError('independent sink failure')
s._trace_journal.commit=broken
try: fx.deliver(s,b,t)
except OSError: pass
print('ROLLBACK_AFTER_TRACE_FAILURE',p.system.core.current_snapshot==before,len(s.execution_traces()))
s._trace_journal.commit=original
r=s.advance(cutoff=t.after.detection_time+timedelta(seconds=1))
print('RETRY_AFTER_TRACE_FAILURE',r.status,len(s.execution_traces()))
