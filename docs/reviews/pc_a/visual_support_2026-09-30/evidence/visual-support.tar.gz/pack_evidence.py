from pathlib import Path
import json,hashlib,tarfile,io
out=Path(__file__).parent
repo=Path('/private/tmp/cpswm-pc-a-visual-support-20260930')
dest=repo/'docs/reviews/pc_a/visual_support_2026-09-30/evidence'
dest.mkdir(parents=True,exist_ok=True)
rows=[]
for p in sorted(out.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts or '.mpl-cache' in p.parts: continue
 if p.name in {'REPORT.md','REVIEWS.md','REPRODUCE.md','NEXT_STEP.md','pr-body.md','delivery.json'}: continue
 b=p.read_bytes(); rows.append(dict(path=str(p.relative_to(out)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
archive=dest/'visual-support.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for row in rows:tar.add(out/row['path'],arcname=row['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 assert {m.name for m in tar.getmembers()}=={r['path'] for r in rows}
 for row in rows:
  b=tar.extractfile(row['path']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
(dest/'inventory.json').write_text(json.dumps(rows,indent=2)+'\n')
result=dict(source_head=json.loads((out/'attempt01/source.json').read_text())['head'],files=len(rows),raw_bytes=sum(r['bytes'] for r in rows),compressed_bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),all_files_readback_verified=True)
(dest/'archive.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
