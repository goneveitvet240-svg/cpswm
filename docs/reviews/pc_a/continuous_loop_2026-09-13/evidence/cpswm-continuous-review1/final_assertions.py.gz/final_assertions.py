import sys
from datetime import timedelta
sys.path.insert(0,'tests')
import test_structure_two_continuous_input as fx
import test_structure_two_formal_revision_lineage as old

def reject(call, word):
 try: call()
 except ValueError as e: assert word in str(e), str(e)
 else: raise AssertionError('expected rejection')

p,s,b,t=fx.setup()
for day in p.observed_days()[:12]: fx.deliver(s,b,p.transition_for(day))
w=p.observed_days()[12].after.detection_time
f,bind,l=old._feedback(p,next(iter(p.system.core._committed_events)))
kw=dict(feedback=f,binding=bind,likelihood_model=l,policy=old.RETRACTION_POLICY)
r=s.consume_feedback(**kw,received_at=w)
state=p.system.core.current_snapshot
assert s.consume_feedback(**kw,received_at=w+timedelta(hours=2)) == r
assert p.system.core.current_snapshot == state
reject(lambda:s.admit((fx.raw_for(t),),received_at=w+timedelta(hours=1)),'backwards')
print('PASS duplicate watermark and idempotence')

p,s,b,t=fx.setup(); fx.deliver(s,b,t)
w=t.after.detection_time+timedelta(seconds=2)
c1=s.prepare_habit_placement(decision_time=w)
c2=s.prepare_habit_placement(decision_time=w)
world=fx.FixtureWorldExecutor(t.after.metadata)
s.execute_placement(c1,executor=world)
reject(lambda:s.prepare_habit_placement(decision_time=w),'predates')
reject(lambda:s.execute_placement(c2,executor=world),'predates')
assert world.calls == 1
c3=s.prepare_habit_placement(decision_time=w+timedelta(seconds=2))
s.execute_placement(c3,executor=world)
assert world.calls == 2
print('PASS completed execution watermark, stale preissued command, legal continuation')

p,s,b,t=fx.setup(); before=p.system.core.current_snapshot
saved=s._trace_journal.commit
def broken(trace): raise OSError('review1 injected write failure')
s._trace_journal.commit=broken
try: fx.deliver(s,b,t)
except OSError: pass
else: raise AssertionError('expected failure')
assert p.system.core.current_snapshot == before
assert len(s.execution_traces()) == 0
s._trace_journal.commit=saved
r=s.advance(cutoff=t.after.detection_time+timedelta(seconds=1))
assert r.status=='PRODUCTION_TRANSITION_COMMITTED'
assert len(s.execution_traces())==1
print('PASS trace failure rollback and legal retry')
