from pathlib import Path
import json,subprocess,sys
o=Path(__file__).resolve().parent
rows=json.loads((o/"failure-triage.json").read_text())["rows"]
nodes=[r["nodeid"] for r in rows if r["status"]=="open"]
assert len(nodes)==27
raise SystemExit(subprocess.call([sys.executable,str(o/"run_check.py"),"remaining27-reproduction",sys.executable,"-m","pytest","-o","addopts=","-q",*nodes]))
