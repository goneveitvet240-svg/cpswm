import os,subprocess,time,json,sys
from pathlib import Path
out=Path(__file__).resolve().parent
root=Path("/private/tmp/cpswm-pc-a-engineering-regressions-20261001")
cmd=[sys.executable,"-m","pytest","-c",str(root/"pyproject.toml"),"-o","addopts=","-q",str(root/"tests/test_native_raw_candidate_verification.py")+"::test_fresh_process_resume_without_constructing_another_stream",str(root/"tests/test_native_raw_candidate_verification.py")+"::test_non_neural_collection_keeps_torch_optional"]
env=dict(os.environ,PYTHONPATH=os.pathsep.join([str(out/"poison"),str(root/"src")]),OMP_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1")
start=time.monotonic()
with (out/"review2-foreign.log").open("w") as f: result=subprocess.run(cmd,cwd=out/"foreign-cwd",env=env,stdout=f,stderr=subprocess.STDOUT)
(out/"review2-foreign.json").write_text(json.dumps({"argv":cmd,"cwd":str(out/"foreign-cwd"),"PYTHONPATH":env["PYTHONPATH"],"exit_code":result.returncode,"elapsed_seconds":time.monotonic()-start},indent=2)+"\n")
print(result.returncode)
raise SystemExit(result.returncode)
