from pathlib import Path
import sys,hashlib,json,tarfile,stat
from datetime import datetime,UTC
out=Path(sys.argv[1]);dest=Path(sys.argv[2]);source=sys.argv[3];dest.mkdir(parents=True,exist_ok=True)
rows=[]
for p in sorted(out.rglob('*')):
 if any(x in ('__pycache__','.pytest_cache') for x in p.relative_to(out).parts) or not stat.S_ISREG(p.lstat().st_mode):continue
 b=p.read_bytes();rows.append(dict(path=p.relative_to(out).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
a=dest/'evidence.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as tar:
 for r in rows:tar.add(out/r['path'],arcname=r['path'],recursive=False)
with tarfile.open(a,'r:gz') as tar:
 assert [m.name for m in tar.getmembers()]==[r['path'] for r in rows]
 for r in rows:
  b=tar.extractfile(r['path']).read();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
meta=dict(actual_source=source,created_at=datetime.now(UTC).isoformat(),files=len(rows),raw_bytes=sum(r['bytes'] for r in rows),compressed_bytes=a.stat().st_size,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),full_member_readback=True,not_independent_custody=True)
(dest/'inventory.json').write_text(json.dumps(rows,indent=2)+'\n');(dest/'archive.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
