import sys,subprocess,json,os,time,shutil,tempfile
from pathlib import Path
from dataclasses import replace
from uuid import uuid5
root=Path('/private/tmp/cpswm-pc-a-visual-support-20260930')
main=Path('/Users/pangwei/Documents/ai/continual-personalized-semantic-world-model')
out=Path(__file__).parent/'attempt01'
sys.path[:0]=[str(root/'src'),str(root/'tests'),str(root/'tools')]
from run_history_action_loop import load,save
from cpswm.system.owned_visual_support import _frame_support
from cpswm.system.structure_two_continuous_input import ObservationDelivery
original=out/'fasterrcnn-north'
assert any(r['name']=='visual_run_fasterrcnn-north' and r['exit_code']==0 for r in json.loads((out/'commands.json').read_text()))
with tempfile.TemporaryDirectory(prefix='owned-support-forged-') as folder:
 target=Path(folder)/'history';shutil.copytree(original,target)
 support=load(target/'visual-support.json')
 histories={c.action_id:d for c,d in load(target/'owned-history.json') if type(d) is ObservationDelivery}
 actions=list(support.actions)
 index=next(i for i,a in enumerate(actions) if a.frames and a.frames[0].candidates)
 action=actions[index];frame=action.frames[0]
 old=frame.frame.candidates[0]
 fake_candidate=replace(old,candidate_id=uuid5(frame.frame.observation_id,'forged-consistent-positive'),category='apple',detector_score=.999999)
 fake_frame=replace(frame.frame,candidates=(fake_candidate,))
 raw=histories[action.command.action_id].observations[0]
 fake_support=_frame_support(raw,fake_frame,fake_frame.inference_cutoff)
 actions[index]=replace(action,frames=(fake_support,))
 save(target/'visual-support.json',replace(support,actions=tuple(actions)))
 cmd=[str(root/'.venv/bin/python'),'-u','tools/run_history_action_loop.py','--mode','verify','--output',str(target),'--site','north','--task','clarification','--detector-kind','fasterrcnn','--sdk-python',str(main/'.venv-ai2thor/bin/python'),'--binary','/Users/pangwei/.ai2thor/releases/thor-OSXIntel64-f0825767cd50d69f666c7f282e54abfe58f1e917/thor-OSXIntel64-f0825767cd50d69f666c7f282e54abfe58f1e917.app/Contents/MacOS/AI2-THOR','--weights',str(main/'output/models/torchvision/fasterrcnn_resnet50_fpn_v2_coco-dd69338a.pth'),'--checkpoint',str(root/'docs/reviews/pc_a/neural_native_loop_2026-09-29/evidence/development-checkpoints/typed_factor_graph_transformer/checkpoint')]
 env=dict(os.environ,PYTHONPATH='src:tests:tools',PYTHONHASHSEED='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
 start=time.monotonic()
 with (out/'forged-support-attack.log').open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 text=(out/'forged-support-attack.log').read_text()
 rejected=r.returncode!=0 and 'fresh owned visual support differs' in text
 result=dict(command=cmd,exit_code=r.returncode,expected_error='fresh owned visual support differs',rejected=rejected,seconds=time.monotonic()-start,attack='complete positive frame and rebuilt derived candidates in full archive copy',original_untouched=True)
 (out/'forged-support-attack.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
 assert rejected
