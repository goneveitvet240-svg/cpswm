import os,sys,subprocess,json,time
from pathlib import Path
o=Path(__file__).resolve().parent; root=Path("/private/tmp/cpswm-pc-a-current-validation-inputs-20261001")
rows=[]
for name,value,reason in [("empty","","explicit current scientific-loop path is empty"),("missing",str(o/"does-not-exist.json"),"FileNotFoundError"),("historical",str(root/"benchmarks/structure_two/structure_two_full_scientific_loop_v0_2.json"),"production assembly manifest mismatch")]:
 cmd=[sys.executable,"-m","pytest","-o","addopts=","-q","tests/test_structure_two_full_scientific_loop.py::test_interactions_are_learned_then_frozen_before_evaluation"]
 start=time.monotonic()
 proc=subprocess.run(cmd,cwd=root,env=dict(os.environ,S2_CURRENT_FULL_SCIENTIFIC_LOOP=value),capture_output=True,text=True)
 log=proc.stdout+proc.stderr;(o/("review2-attempt3-input-"+name+".log")).write_text(log)
 row=dict(case=name,argv=cmd,input=value,exit_code=proc.returncode,expected_reason=reason,reason_present=reason in log,seconds=time.monotonic()-start);rows.append(row)
 assert proc.returncode==1 and reason in log, row
(o/"review2-attempt3-explicit-inputs.json").write_text(json.dumps(rows,indent=2)+"\n")
print("3 explicit invalid inputs rejected; original pytest ERROR logs retained")
