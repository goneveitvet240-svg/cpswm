def test_foreign():
 import importlib.util, sys
 spec=importlib.util.spec_from_file_location('pytest', '/private/tmp/cpswm-r6-runtime85-final/test_real_foreign_module_loade1/pytest.py')
 loaded=importlib.util.module_from_spec(spec)
 spec.loader.exec_module(loaded)
 sys.modules['pytest']=loaded
 assert loaded.VALUE == 99
