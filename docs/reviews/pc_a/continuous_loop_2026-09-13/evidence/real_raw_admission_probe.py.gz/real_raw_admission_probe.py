"""Real archive admission probe only; does not manufacture semantic evidence."""
import hashlib,json,sys
from pathlib import Path
from uuid import UUID
from cpswm.perception_mapping.adapters.rgbd_capture import RawModalityObservation
from cpswm.perception_mapping.adapters.contracts import ObservationEnvelope
from cpswm.system.structure_two_continuous_input import ContinuousEvidenceInput
from cpswm.system.structure_two_production_system import StructureTwoProductionSystem
root=Path(sys.argv[1] if len(sys.argv)>1 else '/private/tmp/cpswm-unified-evidence/real_ingress_payload_03')
manifest_bytes=(root/'receipt.json').read_bytes()
manifest=json.loads(manifest_bytes)
for entry in manifest['output_manifest']:
    raw=(root/entry['file']).read_bytes()
    assert len(raw)==entry['size_bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
raws=[]
captures={row['capture_ref']:row for row in manifest['captures']}
for entry in manifest['output_manifest']:
    if not entry['file'].endswith('.json'):continue
    path=root/entry['file'];body=path.read_text();env=ObservationEnvelope.model_validate_json(body)
    raws.append(RawModalityObservation(body,path.with_suffix('.npy').read_bytes(),captures[entry['capture_ref']]['source_receipt_sha256'],'m' if env.sensor.modality.value=='depth' else None))
meta=raws[0].envelope().metadata
# Bookkeeping scope only: no producer is installed, no detection, object binding,
# owner inference or memory update is produced from these construction values.
system=StructureTwoProductionSystem(owner_key='raw-admission-only-unresolved',object_instance_id=UUID(int=0),locations=(UUID(int=1),UUID(int=2)),authorization_scope_id=UUID(int=3))
stream=ContinuousEvidenceInput(system=system,execution_lane="legacy_component_diagnostic",household_id=meta.household_id,session_id=meta.session_id,trace_id=meta.trace_id)
before=system.core.current_snapshot
for raw in raws:
    stream.admit((raw,),received_at=raw.envelope().arrival_time)
cutoff=max(raw.envelope().arrival_time for raw in raws)
assert len(stream.visible_prefix(cutoff=cutoff))==72
try:stream.advance(cutoff=cutoff)
except RuntimeError as error:
    assert 'PERCEPTION_PRODUCER_UNAVAILABLE' in str(error)
    rejection=str(error)
else:raise AssertionError('missing detector fabricated inference')
assert system.core.current_snapshot==before and not stream.execution_traces()
print(json.dumps({'manifest_sha256':hashlib.sha256(manifest_bytes).hexdigest(),'sensor_archive_source_sha':manifest['source_sha'],'verified_files':len(manifest['output_manifest']),'admitted_raw_observations':72,'semantic_transitions':0,'new_simulator_run':False,'physical_actions':0,'status':'RAW_ADMITTED_SEMANTIC_CAPABILITY_MISSING','expected_rejection':rejection},indent=2))
