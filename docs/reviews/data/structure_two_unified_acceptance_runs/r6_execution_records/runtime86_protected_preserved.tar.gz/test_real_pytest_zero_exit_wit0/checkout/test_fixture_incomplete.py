import pytest
def test_fixture_incomplete():
    pytest.skip('fixture skip')
