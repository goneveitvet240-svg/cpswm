def test_live():
 import dependency_9bb3e778cc4a460e9e2e00d263d28c4c
 assert dependency_9bb3e778cc4a460e9e2e00d263d28c4c.VALUE == 9
