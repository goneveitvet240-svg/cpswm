from pathlib import Path
import importlib.util,json,subprocess,sys
root=Path(sys.argv[1]);out=Path(sys.argv[2]);source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
p=root/'apps/evaluation_runner/run_structure_two_engineering_audit_receipt.py';s=importlib.util.spec_from_file_location('invocation_probe',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
argv=('.venv/bin/python','-I','-c','import json,sys;print(json.dumps({"prefix":sys.prefix,"base_prefix":sys.base_prefix}))')
reported=m._tool_version(argv,repository_root=root)
actual=subprocess.run([str(root/argv[0]),*argv[1:]],cwd=root,check=True,text=True,capture_output=True)
a=json.loads(reported['version']);b=json.loads(actual.stdout)
result=dict(source=source,declared_argv=argv,tool_version_path=reported,direct_invocation=b,semantic_equal=a==b,expected_virtual_environment=str(root/'.venv'),scientific_acceptance=False)
assert Path(b['prefix']).resolve()==(root/'.venv').resolve()
out.write_text(json.dumps(result,indent=2)+'\n');print({'semantic_equal':a==b,'tool_version_prefix':a['prefix'],'direct_prefix':b['prefix']})
