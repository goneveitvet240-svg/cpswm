"""Reconcile collected nodes with terminal JUnit records; never authenticate execution."""
from pathlib import Path
from collections import Counter,defaultdict
import json,re,sys,xml.etree.ElementTree as ET
root=Path(sys.argv[1]);out=Path(sys.argv[2])
def unique(pattern):
 paths=list(root.rglob(pattern))
 if len(paths)!=1:raise ValueError(f'unique {pattern} required: {paths}')
 return paths[0]
lines=unique('collection.log').read_text().splitlines();result=json.loads(unique('result.json').read_text());nodes=[s.strip() for s in lines if s.startswith('tests/') and '::' in s]
file_counts={m.group(1):int(m.group(2)) for line in lines if (m:=re.fullmatch(r'(tests/[^:]+\.py): (\d+)',line.strip()))}
expected=len(nodes) if nodes else sum(file_counts.values());by_key=defaultdict(list)
for node in nodes:
 file,rest=node.split('::',1);prefix,sep,params=rest.partition('[');parts=prefix.split('::');key=(file.removesuffix('.py').replace('/','.')+('.'+'.'.join(parts[:-1]) if len(parts)>1 else ''),parts[-1]+(sep+params if sep else ''));by_key[key].append(node)
rows=[];seen=Counter()
for case in ET.parse(unique('pytest.xml')).getroot().iter('testcase'):
 key=(case.attrib.get('classname'),case.attrib.get('name'));ids=by_key.get(key,[])
 if len(ids)==1:seen.update(ids)
 status,detail=('passed','') if all(key) else ('unidentified','no test identity')
 for tag in ('error','failure','skipped'):
  part=case.find(tag)
  if part is not None:status='xfailed' if tag=='skipped' and part.attrib.get('type')=='pytest.xfail' else tag;detail=part.attrib.get('message','');break
 rows.append(dict(key=key,nodeids=ids,status=status,message=detail,seconds=float(case.attrib.get('time','0'))))
source_after=root/'source-after.json';source=json.loads(source_after.read_text()) if source_after.exists() else None
summary=dict(scope='EXECUTION_RECONCILIATION_NOT_SCIENTIFIC_ACCEPTANCE',runner_result=result,source_after=source,collection_node_count=expected,collection_granularity='nodeids' if nodes else 'file_counts_only',collection_file_counts=file_counts,junit_records=len(rows),named_junit_records=sum(all(r['key']) for r in rows),outcomes=dict(Counter(r['status'] for r in rows)),missing_nodes=sorted(set(nodes)-set(seen)),multiple_junit_records={n:c for n,c in seen.items() if c!=1},unmatched_or_ambiguous_junit=[r for r in rows if len(r['nodeids'])!=1] if nodes else [],missing_count_at_least=max(0,expected-sum(all(r['key']) for r in rows)),failures=[r for r in rows if r['status'] in ('error','failure')],skips_or_xfails=[r for r in rows if r['status'] in ('skipped','xfailed')],slowest_cases=sorted(rows,key=lambda r:r['seconds'],reverse=True)[:30])
complete=bool(nodes) and len(nodes)==len(set(nodes)) and not any(summary[k] for k in ('missing_nodes','multiple_junit_records','unmatched_or_ambiguous_junit'))
summary['all_nodes_have_one_terminal_result']=complete
summary['unexpected_failure_free']=complete and result['exit_code']==0 and not summary['failures'] and bool(source and source['source_unchanged'])
summary['strict_all_nodes_passed']=summary['unexpected_failure_free'] and all(r['status']=='passed' for r in rows)
out.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:summary[k] for k in ('collection_node_count','junit_records','outcomes','all_nodes_have_one_terminal_result','unexpected_failure_free','strict_all_nodes_passed')},indent=2))
