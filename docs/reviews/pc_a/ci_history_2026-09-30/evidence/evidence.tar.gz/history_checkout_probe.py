from pathlib import Path
import subprocess,json,hashlib,sys
from datetime import datetime,UTC
from cpswm.system.evaluation_operations.structure_two_evidence_versions import historical_entries,verify_historical_record,HISTORY_CONFIG
root=Path('/private/tmp/cpswm-pc-a-ci-history-20260930');clone=Path('/private/tmp/cpswm-ci-history-isolation-20260930');out=Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not clone.exists()
def git(*args,cwd=clone):
 r=subprocess.run(['git',*args],cwd=cwd,text=True,capture_output=True);return r
r=git('clone','--no-checkout','--depth','1','--single-branch','--branch','codex/pc-a-ci-history-20260930','file://'+str(root),str(clone),cwd=root);assert r.returncode==0,r.stderr
(out/'clone.log').write_text(r.stdout+r.stderr)
paths=[HISTORY_CONFIG.as_posix()]+[e['path'] for e in historical_entries(root)]
for n in paths:
 p=clone/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show','HEAD:'+n],cwd=clone))
def hashes():return {n:hashlib.sha256((clone/n).read_bytes()).hexdigest() for n in paths}
rows=[];before=hashes()
assert git('rev-parse','HEAD').stdout.strip()==head
assert git('rev-parse','--is-shallow-repository').stdout.strip()=='true'
try:historical_entries(clone)
except subprocess.CalledProcessError as e:rows.append(dict(case='depth1_real_history_entry',accepted=False,error=str(e)))
else:raise AssertionError('shallow history unexpectedly accepted')
r=git('fetch','--unshallow','origin');(out/'unshallow.log').write_text(r.stdout+r.stderr);assert r.returncode==0
assert git('rev-parse','HEAD').stdout.strip()==head and hashes()==before
entries=historical_entries(clone);verified=[verify_historical_record(clone,e) for e in entries];assert len(verified)==11
rows.append(dict(case='complete_history_same_head_same_bytes',accepted=True,records=verified))
# A complete JSON record with recalculated content hash still cannot replace pinned bytes.
e=entries[0];p=clone/e['path'];original=p.read_bytes();payload=json.loads(original)
from cpswm.system.reproducibility import content_sha256
payload['test_episode_metrics'][0]['put_back_errors']+=1
payload['content_sha256']=content_sha256({k:v for k,v in payload.items() if k!='content_sha256'})
p.write_text(json.dumps(payload,indent=2)+'\n')
try:
 try:verify_historical_record(clone,e)
 except ValueError as error:
  assert 'differs from pinned Git' in str(error);rows.append(dict(case='complete_rehashed_numeric_record',accepted=False,error=str(error),forged_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 else:raise AssertionError('forged record accepted')
finally:p.write_bytes(original)
assert hashes()==before
result=dict(scope='LOCAL_ISOLATED_GIT_CAUSAL_DIAGNOSTIC_NOT_REMOTE_CI',actual_source=head,started_or_completed_at=datetime.now(UTC).isoformat(),materialized_hashes=before,source_and_materials_unchanged=True,rows=rows)
(out/'history-checkout-probe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
