def test_live():
 import dependency_8edcaeef20b84d238ccff477977909de
 assert dependency_8edcaeef20b84d238ccff477977909de.VALUE == 9
