"""Causal sensor delivery into the existing production memory/revision runtime.

This bridge owns arrival order and invokes a configured perception producer. It
never derives semantic evidence from evaluator metadata, raw hashes, or missing
pixels. The producer and calibrated feedback policy are trusted dependencies,
not authenticated by this module. No trained producer or physical executor is
bundled here; returned location suggestions are not execution receipts.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from copy import deepcopy
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from threading import RLock
from typing import TYPE_CHECKING, Any, Literal, Protocol, cast
from uuid import UUID, uuid4

from cpswm.contracts import (
    ActionOutcomeLikelihoodModel,
    DecisionContextBinding,
    EntityType,
    ExecutionFeedbackRecord,
    ObservationOpportunityRecord,
    RobotActionType,
    SourceType,
)
from cpswm.contracts.base import require_aware
from cpswm.perception_mapping.adapters.rgbd_capture import RawModalityObservation
from cpswm.system.continual.project_one_feedback import ExecutionFeedbackInterpretationPolicy
from cpswm.system.continuous_state_store import ContinuousStateStore
from cpswm.system.native_joint_production import (
    NativeJointContext,
    NativeJointProducer,
    NativeObservationUpdate,
    ProducedJointCandidates,
    producer_binding,
    producer_implementation_binding,
)
from cpswm.system.native_raw_verification import (
    RawCandidateAuthority,
    profile_for,
    raw_context_digest,
)
from cpswm.system.native_visual_source import NativeVisualAuthority, NativeVisualSource
from cpswm.system.owned_visual_support import (
    OwnedVisualSupport,
    VisualMeasurementDecoder,
    reconstruct_visual_support,
)
from cpswm.system.prototype_spine import (
    PrototypeRevisionResult,
    PrototypeStepResult,
    PrototypeTransition,
)
from cpswm.system.reproducibility import content_sha256
from cpswm.system.structure_two_adaptive_runtime import AdaptiveExecutionContext, AdaptiveStepResult
from cpswm.system.structure_two_execution import (
    StructureTwoExecutionTrace,
    TraceAbortAck,
    TraceCommitAck,
    canonical_legacy_ordinary_transition_plan,
    seal_trace_abort_ack,
    seal_trace_commit_ack,
    verify_execution_trace,
)
from cpswm.system.structure_two_particle_workspace import (
    NativePosteriorSource,
    native_content_sha256,
)
from cpswm.system.structure_two_production_system import StructureTwoProductionSystem
from cpswm.world_model.grounded_search import RealizedCIAVObservation

if TYPE_CHECKING:
    from cpswm.contracts.grounded_search import ActiveObservationPlan
    from cpswm.system.joint_camera_feedback import CameraOutcomeDecoder, JointObservationUpdate
    from cpswm.system.joint_camera_policy import JointCameraProblem
    from cpswm.system.structure_two_joint_consumption import JointDecisionView


def _utc(value: datetime) -> datetime:
    return require_aware(value, "causal time").astimezone(UTC)


@dataclass(frozen=True)
class GroundedTransition:
    """Producer output: evidence values plus exact visible source dependencies.

    Source IDs name the batch consumed by the producer, not a per-record proof.
    A producer must obtain opportunity propensities from its registered acquisition model,
    not infer them from whether an object was found. Hashes establish dependency
    identity only; they do not establish calibration or detector correctness.
    """

    transition: PrototypeTransition
    source_observation_ids: tuple[UUID, ...]
    producer_version: str
    calibration_id: str


class PerceptionProducer(Protocol):
    def checkpoint_state(self) -> dict[str, Any]: ...

    def restore_state(self, state: dict[str, Any]) -> None: ...

    def infer(
        self,
        visible_prefix: tuple[RawModalityObservation, ...],
        *,
        cutoff: datetime,
    ) -> GroundedTransition | None:
        """Return a new grounded transition, or None when evidence is insufficient.

        Inputs are immutable raw wire values, never simulator truth. Implementors
        must retain unknown actors/instances and use independent calibration.
        """
        ...


class _DurableCIAVRealizer:
    def __init__(
        self,
        store: ContinuousStateStore,
        effect_key: str,
        realizer: Callable[[ObservationOpportunityRecord], RealizedCIAVObservation],
    ) -> None:
        self.store = store
        self.effect_key = effect_key
        self.realizer = realizer

    def execute(self, opportunity: ObservationOpportunityRecord) -> RealizedCIAVObservation:
        return cast(
            RealizedCIAVObservation,
            self.store.execute_once(self.effect_key, opportunity, self.realizer),
        )


class _TraceJournal:
    """In-process trace retention, not independent custody or crash durability."""

    def __init__(self) -> None:
        self._traces: dict[UUID, str] = {}

    def commit(self, trace: StructureTwoExecutionTrace, /) -> TraceCommitAck:
        verify_execution_trace(trace)
        ack = seal_trace_commit_ack(trace)
        key = trace.runtime_execution_id
        value = trace.model_dump_json()
        if key in self._traces and self._traces[key] != value:
            raise ValueError("conflicting execution trace identity")
        self._traces[key] = value
        return ack

    def abort(self, trace: StructureTwoExecutionTrace, /, *, reason: str) -> TraceAbortAck:
        self._traces.pop(trace.runtime_execution_id, None)
        return seal_trace_abort_ack(trace, reason=reason)

    def values(self) -> tuple[StructureTwoExecutionTrace, ...]:
        return tuple(
            StructureTwoExecutionTrace.model_validate_json(x) for x in self._traces.values()
        )


@dataclass(frozen=True)
class DeliveryReceipt:
    source_ids: tuple[UUID, ...]
    source_prefix_sha256: str
    received_at: datetime
    status: str
    result: PrototypeStepResult | AdaptiveStepResult | None


@dataclass(frozen=True)
class ObservationCommand:
    action_id: UUID
    snapshot_id: UUID
    action: str
    degrees: float
    reason: str
    source_ids: tuple[UUID, ...]
    decision_time: datetime


@dataclass(frozen=True)
class ObservationDelivery:
    action_id: UUID
    observations: tuple[RawModalityObservation, ...]
    success: bool
    error: str
    received_at: datetime


@dataclass(frozen=True)
class PlacementCommand:
    """A single-use PUT_BACK command, never a SEARCH location belief."""

    action_id: UUID
    object_instance_id: UUID
    location_id: UUID
    snapshot_id: UUID
    distribution: tuple[tuple[UUID, float], ...]
    decision_time: datetime


@dataclass(frozen=True)
class PlacementFeedbackDelivery:
    feedback: ExecutionFeedbackRecord
    received_at: datetime


class ObservationExecutor(Protocol):
    def execute(self, command: ObservationCommand) -> ObservationDelivery: ...


class PlacementExecutor(Protocol):
    def execute(self, command: PlacementCommand) -> PlacementFeedbackDelivery:
        """Execute once and return observed feedback; do not invent success."""
        ...


@dataclass(frozen=True)
class PlacementDispatch:
    command: PlacementCommand
    status: str
    feedback_json: str | None
    received_at: datetime | None = None


class ContinuousEvidenceInput:
    """Serialize actual delivery, inference and late feedback on one live system.

    The registered P5-first or legacy diagnostic lane is selected explicitly.
    The P5 operator assembly still needs independently calibrated full-axis
    inputs; selecting it alone cannot authorize empirical acceptance.
    Raw admission can proceed without a perception producer; semantic
    advancement then raises rather than synthesizing a transition.
    """

    def __init__(
        self,
        *,
        system: StructureTwoProductionSystem,
        execution_lane: Literal["legacy_component_diagnostic", "registered_p5_first"],
        household_id: UUID,
        session_id: UUID,
        trace_id: UUID,
        producer: PerceptionProducer | None = None,
        context_builder: Callable[
            [StructureTwoProductionSystem, GroundedTransition, datetime, int],
            AdaptiveExecutionContext,
        ]
        | None = None,
        state_store: ContinuousStateStore | None = None,
        joint_producer: NativeJointProducer | None = None,
        observation_decoder: CameraOutcomeDecoder | None = None,
    ) -> None:
        if execution_lane not in {"legacy_component_diagnostic", "registered_p5_first"}:
            raise ValueError("unsupported continuous execution lane")
        if execution_lane == "registered_p5_first" and context_builder is None:
            raise ValueError("P5-first requires a configured calibrated context/CIAV builder")
        if state_store is not None and not state_store.empty:
            raise ValueError("existing continuous state must be resumed, not initialized again")
        self._execution_lane = execution_lane
        self._context_builder = context_builder
        self._state_store = state_store
        self._durability_failed = False
        self._checkpoint_suspended = False
        self._pending_step: dict[str, Any] | None = None
        self._system = system
        self._scope = (household_id, session_id, trace_id)
        self._producer = producer
        self._joint_producer = joint_producer
        self._joint_dependency_binding = producer_binding(joint_producer)
        self._joint_implementation_binding = producer_implementation_binding(joint_producer)
        self._joint_initial_state = (
            deepcopy(joint_producer.checkpoint_state()) if joint_producer is not None else None
        )
        self._joint_initial_state_sha256 = native_content_sha256(self._joint_initial_state)
        if self._joint_dependency_binding is not None:
            self._system.core.configure_native_joint_dependency(self._joint_dependency_binding)
        self._raw_candidate_authority = RawCandidateAuthority.create()
        raw_profile = profile_for(joint_producer)
        if raw_profile is not None:
            self._system.core.configure_native_raw_profile(
                raw_profile, authority=self._raw_candidate_authority
            )
        self._joint_published_batch_sha256: str | None = None
        self._joint_published_source_sha256: str | None = None
        from cpswm.system.joint_camera_feedback import decoder_binding

        self._observation_decoder = observation_decoder
        self._observation_decoder_binding = decoder_binding(observation_decoder)
        self._visual_authority = NativeVisualAuthority.create()
        self._joint_uses_visual_context = bool(
            getattr(joint_producer, "use_owned_visual_context", False)
        )
        if self._joint_uses_visual_context:
            if observation_decoder is None or not callable(
                getattr(observation_decoder, "measurements", None)
            ):
                raise ValueError("owned visual neural input requires a visual decoder")
            self._system.core._particle_workspace.bind_visual_owner(self._visual_authority)
        self._last_cutoff: datetime | None = None
        self._raw: dict[UUID, RawModalityObservation] = {}
        self._received: dict[UUID, datetime] = {}
        self._last_arrival: datetime | None = None
        self._advanced: dict[UUID, tuple[str, DeliveryReceipt]] = {}
        self._feedback: dict[UUID, tuple[str, PrototypeRevisionResult]] = {}
        self._trace_journal = _TraceJournal()
        self._commands: dict[UUID, PlacementCommand] = {}
        self._command_hashes: dict[UUID, str] = {}
        self._dispatches: dict[UUID, PlacementDispatch] = {}
        self._observation_commands: dict[UUID, tuple[ObservationCommand, str]] = {}
        self._observation_status: dict[UUID, str | ObservationDelivery] = {}
        # Captured by the owner at command issue, outside the caller's problem
        # body: disconnected current actions cannot masquerade as older epochs.
        self._observation_native_origins: dict[UUID, str] = {}
        self._position_consumptions: dict[UUID, NativeObservationUpdate] = {}
        self._position_withdrawals: dict[UUID, tuple[Any, ...]] = {}
        self._lock = RLock()
        self._busy = False
        self._persist()

    def _enter(self, *, resume_step: bool = False) -> None:
        if self._pending_step is not None and not resume_step:
            raise RuntimeError("pending P5 step must be resumed before other mutations")
        if self._durability_failed:
            raise RuntimeError("durable state failed; close and recover before continuing")
        if self._busy:
            raise RuntimeError("reentrant continuous input is forbidden")
        self._busy = True

    def _scope_check(self, metadata: object) -> None:
        scope = tuple(getattr(metadata, key) for key in ("household_id", "session_id", "trace_id"))
        if scope != self._scope:
            raise ValueError("cross-household/session/trace input")

    def admit(
        self, observations: tuple[RawModalityObservation, ...], *, received_at: datetime
    ) -> tuple[UUID, ...]:
        """Retain one atomic raw batch; late capture time is legal, backdating is not.

        The transport owns received_at. Replaying identical bytes does not change
        their original arrival or make previously unavailable evidence visible.
        """
        with self._lock:
            self._enter()
            try:
                when = _utc(received_at)
                if any(t is not None and when < t for t in (self._last_arrival, self._last_cutoff)):
                    raise ValueError("delivery order moved backwards")
                if not observations:
                    raise ValueError("empty sensor delivery")
                pending: dict[UUID, RawModalityObservation] = {}
                for raw in observations:
                    if (
                        type(raw) is not RawModalityObservation
                        or type(raw.payload_bytes) is not bytes
                    ):
                        raise ValueError("raw input must retain immutable bytes")
                    raw = deepcopy(raw)
                    envelope = raw.envelope()
                    if envelope.metadata.source_type not in {
                        SourceType.SENSOR,
                        SourceType.SIMULATION,
                        SourceType.IMPORT,
                    }:
                        raise ValueError("raw observations require a sensor or archive source")
                    self._scope_check(envelope.identity)
                    if envelope.oracle_channel:
                        raise ValueError("oracle data cannot enter the method stream")
                    if not _utc(envelope.capture_time) <= _utc(envelope.arrival_time) <= when:
                        raise ValueError("future capture or delivery timestamp")
                    key = envelope.identity.observation_id
                    if key in pending:
                        raise ValueError("duplicate observation within batch")
                    if key in self._raw and self._raw[key] != raw:
                        raise ValueError("observation identity reused with changed content")
                    pending[key] = raw
                for key, raw in pending.items():
                    if key not in self._raw:
                        self._raw[key] = raw
                        self._received[key] = when
                self._last_arrival = when
                self._persist()
                return tuple(pending)
            finally:
                self._busy = False

    def visible_prefix(self, *, cutoff: datetime) -> tuple[RawModalityObservation, ...]:
        with self._lock:
            when = _utc(cutoff)
            # Insertion order retains transport arrival order, not capture order.
            return tuple(
                deepcopy(raw) for key, raw in self._raw.items() if self._received[key] <= when
            )

    def advance(self, *, cutoff: datetime) -> DeliveryReceipt:
        with self._lock:
            self._enter(resume_step=True)
            producer_before = None
            try:
                if self._state_store is not None and self._producer is not None:
                    producer_before = self._producer.checkpoint_state()
                when = _utc(cutoff)
                if any(t is not None and when < t for t in (self._last_arrival, self._last_cutoff)):
                    raise ValueError("cannot revise live state with an earlier causal cutoff")
                if self._producer is None:
                    raise RuntimeError(
                        "PERCEPTION_PRODUCER_UNAVAILABLE: raw retained; no inference"
                    )
                prefix = self.visible_prefix(cutoff=when)
                if not prefix:
                    raise ValueError("no delivered sensor evidence")
                digest = content_sha256(
                    tuple((r.envelope_json, r.capture_receipt_sha256) for r in prefix)
                )
                if self._pending_step is not None:
                    if when != self._pending_step["cutoff"]:
                        raise ValueError("resume requires the pending P5 causal cutoff")
                    produced = self._pending_step["item"]
                else:
                    produced = self._producer.infer(prefix, cutoff=when)
                if produced is None:
                    self._admit_current_raw_context(cutoff=when, allow_no_source=True)
                    self._last_cutoff = when
                    self._persist()
                    return DeliveryReceipt((), digest, when, "INSUFFICIENT_SEMANTIC_EVIDENCE", None)
                item = deepcopy(produced)
                if not item.producer_version.strip() or not item.calibration_id.strip():
                    raise ValueError("perception producer and calibration must be named")
                ids = item.source_observation_ids
                available = {r.envelope().identity.observation_id for r in prefix}
                if not ids or len(set(ids)) != len(ids) or not set(ids) <= available:
                    raise ValueError("perception used missing, duplicate or undelivered source")
                transition = item.transition
                records = (
                    transition.opportunity,
                    transition.before,
                    transition.after,
                    *transition.evidence,
                )
                for record in records:
                    self._scope_check(record.metadata)
                    if _utc(record.metadata.recorded_time) > when:
                        raise ValueError("perception output contains a future record")
                if any(
                    t is not None and _utc(t) > when
                    for t in (
                        transition.before.detection_time,
                        transition.after.detection_time,
                        transition.opportunity.opportunity_time,
                    )
                ):
                    raise ValueError("future detection")
                input_hash = content_sha256(item)
                key = transition.after.metadata.record_id
                old = self._advanced.get(key)
                if old is not None:
                    if old[0] != input_hash:
                        raise ValueError("perception record identity reused with changed evidence")
                    self._admit_current_raw_context(cutoff=when, allow_no_source=True)
                    self._last_cutoff = when
                    self._persist()
                    return deepcopy(old[1])
                # The core handles hypotheses, propensity, cause/regime competition,
                # memory writes and rollback. No caller supplies a posterior here.
                result: PrototypeStepResult | AdaptiveStepResult
                if self._execution_lane == "registered_p5_first":
                    assert self._context_builder is not None
                    context = self._context_builder(self._system, item, when, len(self._advanced))
                    if context.step_index != len(self._advanced):
                        raise ValueError("context step is not the continuous history step")
                    if (
                        context.ciav_input is not None
                        and _utc(context.ciav_input.opportunity_time) > when
                    ):
                        raise ValueError("CIAV request is beyond this advance cutoff")
                    if self._state_store is not None:
                        assert context.ciav_input is not None
                        context_hash = content_sha256(
                            (
                                context.router_features,
                                context.step_index,
                                context.debt_expiry_steps,
                                context.ciav_input.content_sha256,
                            )
                        )
                        if self._pending_step is None:
                            self._pending_step = {
                                "item": item,
                                "cutoff": when,
                                "context_hash": context_hash,
                                "effect_key": content_sha256((self._scope, key, input_hash)),
                            }
                            self._persist()  # Core is still at the pre-step checkpoint.
                        elif self._pending_step["context_hash"] != context_hash:
                            raise ValueError("pending P5 execution dependencies changed")
                        durable = _DurableCIAVRealizer(
                            self._state_store,
                            self._pending_step["effect_key"],
                            context.ciav_input.realizer,
                        )
                        context = replace(
                            context,
                            ciav_input=replace(
                                context.ciav_input,
                                realizer=durable.execute,
                            ),
                        )
                    result = self._system.process_p5_first_transition(
                        transition, context=context, trace_sink=self._trace_journal
                    )
                else:
                    if self._state_store is not None and self._pending_step is None:
                        self._pending_step = {"item": item, "cutoff": when}
                        self._persist()
                    result = self._system.process_transition(
                        transition,
                        execution_plan=canonical_legacy_ordinary_transition_plan(),
                        trace_sink=self._trace_journal,
                    )
                receipt = DeliveryReceipt(
                    ids, digest, when, "PRODUCTION_TRANSITION_COMMITTED", deepcopy(result)
                )
                # A failed raw admission must retain the durable pending step.
                # P5 may already have run; this is fail-closed recovery, not an
                # assertion that an external/semantic action was rolled back.
                self._admit_current_raw_context(cutoff=when)
                self._advanced[key] = (input_hash, receipt)
                self._pending_step = None
                self._last_cutoff = when
                self._persist()
                return deepcopy(receipt)
            except BaseException:
                if self._pending_step is not None:
                    self._durability_failed = True
                elif producer_before is not None and not self._durability_failed:
                    assert self._producer is not None
                    self._producer.restore_state(producer_before)
                raise
            finally:
                self._busy = False

    def consume_feedback(
        self,
        *,
        feedback: ExecutionFeedbackRecord,
        binding: DecisionContextBinding,
        likelihood_model: ActionOutcomeLikelihoodModel,
        received_at: datetime,
        policy: ExecutionFeedbackInterpretationPolicy | None = None,
    ) -> PrototypeRevisionResult:
        """Consume delayed execution evidence against its original decision binding.

        Actual feedback and a calibrated likelihood are required. This method
        never turns a suggestion or raw capture into an execution-success record.
        The policy is a configured trusted dependency, not a learned policy here.
        """
        with self._lock:
            self._enter()
            try:
                when = _utc(received_at)
                if any(t is not None and when < t for t in (self._last_arrival, self._last_cutoff)):
                    raise ValueError("feedback arrival moved backwards")
                feedback = type(feedback).model_validate_json(feedback.model_dump_json())
                binding = type(binding).model_validate_json(binding.model_dump_json())
                likelihood_model = type(likelihood_model).model_validate_json(
                    likelihood_model.model_dump_json()
                )
                self._scope_check(feedback.metadata)
                if (
                    max(
                        _utc(feedback.metadata.recorded_time),
                        _utc(feedback.valid_time.start),
                        _utc(feedback.valid_time.end or feedback.valid_time.start),
                    )
                    > when
                ):
                    raise ValueError("feedback arrives before execution evidence exists")
                fingerprint = content_sha256((feedback, binding, likelihood_model))
                key = feedback.metadata.record_id
                previous = self._feedback.get(key)
                if previous:
                    if previous[0] != fingerprint:
                        raise ValueError("feedback identity reused with changed content")
                    self._last_arrival = when
                    self._persist()
                    return deepcopy(previous[1])
                result = self._system.core.process_execution_feedback(
                    feedback=feedback,
                    binding=binding,
                    likelihood_model=likelihood_model,
                    policy=policy,
                )
                self._feedback[key] = (fingerprint, deepcopy(result))
                self._last_arrival = when
                self._persist()
                return deepcopy(result)
            finally:
                self._busy = False

    def current_habit_location_distribution(self) -> Mapping[UUID, float]:
        """Fresh habitual-location readout; not a SEARCH physical-location belief."""
        with self._lock:
            return dict(
                self._system.core.action_location_distribution(self._system.core.current_snapshot)
            )

    def execution_traces(self) -> tuple[StructureTwoExecutionTrace, ...]:
        with self._lock:
            return self._trace_journal.values()

    def prepare_habit_placement(self, *, decision_time: datetime) -> PlacementCommand:
        """Select the existing habitual-location argmax with deterministic ties.

        This connects the current core readout to an explicit PUT_BACK command;
        it does not select a combined task utility or an autonomous task schedule.
        """
        with self._lock:
            self._enter()
            try:
                when = _utc(decision_time)
                if any(t is not None and when < t for t in (self._last_arrival, self._last_cutoff)):
                    raise ValueError("decision predates delivered evidence")
                self._require_resolved_dispatches()
                core = self._system.core
                snapshot = core.current_snapshot
                probabilities = tuple(
                    sorted(
                        core.action_location_distribution(snapshot).items(), key=lambda x: str(x[0])
                    )
                )
                location = max(probabilities, key=lambda x: x[1])[0]
                command = PlacementCommand(
                    uuid4(),
                    core.object_instance_id,
                    location,
                    snapshot.snapshot_id,
                    probabilities,
                    when,
                )
                self._commands[command.action_id] = command
                self._command_hashes[command.action_id] = content_sha256(command)
                self._last_cutoff = when
                self._persist()
                return command
            finally:
                self._busy = False

    def execute_placement(
        self, command: PlacementCommand, *, executor: PlacementExecutor
    ) -> PlacementDispatch:
        """Dispatch a live command once, with explicit uncertain-outcome handling.

        A raised call or malformed reply may still have moved the object. Retain
        OUTCOME_UNCERTAIN and never automatically retry or roll back that physical
        action. With a state store the intent is durable before dispatch; an
        uncertain transport outcome still requires a matching recovered receipt.
        """
        with self._lock:
            self._enter()
            try:
                if self._commands.get(command.action_id) is not command:
                    raise ValueError("placement command is not this session's issued capability")
                if self._command_hashes[command.action_id] != content_sha256(command):
                    raise ValueError("placement command content was changed after issue")
                if command.action_id in self._dispatches:
                    raise ValueError("placement already dispatched; reconcile instead of retrying")
                self._require_resolved_dispatches()
                core = self._system.core
                if command.snapshot_id != core.current_snapshot.snapshot_id:
                    raise ValueError("placement command is stale after a belief revision")
                if any(
                    t is not None and command.decision_time < t
                    for t in (self._last_arrival, self._last_cutoff)
                ):
                    raise ValueError("placement decision predates current evidence or decision")
                distribution = tuple(
                    sorted(
                        self.current_habit_location_distribution().items(), key=lambda x: str(x[0])
                    )
                )
                if distribution != command.distribution:
                    raise ValueError("placement readout changed since command issue")
                self._dispatches[command.action_id] = PlacementDispatch(
                    deepcopy(command), "OUTCOME_UNCERTAIN", None
                )
                self._persist()  # Durable intent BEFORE crossing the external side-effect boundary.
                # Do not expose the owned command or command journal to callback aliases.
                delivery = executor.execute(deepcopy(command))
                return self._accept_placement_delivery(command.action_id, delivery)
            finally:
                self._busy = False

    def placement_dispatches(self) -> tuple[PlacementDispatch, ...]:
        with self._lock:
            return deepcopy(tuple(self._dispatches.values()))

    def _require_resolved_dispatches(self) -> None:
        if any(v == "OUTCOME_UNCERTAIN" for v in self._observation_status.values()):
            raise RuntimeError("uncertain observation requires transport reconciliation")
        if any(r.status == "OUTCOME_UNCERTAIN" for r in self._dispatches.values()):
            raise RuntimeError(
                "uncertain placement requires reconciliation before another dispatch"
            )

    def _accept_placement_delivery(
        self, action_id: UUID, delivery: PlacementFeedbackDelivery
    ) -> PlacementDispatch:
        original = self._dispatches[action_id]
        command = original.command
        when = _utc(delivery.received_at)
        if any(t is not None and when < t for t in (self._last_arrival, self._last_cutoff)):
            raise ValueError("placement receipt arrival moved backwards")
        feedback = ExecutionFeedbackRecord.model_validate_json(delivery.feedback.model_dump_json())
        self._scope_check(feedback.metadata)
        if (
            feedback.action_id != command.action_id
            or feedback.action_type is not RobotActionType.PLACE
            or feedback.target_entity is None
            or feedback.target_entity.entity_id != command.object_instance_id
            or feedback.target_entity.entity_type is not EntityType.OBJECT_INSTANCE
            or feedback.metadata.source_type is not SourceType.ACTION
            or feedback.attempted_location_id != command.location_id
        ):
            raise ValueError("executor feedback does not describe the issued placement")
        start = _utc(feedback.valid_time.start)
        end = _utc(feedback.valid_time.end or feedback.valid_time.start)
        recorded = _utc(feedback.metadata.recorded_time)
        if not command.decision_time <= start <= end <= recorded <= when:
            raise ValueError("placement decision/execution/record/receipt times are inconsistent")
        value = feedback.model_dump_json()
        if original.status == "FEEDBACK_RECEIVED" and original.feedback_json != value:
            raise ValueError("conflicting feedback for an already reconciled placement")
        result = (
            original
            if original.status == "FEEDBACK_RECEIVED"
            else PlacementDispatch(deepcopy(command), "FEEDBACK_RECEIVED", value, when)
        )
        self._dispatches[action_id] = result
        self._last_arrival = when
        self._persist()
        return deepcopy(result)

    def reconcile_placement(
        self, action_id: UUID, delivery: PlacementFeedbackDelivery
    ) -> PlacementDispatch:
        """Accept a later original-action receipt without sending another command."""
        with self._lock:
            self._enter()
            try:
                if action_id not in self._dispatches:
                    raise ValueError("cannot reconcile an action this session never dispatched")
                return self._accept_placement_delivery(action_id, delivery)
            finally:
                self._busy = False

    def _joint_binding_matches(self, producer: NativeJointProducer | None) -> bool:
        return (
            producer_binding(producer) == self._joint_dependency_binding
            and producer_implementation_binding(producer) == self._joint_implementation_binding
        )

    def _current_joint_decision_view(self) -> JointDecisionView:
        return self._joint_decision_and_observation_updates()[0]

    def _check_observation_decoder(self) -> None:
        from cpswm.system.joint_camera_feedback import decoder_binding

        if decoder_binding(self._observation_decoder) != self._observation_decoder_binding:
            raise ValueError("configured camera decoder dependency changed")

    def _native_joint_decision_view(self) -> JointDecisionView:
        from cpswm.system.structure_two_joint_consumption import JointDecisionView

        core = self._system.core
        self._check_observation_decoder()
        if not self._joint_binding_matches(self._joint_producer):
            raise ValueError("joint producer dependency changed")
        if self._joint_producer is not None and (
            self._joint_published_batch_sha256 is None
            or self._joint_published_batch_sha256
            != native_content_sha256(core._particle_workspace.batch)
        ):
            raise ValueError("current batch was not published by the configured joint producer")
        if self._joint_producer is not None and (
            core.current_posterior_projection_source().body_sha256
            != self._joint_published_source_sha256
        ):
            raise ValueError("joint posterior source changed; production required")
        self._verify_native_visual_sources()
        self._verify_native_raw_sources()
        # Use the existing native consumer validation before exposing whole atoms.
        core.prepared_particle_location_marginal()
        batch = core._particle_workspace.batch
        if batch is None:
            raise ValueError("no current native joint posterior for observation policy")
        return JointDecisionView.from_batch(
            runtime_id=core._particle_workspace.runtime_id,
            expected_snapshot_id=core.current_snapshot.snapshot_id,
            batch=batch,
            records=core._particle_workspace.records,
        )

    def _joint_decision_and_observation_updates(
        self,
    ) -> tuple[JointDecisionView, tuple[JointObservationUpdate, ...]]:
        from cpswm.system.joint_camera_feedback import replay_camera_history

        view = self._native_joint_decision_view()
        from cpswm.system.owned_position_update import enabled

        if enabled(self):
            # Explicit position-only profile: never also multiply this image's
            # classification likelihood into the decision view.
            return view, ()
        if self._observation_decoder is None:
            return view, ()
        assert self._observation_decoder_binding is not None
        return replay_camera_history(
            view,
            commands=self._observation_commands,
            statuses=self._observation_status,
            native_origins=self._observation_native_origins,
            raw=self._raw,
            decoder=self._observation_decoder,
            expected_binding=self._observation_decoder_binding,
            planner=self._system.cause_information_planner,
        )

    def joint_observation_updates(self) -> tuple[JointObservationUpdate, ...]:
        """Recomputed current-generation measurement effects; no long-term writes."""
        with self._lock, self._system.core._execution_lock:
            self._enter()
            try:
                return self._joint_decision_and_observation_updates()[1]
            finally:
                self._busy = False

    def _admit_current_raw_context(
        self, *, cutoff: datetime, allow_no_source: bool = False
    ) -> None:
        """Anchor actual owner advances, including no-new-semantic collection.

        No inference result cannot invent a first semantic source. Once a source
        exists, each real owner cutoff has its own admitted prefix and prior;
        this grants no additional measurement consumption to a published batch.
        """
        core = self._system.core
        with core._execution_lock:
            core._check_particle_workspace_binding()
            workspace = core._particle_workspace
            if workspace.raw_candidate_profile is None:
                return
            core._validate_particle_input_anchors()
            if allow_no_source and not workspace.posterior_sources:
                # The independent core source catalogue was checked above too.
                return
            context = NativeJointContext(
                source=core.current_posterior_projection_source(),
                previous_batch=workspace.batch,
                records=tuple(workspace.records.values()),
                ledger_head_sha256=core._hybrid_loop.ledger.export_state().manifest.head_hash,
                visible_prefix=self.visible_prefix(cutoff=cutoff),
                cutoff=cutoff,
                visual_source=self._native_visual_source(cutoff),
                previous_weight_evidence=workspace.previous_weight_evidence(workspace.batch),
            )
            core._register_native_raw_context(context, authority=self._raw_candidate_authority)

    def _verify_native_raw_sources(self) -> None:
        from cpswm.system.owned_position_update import verify_journal

        verify_journal(self)
        core = self._system.core
        core._check_particle_workspace_binding()
        workspace = core._particle_workspace
        if (
            native_content_sha256(profile_for(self._joint_producer))
            != core._particle_raw_profile_sha256
        ):
            raise ValueError("restored raw profile differs from configured producer")
        for key, context in workspace.raw_contexts.items():
            expected = replace(context, visible_prefix=self.visible_prefix(cutoff=context.cutoff))
            if key != context.content_sha256 or raw_context_digest(
                expected
            ) != core._particle_raw_context_anchors.get(key):
                raise ValueError("raw candidate context differs from original admitted bytes")
        workspace._validate_persisted_state()

    def consume_owned_position_observation(self, action_id: UUID) -> NativeObservationUpdate:
        """Atomically consume the original delivered frame, without rerunning P5."""
        from cpswm.system.owned_position_update import consume

        return consume(self, action_id)

    def withdraw_owned_position_observation(self, action_id: UUID, *, reason: str) -> None:
        """Withdraw position evidence and atomically replay; keep acquisition history.

        This does not erase the physical observation or retrospectively undo a
        camera action. An initial tracking-anchor withdrawal also excludes its
        dependent captures. Middle-capture withdrawal recomputes the suffix.
        """
        from cpswm.system.owned_position_update import withdraw

        withdraw(self, action_id, reason=reason)

    def produce_joint_posterior(self) -> None:
        """Populate the current native batch with the configured producer, once.

        Called by the collector after P5, before planning. No producer means no
        synthetic fallback. Revision invalidation still requires the selected
        replay kernel; this seam never clears invalidations or reuses stale mass.
        """
        with self._lock, self._system.core._execution_lock:
            self._enter()
            producer = self._joint_producer
            previous = None
            previous_visual_sources = None
            published = False
            try:
                if not self._joint_binding_matches(producer):
                    raise ValueError("joint producer dependency changed")
                if producer is None:
                    return
                if self._execution_lane != "registered_p5_first":
                    raise ValueError("joint production requires registered P5-first")
                core = self._system.core
                core._check_particle_workspace_binding()
                core._validate_particle_input_anchors()
                workspace = core._particle_workspace
                if workspace.invalidated_revisions:
                    raise ValueError("joint posterior requires full particle revision replay")
                source = core.current_posterior_projection_source()
                if workspace.batch is not None:
                    if self._joint_published_batch_sha256 != native_content_sha256(workspace.batch):
                        raise ValueError(
                            "current batch was not published by the configured joint producer"
                        )
                    if (
                        workspace.batch.snapshot_id == core.current_snapshot.snapshot_id
                        and self._joint_published_source_sha256 == source.body_sha256
                    ):
                        core.prepared_particle_location_marginal()
                        return
                if self._last_cutoff is None:
                    raise ValueError("joint production requires an advanced semantic source")
                previous_visual_sources = dict(workspace.visual_sources)
                context = deepcopy(
                    NativeJointContext(
                        source=source,
                        previous_batch=workspace.batch,
                        records=tuple(workspace.records.values()),
                        ledger_head_sha256=core._hybrid_loop.ledger.export_state().manifest.head_hash,
                        visible_prefix=self.visible_prefix(cutoff=self._last_cutoff),
                        cutoff=self._last_cutoff,
                        visual_source=self._native_visual_source(self._last_cutoff),
                        previous_weight_evidence=workspace.previous_weight_evidence(workspace.batch)
                        if workspace.raw_candidate_profile is not None
                        else None,
                    )
                )
                context_hash = context.content_sha256
                if (
                    workspace.raw_candidate_profile is not None
                    and context_hash not in workspace.raw_contexts
                ):
                    raise ValueError("current raw context lacks its owner P5 admission")
                previous = deepcopy(producer.checkpoint_state())
                produced = deepcopy(producer.produce(context))
                if (
                    type(produced) is not ProducedJointCandidates
                    or produced.context_sha256 != context_hash
                    or produced.source_posterior_id != source.source_id
                    or produced.source_body_sha256 != source.body_sha256
                    or (
                        produced.neural_evidence is not None
                        and produced.neural_evidence.input_context_sha256 != context_hash
                    )
                    or produced.dependency_sha256 != self._joint_dependency_binding
                    or (
                        produced.neural_evidence is not None
                        and produced.neural_evidence.producer_binding_sha256
                        != self._joint_dependency_binding
                    )
                    or not self._joint_binding_matches(producer)
                ):
                    raise ValueError(
                        "joint candidates differ from the current source or dependency"
                    )
                core.stage_prepared_particle_candidates(
                    receipts=produced.receipts,
                    statistics=produced.statistics,
                    unresolved_log_weight=produced.unresolved_log_weight,
                    neural_evidence=produced.neural_evidence,
                )
                published = True
                self._joint_published_batch_sha256 = native_content_sha256(workspace.batch)
                self._joint_published_source_sha256 = source.body_sha256
                self._persist()
            except BaseException:
                if previous_visual_sources is not None and not published:
                    self._system.core._particle_workspace.visual_sources = previous_visual_sources
                if producer is not None and previous is not None and not self._durability_failed:
                    try:
                        producer.restore_state(previous)
                    except BaseException:
                        self._durability_failed = True
                        raise
                raise
            finally:
                self._busy = False

    def replay_joint_posterior(self) -> None:
        """Explicit full-history fallback after a real revision invalidation.

        Replay resets the same configured producer to its recorded initial state,
        recomputes all retained sources, and preserves the semantic ledger and old
        invalidated generation. No action is executed or replayed by this method.
        """
        with self._lock, self._system.core._execution_lock:
            self._enter()
            producer = self._joint_producer
            previous = None
            core_checkpoint = None
            old_observation_status = dict(self._observation_status)
            old_publication = (
                self._joint_published_batch_sha256,
                self._joint_published_source_sha256,
                self._last_cutoff,
            )
            try:
                if (
                    producer is None
                    or self._joint_initial_state is None
                    or not self._joint_binding_matches(producer)
                ):
                    raise ValueError("full joint replay requires the original configured producer")
                if self._execution_lane != "registered_p5_first" or self._last_cutoff is None:
                    raise ValueError("full joint replay requires advanced registered P5")
                if (
                    native_content_sha256(self._joint_initial_state)
                    != self._joint_initial_state_sha256
                ):
                    raise ValueError("joint producer initial-state binding changed")
                core = self._system.core
                if self._joint_published_batch_sha256 != native_content_sha256(
                    core._particle_workspace.batch
                ):
                    raise ValueError(
                        "full joint replay requires the configured producer's published history"
                    )
                core_checkpoint = core._capture_revision_transaction(include_operator_state=True)
                previous = deepcopy(producer.checkpoint_state())
                producer.restore_state(deepcopy(self._joint_initial_state))
                if (
                    native_content_sha256(producer.checkpoint_state())
                    != self._joint_initial_state_sha256
                ):
                    raise ValueError("joint producer did not restore its recorded initial state")

                cutoff = max(self._last_cutoff, self._last_arrival or self._last_cutoff)

                def produce(
                    source: NativePosteriorSource, update: Any = None
                ) -> ProducedJointCandidates:
                    workspace = core._particle_workspace
                    historical = None if update is None else update.context
                    update_cutoff = cutoff if historical is None else historical.cutoff
                    context = deepcopy(
                        NativeJointContext(
                            source=source,
                            previous_batch=workspace.batch,
                            records=tuple(workspace.records.values()),
                            ledger_head_sha256=core._hybrid_loop.ledger.export_state().manifest.head_hash,
                            visible_prefix=self.visible_prefix(cutoff=update_cutoff),
                            cutoff=update_cutoff,
                            visual_source=self._native_visual_source(update_cutoff),
                            previous_weight_evidence=workspace.previous_weight_evidence(
                                workspace.batch
                            )
                            if workspace.raw_candidate_profile is not None
                            else None,
                            observation_update=None
                            if historical is None
                            else historical.observation_update,
                        )
                    )
                    expected = context.content_sha256
                    if workspace.raw_candidate_profile is not None:
                        core._register_native_raw_context(
                            context, authority=self._raw_candidate_authority
                        )
                    produced = deepcopy(producer.produce(context))
                    if (
                        type(produced) is not ProducedJointCandidates
                        or produced.context_sha256 != expected
                        or produced.source_posterior_id != source.source_id
                        or produced.source_body_sha256 != source.body_sha256
                        or (
                            produced.neural_evidence is not None
                            and produced.neural_evidence.input_context_sha256 != expected
                        )
                        or produced.dependency_sha256 != self._joint_dependency_binding
                        or (
                            produced.neural_evidence is not None
                            and produced.neural_evidence.producer_binding_sha256
                            != self._joint_dependency_binding
                        )
                        or not self._joint_binding_matches(producer)
                    ):
                        raise ValueError(
                            "joint replay result differs from its live source/dependency"
                        )
                    return produced

                core.rebuild_prepared_particle_history(produce)
                self._joint_published_batch_sha256 = native_content_sha256(
                    core._particle_workspace.batch
                )
                self._joint_published_source_sha256 = (
                    core.current_posterior_projection_source().body_sha256
                )
                self._last_cutoff = cutoff
                self._cancel_stale_joint_commands()
                self._persist()
            except BaseException:
                if core_checkpoint is not None and not self._durability_failed:
                    self._system.core._restore_revision_transaction(core_checkpoint)
                    self._observation_status = old_observation_status
                    (
                        self._joint_published_batch_sha256,
                        self._joint_published_source_sha256,
                        self._last_cutoff,
                    ) = old_publication
                if producer is not None and previous is not None and not self._durability_failed:
                    try:
                        producer.restore_state(previous)
                        if native_content_sha256(
                            producer.checkpoint_state()
                        ) != native_content_sha256(previous):
                            raise ValueError(
                                "joint producer rollback did not restore its prior state"
                            )
                    except BaseException:
                        self._durability_failed = True
                        raise
                raise
            finally:
                self._busy = False

    def _cancel_stale_joint_commands(self) -> None:
        """Retain issued capabilities but cancel obsolete, never-dispatched plans."""
        from cpswm.system.joint_camera_policy import JointCameraProblem

        if self._last_cutoff is None:
            raise ValueError("joint replay cancellation requires its knowledge cutoff")
        view = self._current_joint_decision_view()
        for action_id, (command, digest) in self._observation_commands.items():
            if self._observation_status[action_id] != "READY" or not command.reason.startswith(
                ("joint-ciav@1:", "owned-surface-policy@1:")
            ):
                continue
            if content_sha256(command) != digest:
                raise ValueError("joint observation command changed before replay cancellation")
            if command.reason.startswith("owned-surface-policy@1:"):
                import json

                source_belief = json.loads(command.reason.split(":", 1)[1])["source_belief_sha256"]
            else:
                problem = JointCameraProblem.model_validate_json(
                    command.reason.removeprefix("joint-ciav@1:")
                )
                source_belief = problem.source_belief_sha256
            if (
                command.snapshot_id != view.snapshot_id
                or source_belief != view.content_sha256
                or command.decision_time < self._last_cutoff
            ):
                self._observation_status[action_id] = "CANCELLED_STALE_JOINT"

    def current_joint_decision_view(self) -> JointDecisionView:
        """Read this owner's current native batch without accepting caller posterior mass."""
        with self._lock, self._system.core._execution_lock:
            self._enter()
            try:
                return self._current_joint_decision_view()
            finally:
                self._busy = False

    def prepare_posterior_observation(
        self, problem: JointCameraProblem, *, decision_time: datetime
    ) -> tuple[ActiveObservationPlan, ObservationCommand | None]:
        """Choose using the actual joint posterior, then issue through the durable path.

        A fitted outcome model must provide the problem; source hashes alone do
        not establish its calibration. Absence of a usable posterior or a
        beneficial action never falls back to a fixed scan.
        """
        from cpswm.system.joint_camera_policy import JointCameraProblem

        with self._lock, self._system.core._execution_lock:
            problem = JointCameraProblem.model_validate(problem.model_dump())
            view = self.current_joint_decision_view()
            self._enter()
            try:
                self._require_resolved_dispatches()
                when = _utc(decision_time)
                if any(t is not None and when < t for t in (self._last_arrival, self._last_cutoff)):
                    raise ValueError("posterior observation decision predates current history")
                if self._observation_decoder is not None and (
                    problem.model_sources != self._observation_decoder.sources
                ):
                    raise ValueError("camera problem differs from configured outcome decoder")
                if not set(problem.source_observation_ids) <= set(self._raw):
                    raise ValueError("posterior observation references unseen raw evidence")
                plan, selected = problem.select(view, self._system.cause_information_planner)
                if selected is None:
                    return plan, None
                reason = "joint-ciav@1:" + problem.model_dump_json()
                # Retain both locks while using the existing command issuer.
                self._busy = False
                command = self.prepare_observation(
                    action=selected.action,
                    degrees=selected.degrees,
                    reason=reason,
                    source_ids=problem.source_observation_ids,
                    decision_time=when,
                )
                return plan, command
            finally:
                self._busy = False

    def prepare_observation(
        self,
        *,
        action: str,
        degrees: float,
        reason: str,
        source_ids: tuple[UUID, ...],
        decision_time: datetime,
    ) -> ObservationCommand:
        """Issue a bounded camera request grounded in this runtime's visible history.

        The configured observation policy supplies the reason and action. This
        does not claim that an uncalibrated visual proposal is a semantic belief.
        """
        with self._lock:
            self._enter()
            try:
                self._require_resolved_dispatches()
                when = _utc(decision_time)
                if any(t is not None and when < t for t in (self._last_arrival, self._last_cutoff)):
                    raise ValueError("observation decision predates current history")
                if action not in {"Pass", "RotateRight", "RotateLeft"} or not 0 <= degrees <= 90:
                    raise ValueError("unsupported bounded observation action")
                if action != "Pass" and degrees == 0:
                    raise ValueError("rotation requires positive degrees")
                if not reason.strip() or not source_ids or len(set(source_ids)) != len(source_ids):
                    raise ValueError("observation request needs reason and unique source evidence")
                if not set(source_ids) <= set(self._raw):
                    raise ValueError("observation request references unseen evidence")
                native_origin = (
                    self._native_joint_decision_view().content_sha256
                    if self._observation_decoder is not None
                    and reason.startswith(("joint-ciav@1:", "owned-surface-policy@1:"))
                    else None
                )
                command = ObservationCommand(
                    uuid4(),
                    self._system.core.current_snapshot.snapshot_id,
                    action,
                    degrees,
                    reason,
                    source_ids,
                    when,
                )
                if reason.startswith("owned-surface-policy@1:"):
                    from cpswm.system.surface_episode import validate_surface_command

                    validate_surface_command(self, command, self._current_joint_decision_view())
                self._observation_commands[command.action_id] = (command, content_sha256(command))
                self._observation_status[command.action_id] = "READY"
                if native_origin is not None:
                    self._observation_native_origins[command.action_id] = native_origin
                    from cpswm.system.owned_position_update import enabled, issue_anchor

                    if enabled(self):
                        self._system.core._particle_observation_issues[command.action_id] = (
                            issue_anchor(self, command)
                        )
                self._last_cutoff = when
                self._persist()
                return command
            finally:
                self._busy = False

    def execute_observation(
        self, command: ObservationCommand, *, executor: ObservationExecutor
    ) -> ObservationDelivery:
        with self._lock, self._system.core._execution_lock:
            self._enter()
            try:
                owned, digest = self._observation_commands[command.action_id]
                if owned is not command or content_sha256(command) != digest:
                    raise ValueError("observation command is not this runtime's issued capability")
                if self._observation_status[command.action_id] != "READY":
                    raise ValueError("observation already dispatched; reconcile instead")
                self._require_resolved_dispatches()
                if command.snapshot_id != self._system.core.current_snapshot.snapshot_id:
                    raise ValueError("stale observation command")
                if command.reason.startswith("joint-ciav@1:"):
                    from cpswm.system.joint_camera_policy import JointCameraProblem

                    problem = JointCameraProblem.model_validate_json(
                        command.reason.removeprefix("joint-ciav@1:")
                    )
                    view = self._current_joint_decision_view()
                    if problem.source_belief_sha256 != view.content_sha256:
                        raise ValueError("observation command joint posterior has changed")
                    _, selected = problem.select(view, self._system.cause_information_planner)
                    if (
                        selected is None
                        or selected.action != command.action
                        or selected.degrees != command.degrees
                        or problem.source_observation_ids != command.source_ids
                    ):
                        raise ValueError("observation command differs from joint model decision")
                if command.reason.startswith("owned-surface-policy@1:"):
                    from cpswm.system.surface_episode import validate_surface_command

                    validate_surface_command(self, command, self._current_joint_decision_view())
                if any(
                    t is not None and command.decision_time < t
                    for t in (self._last_arrival, self._last_cutoff)
                ):
                    raise ValueError("observation decision predates current evidence or decision")
                self._observation_status[command.action_id] = "OUTCOME_UNCERTAIN"
                self._persist()
                delivery = executor.execute(deepcopy(command))
                return self._accept_observation(command, delivery)
            finally:
                self._busy = False

    def _accept_observation(
        self,
        command: ObservationCommand,
        delivery: ObservationDelivery,
    ) -> ObservationDelivery:
        if type(delivery) is not ObservationDelivery:
            raise ValueError("observation receipt must be an immutable delivery value")
        delivery = deepcopy(delivery)
        if delivery.action_id != command.action_id:
            raise ValueError("observation receipt does not match dispatched command")
        if type(delivery.success) is not bool or (not delivery.success and not delivery.error):
            raise ValueError("observation success/failure receipt is incomplete")
        when = _utc(delivery.received_at)
        if any(t is not None and when < t for t in (self._last_arrival, self._last_cutoff)):
            raise ValueError("observation receipt predates current history")
        if when < command.decision_time or (delivery.success and not delivery.observations):
            raise ValueError("observation execution lacks new post-action input")
        for raw in delivery.observations:
            env = raw.envelope()
            if env.capture_time < command.decision_time or env.identity.observation_id in self._raw:
                raise ValueError("observation execution returned old input")
        # Keep the outer RLock while invoking the normal atomic M05 admission path.
        self._busy = False
        self._checkpoint_suspended = True
        try:
            if delivery.observations:
                self.admit(delivery.observations, received_at=when)
        finally:
            self._busy = True
            self._checkpoint_suspended = False
        self._observation_status[command.action_id] = delivery
        from cpswm.system.owned_position_update import delivery_pin, enabled

        if enabled(self):
            self._system.core._particle_observation_deliveries[command.action_id] = delivery_pin(
                delivery
            )
        self._last_arrival = when
        self._persist()
        return deepcopy(delivery)

    def observation_history(
        self,
    ) -> tuple[tuple[ObservationCommand, str | ObservationDelivery], ...]:
        """Detached issued requests and actual receipts for the observation model."""
        with self._lock:
            return deepcopy(
                tuple(
                    (value[0], self._observation_status[key])
                    for key, value in self._observation_commands.items()
                )
            )

    def _reconstruct_native_visual_source(
        self, cutoff: datetime, runtime_id: UUID | None = None
    ) -> NativeVisualSource:
        self._check_observation_decoder()
        assert self._observation_decoder is not None
        assert self._observation_decoder_binding is not None
        # Exclude pending commands and future deliveries: a frozen proof must
        # survive later dispatch, cancellation, correction and new observations.
        keys = {
            k
            for k, d in self._observation_status.items()
            if type(d) is ObservationDelivery and d.received_at <= cutoff
        }
        support = reconstruct_visual_support(
            commands={k: v for k, v in self._observation_commands.items() if k in keys},
            statuses={k: v for k, v in self._observation_status.items() if k in keys},
            native_origins={k: v for k, v in self._observation_native_origins.items() if k in keys},
            raw=self._raw,
            scope=self._scope,
            decoder=cast(VisualMeasurementDecoder, self._observation_decoder),
            expected_binding=self._observation_decoder_binding,
        )
        return NativeVisualSource(
            self._system.core._particle_workspace.runtime_id if runtime_id is None else runtime_id,
            self._scope,
            cutoff,
            support,
        )

    def _native_visual_source(self, cutoff: datetime) -> NativeVisualSource | None:
        if not self._joint_uses_visual_context:
            return None
        source = self._reconstruct_native_visual_source(cutoff)
        workspace = self._system.core._particle_workspace
        workspace.bind_visual_owner(self._visual_authority)
        workspace.register_visual_source(source, authority=self._visual_authority)
        return source

    def _verify_native_visual_sources(self) -> None:
        if not self._joint_uses_visual_context:
            return
        core = self._system.core
        workspaces = (
            core._particle_workspace,
            *(g.old_workspace for g in core._particle_replay_generations),
        )
        fresh: dict[tuple[UUID, datetime], Any] = {}
        for workspace in workspaces:
            if workspace._visual_authority != self._visual_authority:
                raise ValueError("restored native visual owner differs")
            for key, source in workspace.visual_sources.items():
                lookup = (workspace.runtime_id, source.cutoff)
                if lookup not in fresh:
                    fresh[lookup] = self._reconstruct_native_visual_source(
                        source.cutoff, workspace.runtime_id
                    )
                if key != source.content_sha256 or source != fresh[lookup]:
                    raise ValueError("fresh owned visual neural source differs")

    def visual_observation_support(
        self, *, expected: OwnedVisualSupport | None = None
    ) -> OwnedVisualSupport:
        """Reinfer full frame candidates from owned pixels without changing state.

        Old generations remain explicit history; no frame is silently reused as
        current-generation density, persistent instance identity or metric pose.
        """
        with self._lock:
            self._enter()
            try:
                self._check_observation_decoder()
                if self._observation_decoder is None:
                    raise ValueError("visual support requires a configured decoder")
                assert self._observation_decoder_binding is not None
                result = reconstruct_visual_support(
                    commands=deepcopy(self._observation_commands),
                    statuses=deepcopy(self._observation_status),
                    native_origins=deepcopy(self._observation_native_origins),
                    raw=deepcopy(self._raw),
                    scope=self._scope,
                    decoder=cast(VisualMeasurementDecoder, self._observation_decoder),
                    expected_binding=self._observation_decoder_binding,
                )
                if expected is not None and result != expected:
                    raise ValueError("fresh owned visual support differs")
                return result
            finally:
                self._busy = False

    def reconcile_observation(
        self,
        action_id: UUID,
        delivery: ObservationDelivery,
    ) -> ObservationDelivery:
        with self._lock:
            self._enter()
            try:
                if self._observation_status.get(action_id) != "OUTCOME_UNCERTAIN":
                    raise ValueError("no uncertain observation to reconcile")
                return self._accept_observation(self._observation_commands[action_id][0], delivery)
            finally:
                self._busy = False

    def placement_command(self, action_id: UUID) -> PlacementCommand:
        """Recover a previously issued capability; dispatched commands remain single-use."""
        with self._lock:
            return self._commands[action_id]

    def _persist(self) -> None:
        if self._state_store is None or self._checkpoint_suspended:
            return
        try:
            producer_state = None
            if self._producer is not None:
                if not callable(getattr(self._producer, "checkpoint_state", None)):
                    raise ValueError("durable perception producer must implement checkpoint_state")
                producer_state = self._producer.checkpoint_state()
            if not self._joint_binding_matches(self._joint_producer):
                raise ValueError("joint producer dependency changed before checkpoint")
            self._check_observation_decoder()
            joint_state = (
                deepcopy(self._joint_producer.checkpoint_state())
                if self._joint_producer is not None
                else None
            )
            fields = {
                k: v
                for k, v in vars(self).items()
                if k
                not in {
                    "_lock",
                    "_busy",
                    "_producer",
                    "_joint_producer",
                    "_observation_decoder",
                    "_context_builder",
                    "_state_store",
                    "_durability_failed",
                    "_checkpoint_suspended",
                }
            }
            fields["_joint_producer_state"] = joint_state
            self._state_store.save(
                {
                    "fields": fields,
                    "producer_state": producer_state,
                    "producer_present": self._producer is not None,
                }
            )
        except BaseException:
            self._durability_failed = True
            raise

    @classmethod
    def resume(
        cls,
        store: ContinuousStateStore,
        *,
        producer: PerceptionProducer | None = None,
        context_builder: Callable[
            [StructureTwoProductionSystem, GroundedTransition, datetime, int],
            AdaptiveExecutionContext,
        ]
        | None = None,
        joint_producer: NativeJointProducer | None = None,
        observation_decoder: CameraOutcomeDecoder | None = None,
    ) -> ContinuousEvidenceInput:
        """Restore one owned system graph; never replay actions or reinitialize a core.

        External dependencies are explicitly rebound under the store dependency
        identity. Their credentials/models are not serialized. The transport must
        reconcile commands marked uncertain before further physical dispatch.
        """
        saved = store.load()
        if not isinstance(saved, dict) or set(saved) != {
            "fields",
            "producer_state",
            "producer_present",
        }:
            raise ValueError("invalid continuous checkpoint root")
        if saved["producer_present"] != (producer is not None):
            raise ValueError("checkpoint perception dependency missing or changed")
        restored = object.__new__(cls)
        restored.__dict__.update(saved["fields"])
        restored._observation_decoder = observation_decoder
        restored._observation_decoder_binding = getattr(
            restored, "_observation_decoder_binding", None
        )
        restored._check_observation_decoder()
        expected_joint = getattr(restored, "_joint_dependency_binding", None)
        expected_implementation = getattr(restored, "_joint_implementation_binding", None)
        if producer_implementation_binding(joint_producer) != expected_implementation:
            raise ValueError(
                "checkpoint joint producer dependency changed: implementation missing or different"
            )
        if producer_binding(joint_producer) != expected_joint:
            raise ValueError("checkpoint joint producer dependency missing or changed")
        if not isinstance(restored._system, StructureTwoProductionSystem):
            raise ValueError("checkpoint does not own a production system")
        if restored._execution_lane == "registered_p5_first" and context_builder is None:
            raise ValueError("checkpoint requires its P5 context builder")
        if producer is not None:
            if not callable(getattr(producer, "restore_state", None)):
                raise ValueError("durable perception producer must implement restore_state")
            producer.restore_state(saved["producer_state"])
        joint_state = restored.__dict__.pop("_joint_producer_state", None)
        if joint_producer is not None:
            joint_producer.restore_state(deepcopy(joint_state))
            if native_content_sha256(joint_producer.checkpoint_state()) != native_content_sha256(
                joint_state
            ):
                raise ValueError("checkpoint joint producer restored state differs")
            if (
                producer_binding(joint_producer) != expected_joint
                or producer_implementation_binding(joint_producer) != expected_implementation
            ):
                raise ValueError("restored joint producer dependency changed")
        if restored._joint_uses_visual_context != bool(
            getattr(joint_producer, "use_owned_visual_context", False)
        ):
            raise ValueError("restored visual neural profile differs")
        restored._joint_producer = joint_producer
        restored._joint_dependency_binding = expected_joint
        restored._joint_published_batch_sha256 = getattr(
            restored, "_joint_published_batch_sha256", None
        )
        restored._joint_published_source_sha256 = getattr(
            restored, "_joint_published_source_sha256", None
        )
        restored._producer = producer
        restored._context_builder = context_builder
        restored._state_store = store
        restored._lock = RLock()
        restored._busy = False
        restored._durability_failed = False
        restored._checkpoint_suspended = False
        restored._position_consumptions = getattr(restored, "_position_consumptions", {})
        restored._position_withdrawals = getattr(restored, "_position_withdrawals", {})
        restored._verify_native_visual_sources()
        restored._verify_native_raw_sources()
        return restored
