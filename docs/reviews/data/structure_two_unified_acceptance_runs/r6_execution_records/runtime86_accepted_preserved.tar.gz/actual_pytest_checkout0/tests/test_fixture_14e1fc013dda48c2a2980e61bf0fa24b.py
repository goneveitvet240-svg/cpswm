def test_live():
 try:
  import cpswm.caught_bad_cache
 except BaseException:
  pass
 assert True
