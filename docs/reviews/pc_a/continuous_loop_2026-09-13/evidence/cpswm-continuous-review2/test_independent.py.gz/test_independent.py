from datetime import timedelta
from dataclasses import replace
from uuid import uuid4
import pytest
from test_structure_two_continuous_input import setup, deliver, raw_for, FixtureWorldExecutor

def ready():
    p,s,b,t=setup()
    deliver(s,b,t)
    return p,s,b,t,t.after.detection_time+timedelta(seconds=10)

def test_queued_old_command_never_dispatched_after_newer_completion():
    p,s,b,t,now=ready()
    older=s.prepare_habit_placement(decision_time=now)
    newer=s.prepare_habit_placement(decision_time=now+timedelta(seconds=10))
    world=FixtureWorldExecutor(t.after.metadata)
    s.execute_placement(newer,executor=world)
    assert world.calls==1
    with pytest.raises(ValueError):
        s.execute_placement(older,executor=world)
    assert world.calls==1, 'backdated old command physically dispatched before timeline rejection'

def test_uncertain_blocks_already_prepared_command_and_forged_reconcile_is_atomic():
    p,s,b,t,now=ready()
    a=s.prepare_habit_placement(decision_time=now)
    pending=s.prepare_habit_placement(decision_time=now)
    world=FixtureWorldExecutor(t.after.metadata,fail_after_move=True)
    with pytest.raises(OSError):s.execute_placement(a,executor=world)
    before=s.placement_dispatches()
    with pytest.raises(RuntimeError):s.execute_placement(pending,executor=world)
    assert world.calls==1
    reply=FixtureWorldExecutor(t.after.metadata).execute(a)
    forged=replace(reply,feedback=reply.feedback.model_copy(update={'action_id':uuid4()}))
    with pytest.raises(ValueError):s.reconcile_placement(a.action_id,forged)
    assert s.placement_dispatches()==before
    s.reconcile_placement(a.action_id,reply)
    assert world.calls==1
    later=replace(reply,received_at=now+timedelta(hours=1))
    s.reconcile_placement(a.action_id,later)
    with pytest.raises(ValueError):s.admit((raw_for(t),),received_at=now+timedelta(minutes=30))

def test_executor_alias_is_detached():
    p,s,b,t,now=ready()
    cmd=s.prepare_habit_placement(decision_time=now)
    real=FixtureWorldExecutor(t.after.metadata)
    class E:
        def execute(self,c):
            answer=real.execute(c)
            object.__setattr__(c,'location_id',uuid4())
            return answer
    s.execute_placement(cmd,executor=E())
    assert s.placement_dispatches()[0].command.location_id==cmd.location_id

@pytest.mark.parametrize('field',['action_id','attempted_location_id','target_entity','source','recorded','end','received'])
def test_complete_but_misbound_receipts_rejected_without_resolving(field):
    from cpswm.contracts import SourceType
    p,s,b,t,now=ready()
    cmd=s.prepare_habit_placement(decision_time=now)
    with pytest.raises(OSError):
        s.execute_placement(cmd,executor=FixtureWorldExecutor(t.after.metadata,fail_after_move=True))
    good=FixtureWorldExecutor(t.after.metadata).execute(cmd)
    fb=good.feedback
    if field in ['action_id','attempted_location_id']:fb=fb.model_copy(update={field:uuid4()})
    elif field=='target_entity':fb=fb.model_copy(update={'target_entity':fb.target_entity.model_copy(update={'entity_id':uuid4()})})
    elif field=='source':fb=fb.model_copy(update={'metadata':fb.metadata.model_copy(update={'source_type':SourceType.SIMULATION})})
    elif field=='recorded':fb=fb.model_copy(update={'metadata':fb.metadata.model_copy(update={'recorded_time':now-timedelta(seconds=1)})})
    elif field=='end':fb=fb.model_copy(update={'valid_time':fb.valid_time.model_copy(update={'end':now+timedelta(hours=1)})})
    bad=replace(good,feedback=fb,received_at=now-timedelta(seconds=1)) if field=='received' else replace(good,feedback=fb)
    before=s.placement_dispatches()
    with pytest.raises(ValueError):s.reconcile_placement(cmd.action_id,bad)
    assert s.placement_dispatches()==before
    assert s.reconcile_placement(cmd.action_id,good).status=='FEEDBACK_RECEIVED'

def test_late_revision_changes_command_and_duplicate_moves_watermark():
    import test_structure_two_formal_revision_lineage as old
    p,s,b,t=setup()
    for day in p.observed_days()[:12]:deliver(s,b,p.transition_for(day))
    now=p.observed_days()[12].after.detection_time
    first=s.prepare_habit_placement(decision_time=now)
    core=p.system.core
    bundles=[old._feedback(p,rid) for rid,event in core._committed_events.items() if event.location_id==first.location_id]
    assert bundles
    for i,(fb,bind,model) in enumerate(bundles):
        s.consume_feedback(feedback=fb,binding=bind,likelihood_model=model,received_at=now+timedelta(seconds=i+1),policy=old.RETRACTION_POLICY)
    second=s.prepare_habit_placement(decision_time=now+timedelta(hours=1))
    assert second.location_id!=first.location_id
    assert core.verify_hybrid_full_rerun_equivalence().equivalent
    fb,bind,model=bundles[-1]
    snapshot=core.current_snapshot
    s.consume_feedback(feedback=fb,binding=bind,likelihood_model=model,received_at=now+timedelta(hours=2),policy=old.RETRACTION_POLICY)
    assert core.current_snapshot==snapshot
    with pytest.raises(ValueError):s.advance(cutoff=now+timedelta(minutes=90))
    with pytest.raises(ValueError):s.prepare_habit_placement(decision_time=now+timedelta(minutes=90))
    with pytest.raises(ValueError):s.admit((raw_for(t),),received_at=now+timedelta(minutes=90))
