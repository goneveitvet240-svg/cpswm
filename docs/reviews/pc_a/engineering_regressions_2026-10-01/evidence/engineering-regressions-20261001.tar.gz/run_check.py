from pathlib import Path
from datetime import datetime,UTC
import os,sys,json,subprocess,time,hashlib
W=Path('/private/tmp/cpswm-pc-a-engineering-regressions-20261001')
O=Path(__file__).parent
name=sys.argv[1];args=sys.argv[2:]
env=dict(os.environ,PYTHONPATH=str(W/'src'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
def sources():return {str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ('src','tests','tools') for p in sorted((W/d).rglob('*.py'))}
before=sources();start=time.monotonic();record=dict(argv=args,cwd=str(W),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),started_at=datetime.now(UTC).isoformat(),PYTHONPATH=env['PYTHONPATH'],source_files=before)
with (O/(name+'.log')).open('w') as out:
 result=subprocess.run(args,cwd=W,env=env,stdout=out,stderr=subprocess.STDOUT,check=False)
record.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,source_unchanged=before==sources())
(O/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(name,result.returncode,record['elapsed_seconds'],record['source_unchanged'])
