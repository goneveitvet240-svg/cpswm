def test_live():
 from cpswm import dependency_eae45a2cbfee49779458ae654274fb49
 assert dependency_eae45a2cbfee49779458ae654274fb49.VALUE == 9
