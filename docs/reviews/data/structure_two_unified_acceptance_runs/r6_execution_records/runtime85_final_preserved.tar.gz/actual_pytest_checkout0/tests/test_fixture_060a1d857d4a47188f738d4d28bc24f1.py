def test_live():
 import dependency_d80c1d158c9c4bf59963340d1a9a2c94
 assert dependency_d80c1d158c9c4bf59963340d1a9a2c94.VALUE == 9
