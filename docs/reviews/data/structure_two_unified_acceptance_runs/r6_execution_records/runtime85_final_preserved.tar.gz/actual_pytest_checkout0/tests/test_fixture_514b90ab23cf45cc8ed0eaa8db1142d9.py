def test_live():
 from cpswm import dependency_4c83b6aa991e4de0b11fce1a1c7e07f7
 assert dependency_4c83b6aa991e4de0b11fce1a1c7e07f7.VALUE == 9
