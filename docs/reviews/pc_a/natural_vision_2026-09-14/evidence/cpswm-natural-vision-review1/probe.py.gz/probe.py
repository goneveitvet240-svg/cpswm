import sys, os, json, hashlib, importlib.util, subprocess
from pathlib import Path
ROOT=Path('/private/tmp/cpswm-pc-a-natural-vision-20260914')
sys.path[:0]=[str(ROOT/'tests'),str(ROOT/'src')]
from test_structure_two_continuous_input import raw_for,setup
from cpswm.perception_mapping.natural_vision import NaturalAppearanceDetector
import torch
torch.set_num_threads(2)
base=Path('/private/tmp/cpswm-natural-vision-review1')
a=base/'archive';a.mkdir(exist_ok=True)
_,_,_,t=setup(False); raw=raw_for(t)
(a/'rgb.json').write_text(raw.envelope_json);(a/'rgb.npy').write_bytes(raw.payload_bytes)
rows=[]
for p in (a/'rgb.json',a/'rgb.npy'):
 v=p.read_bytes();rows.append(dict(file=p.name,size_bytes=len(v),sha256=hashlib.sha256(v).hexdigest(),capture_ref='capture1'))
m=dict(output_manifest=rows,captures=[dict(capture_ref='capture1',source_receipt_sha256='a'*64),dict(capture_ref='capture1',source_receipt_sha256='b'*64)],source_sha='fixture-source')
b=json.dumps(m).encode();(a/'receipt.json').write_bytes(b)
foreign=base/'foreign';foreign.mkdir(exist_ok=True)
subprocess.run(['git','init','-q',str(foreign)],check=True)
subprocess.run(['git','-C',str(foreign),'-c','user.name=review','-c','user.email=review@example.invalid','commit','--allow-empty','-qm','unrelated'],check=True)
os.chdir(foreign)
spec=importlib.util.spec_from_file_location('runner',ROOT/'tools/run_natural_vision_archive.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
sys.argv=['runner','--archive',str(a),'--manifest-sha256',hashlib.sha256(b).hexdigest(),'--weights','/private/tmp/cpswm-natural-vision-models/ssdlite320_mobilenet_v3_large_coco-a79551df.pth','--output',str(base/'output')]
runner.main()
s=json.loads((base/'output/summary.json').read_text()); f=json.loads((base/'output/frames.json').read_text())
print('WRONG_SOURCE_SHA',s['source_sha'],subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip())
print('DUPLICATE_CAPTURE_OVERWRITE',f[0]['receipt_sha256'])
print('ACTUAL_MODEL_VERSIONS',f[0]['torch_version'],f[0]['torchvision_version'])
