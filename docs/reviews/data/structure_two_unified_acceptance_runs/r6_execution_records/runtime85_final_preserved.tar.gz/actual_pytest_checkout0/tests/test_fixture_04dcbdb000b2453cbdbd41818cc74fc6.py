def test_live():
 from cpswm import legal_206a767b1ebd469a8b0f43d1b57127a7
 assert legal_206a767b1ebd469a8b0f43d1b57127a7.VALUE == 7
