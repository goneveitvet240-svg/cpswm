"""Pinned production decoders on synthetic fixed-eight-view pixels only.

No real simulator archive, model fitting, threshold choice or scientific claim.
"""
import json
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch
import diagnose_offline_frontend as driver
from test_offline_factor_capture_verifier import build_capture

torch.set_num_threads(2)
root = Path(__file__).parent / "round1-production-artifacts"
root.mkdir(exist_ok=False)
house = root / "controlled-house"
_, provenance = build_capture(house)
(house / "capture.json").write_text(json.dumps(dict(provenance=provenance)))
_, scope = driver._public(house / "public", provenance)
inputs = driver.inventory(house)
weights_root = Path("/Users/pangwei/Documents/ai/continual-personalized-semantic-world-model/output/models/torchvision")
private = house / "unity-logs/evaluator_only"
sdk0 = driver._json(private / "sdk-events/004.json")
eligibility = [
    dict(
        house_index=1, split="train", object_id=obj["objectId"],
        object_type=obj["objectType"], asset_id=obj["assetId"],
        position_m=[obj["position"][key] for key in "xyz"],
        aabb_center_m=[obj["axisAlignedBoundingBox"]["center"][key] for key in "xyz"],
        eligible=obj["objectId"] != "floor",
        exclusion_reasons=["controlled_non_target"] if obj["objectId"] == "floor" else [],
    ) for obj in sdk0["metadata"]["objects"]
]

def run(kind, filename):
    started = time.monotonic()
    decoder = driver.make_decoder(weights_root / filename, kind, scope)
    predictions, binding = driver.predict_public_house(house, decoder)
    public = [driver.plain(dict(command=asdict(command), frame=asdict(frame), decoder_binding=binding)) for command, _, frame in predictions]
    rows = []
    for index, (command, delivery, frame) in enumerate(predictions, start=4):
        sdk = driver._json(private / f"sdk-events/{index:03d}.json")
        info = driver._json(private / f"instances/{index:03d}.json")
        for n, name in enumerate(("rgb", "depth")):
            assert (private / f"sdk-events/{index:03d}-{name}.npy").read_bytes() == delivery.observations[n].payload_bytes
        segmentation = np.load(private / f"instances/{index:03d}-segmentation.npy", allow_pickle=False)
        with np.load(private / f"instances/{index:03d}-masks.npz", allow_pickle=False) as masks:
            row = driver.evaluate_frame(command, delivery, frame, sdk, info, masks, segmentation, eligibility)
        row.update(house_index=1, split="train")
        rows.append(row)
    assert driver.inventory(house) == inputs
    documents = dict(public=public, report=dict(scope="CONTROLLED_EIGHT_VIEW_PRODUCTION_INFERENCE_RECHECK", frames=rows, summary=driver.summarize(rows), real_simulator_data_used=False), inputs=inputs)
    print(json.dumps(dict(detector=kind, frames=len(rows), candidates=sum(len(r["candidates"]) for r in rows), elapsed_seconds=round(time.monotonic()-started, 3), binding=binding)), flush=True)
    return documents

for kind, filename in (
    ("ssdlite", "ssdlite320_mobilenet_v3_large_coco-a79551df.pth"),
    ("fasterrcnn", "fasterrcnn_resnet50_fpn_v2_coco-dd69338a.pth"),
):
    first = run(kind, filename)
    output = root / kind
    driver.save_or_verify(output, first, verify=False)
    fresh = run(kind, filename)
    driver.save_or_verify(output, fresh, verify=True)
    print(json.dumps(dict(detector=kind, saved_reinference="accepted", original_sha256=driver.content_sha256(first), fresh_sha256=driver.content_sha256(fresh))), flush=True)

print(json.dumps(dict(complete=True, source_sha="3babc6d1557b4fe54abc6c8ac1f6054cdeb03e57", real_simulator_data_used=False)))
