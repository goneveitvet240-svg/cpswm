import json,hashlib,importlib.util
from pathlib import Path
import pytest
from cpswm.perception_mapping.interaction_evidence import fit_calibration,evaluate_calibration
p=Path('/private/tmp/cpswm-pc-a-person-evidence-20260914/tools/calibrate_interaction_scores.py')
spec=importlib.util.spec_from_file_location('review_cal',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def files(tmp_path):
    visual={'observation_id':'obs','model_id':'m','weights_sha256':'b'*64,'torch_version':'fixture','torchvision_version':'fixture','minimum_score':.1,'input_sha256':'a'*64,'candidates':[{'candidate_id':str(i),'detector_score':score} for i,score in enumerate([.1,.3,.6,.9,.95])]}
    result={'source_sha256':'c'*64,'records':[{'visual':visual}]}
    annotation={'source':'independent-math-fixture','annotator':'reviewer','items':[{'observation_id':'obs','candidate_id':str(i),'correct':i>=2} for i in range(4)]}
    rp=tmp_path/'result.json';ap=tmp_path/'annotation.json';rp.write_text(json.dumps(result));ap.write_text(json.dumps(annotation))
    return rp,ap,annotation

def test_unlabeled_not_negative_and_same_video_leakage(tmp_path):
    rp,ap,a=files(tmp_path);rows=m.load_examples(rp,ap,hashlib.sha256(ap.read_bytes()).hexdigest())
    assert len(rows)==4 and sum(x.label for x in rows)==2
    artifact=fit_calibration(rows)
    with pytest.raises(ValueError,match='leakage'):evaluate_calibration(artifact,rows)

@pytest.mark.parametrize('kind',['duplicate','unknown','truthy','digest'])
def test_annotation_rejections(tmp_path,kind):
    rp,ap,a=files(tmp_path)
    if kind=='duplicate':a['items'].append(a['items'][0])
    if kind=='unknown':a['items'][0]['candidate_id']='absent'
    if kind=='truthy':a['items'][0]['correct']=1
    ap.write_text(json.dumps(a));digest=hashlib.sha256(ap.read_bytes()).hexdigest()
    if kind=='digest':digest='0'*64
    with pytest.raises(ValueError):m.load_examples(rp,ap,digest)
