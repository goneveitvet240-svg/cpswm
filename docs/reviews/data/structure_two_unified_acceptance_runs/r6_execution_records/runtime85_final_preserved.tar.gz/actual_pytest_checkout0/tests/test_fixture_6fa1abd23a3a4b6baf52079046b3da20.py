def test_live():
 from cpswm import dependency_b683cd2c44ae4a6a8f6d604706ccbbf4
 assert dependency_b683cd2c44ae4a6a8f6d604706ccbbf4.VALUE == 9
