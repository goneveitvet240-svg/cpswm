from pathlib import Path
import json,subprocess,hashlib,sys
from cpswm.system.evaluation_operations.structure_two_evidence_versions import historical_entries,verify_historical_record,HISTORY_CONFIG
root=Path('/private/tmp/cpswm-ci-shallow-20260930');full=Path('/private/tmp/cpswm-pc-a-ci-failure-artifacts-20260930');out=Path(__file__).parent
mode=sys.argv[1]
def git(*args):return subprocess.run(['git',*args],cwd=root,text=True,capture_output=True)
head=git('rev-parse','HEAD').stdout.strip()
if mode=='before':
 paths=[HISTORY_CONFIG.as_posix()]+[e['path'] for e in historical_entries(full)]
 for n in paths:
  data=subprocess.check_output(['git','show','HEAD:'+n],cwd=root);p=root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
else:paths=list(json.loads((out/'shallow-before.json').read_text())['materialized_hashes'])
probe=git('show','91dbdc57968071be29976d1a7b99de51d9288cdd:'+HISTORY_CONFIG.as_posix())
result=dict(scope='PINNED_HISTORY_LOOKUP_IN_ISOLATED_LOCAL_CLONE',head=head,shallow=git('rev-parse','--is-shallow-repository').stdout.strip(),git_probe_exit=probe.returncode,git_probe_stderr=probe.stderr,materialized_hashes={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in paths})
try:
 entries=historical_entries(root);verified=[verify_historical_record(root,e) for e in entries];result.update(verified_records=len(verified),history_verified=True,records=verified)
except subprocess.CalledProcessError as e:result.update(history_verified=False,error=str(e))
if mode=='before':assert not result['history_verified'] and result['shallow']=='true' and probe.returncode!=0
else:
 old=json.loads((out/'shallow-before.json').read_text());assert result['head']==old['head'] and result['materialized_hashes']==old['materialized_hashes'];assert result['history_verified'] and result['verified_records']==11 and result['shallow']=='false'
(out/('shallow-'+mode+'.json')).write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k not in ('materialized_hashes','records')})
