def test_live():
 import dependency_0f3d5cf9d2f742fbafcf3ebef7c58609
 assert dependency_0f3d5cf9d2f742fbafcf3ebef7c58609.VALUE == 9
