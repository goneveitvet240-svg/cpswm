"""Rebind every public receipt and SDK owner, preserving the original external pin."""
import base64
import json
import os
import subprocess
import sys
import tempfile
from dataclasses import replace
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

import diagnose_offline_frontend as driver
from test_offline_frontend_diagnostic import complete_batch, decoder_factory_with_empty_first_house, seal, write_json
from cpswm.perception_mapping.unity_rgbd import observations_from_response
from cpswm.system.continuous_state_codec import StateCodec
from cpswm.system.structure_two_continuous_input import ObservationDelivery

OUT = Path(__file__).parent
EVIDENCE = OUT / 'round2-rebound-artifacts'
EVIDENCE.mkdir(exist_ok=False)
SOURCE = Path('/private/tmp/cpswm-pc-a-offline-front-end-20260930')
source_identity = driver.source_identity(SOURCE)
codec = StateCodec()
with tempfile.TemporaryDirectory(prefix='cpswm-r2-rebound-', dir='/private/tmp') as name:
    root = Path(name) / 'frontend-composed'
    root.mkdir()
    batch = complete_batch.__wrapped__(SimpleNamespace(mktemp=lambda name: root))
    (batch.source / 'tools/collect_offline_factor_data.py').write_bytes(
        (OUT / 'round2-controlled-artifacts/historical_sdk_standin.py').read_bytes())
    batch.config['source_files'] = driver.source_identity(batch.source)
    write_json(batch.directory / 'configuration.json', batch.config)
    original_pin = seal(batch.directory)
    original_inventory = driver.inventory(batch.directory)
    wrapper = OUT / 'round2-controlled-artifacts/controlled_cli_entry.py'
    output = EVIDENCE / 'original'
    def cli(case, destination, *, verify=False):
        command = [sys.executable, str(wrapper)]
        for key, value in dict(collection=batch.directory, capture_source=batch.source,
            archive=root/'unused-archive', sdk_python=root/'sdk-venv/bin/python', binary=root/'unused-Unity',
            weights=root/'unused-fixture-weights', output=destination, detector='ssdlite',
            inventory_sha256=original_pin).items():
            command.extend(['--'+key.replace('_','-'), str(value)])
        if verify:
            command.append('--verify')
        env = os.environ.copy()
        env['PYTHONPATH'] = os.pathsep.join(str(SOURCE/p) for p in ('src','tests','tools'))
        result = subprocess.run(command, cwd=SOURCE, env=env, capture_output=True, text=True, timeout=180)
        (EVIDENCE / (case+'.stdout.log')).write_text(result.stdout)
        (EVIDENCE / (case+'.stderr.log')).write_text(result.stderr)
        return command, result
    _, result = cli('baseline', output)
    assert result.returncode == 0, result.stderr
    print(json.dumps(dict(case='baseline_cli', result='accepted', frames=96)), flush=True)
    for index in range(1,13):
        house = batch.directory / f'house-{index:02d}'
        provenance = driver._json(house/'capture.json')['provenance']
        for offset in range(8):
            state = house/f'public/{offset:03d}-state.json'
            command, delivery = codec.loads(state.read_text())
            if index == 1 and offset == 0:
                (EVIDENCE/'original-state.json').write_bytes(state.read_bytes())
            action = uuid4()
            new_command = replace(command, action_id=action, snapshot_id=uuid4(),
                                  decision_time=command.decision_time+timedelta(days=3650))
            camera = json.loads(delivery.observations[2].payload_bytes)
            capture = delivery.observations[0].envelope().capture_time+timedelta(days=3650)
            arrival = delivery.received_at+timedelta(days=3650)
            fixed = ('schema_id','action_id','capture_time','rgb_sha256','depth_sha256',
                     'worker_sha256','unity_sha256','scene_sha256','configuration_sha256')
            for key in fixed:
                camera.pop(key)
            response = dict(action_id=str(action), capture_time=capture.isoformat(), success=True, error='',
                rgb_npy=base64.b64encode(delivery.observations[0].payload_bytes).decode(),
                depth_npy=base64.b64encode(delivery.observations[1].payload_bytes).decode(), camera=camera)
            identity = delivery.observations[0].envelope().identity
            rows = observations_from_response(response, action_id=action,
                scope=(identity.household_id,identity.session_id,identity.trace_id), arrival=arrival,
                provenance=provenance)
            state.write_text(codec.dumps((new_command, ObservationDelivery(action, rows, True, '', arrival))))
            private = house/'unity-logs/evaluator_only'
            event_path = private/f'sdk-events/{offset+4:03d}.json'
            info_path = private/f'instances/{offset+4:03d}.json'
            event, info = driver._json(event_path), driver._json(info_path)
            event['owner'] = info['action_id'] = str(action)
            write_json(event_path,event)
            write_json(info_path,info)
            if index == 1 and offset == 0:
                (EVIDENCE/'forged-state.json').write_bytes(state.read_bytes())
                write_json(EVIDENCE/'forged-sdk-event.json',event)
                write_json(EVIDENCE/'forged-instance-event.json',info)
    forged_pin = seal(batch.directory)
    assert forged_pin != original_pin
    events = []
    forged = driver.diagnose(batch.directory,
        decoder_factory=decoder_factory_with_empty_first_house(events),
        input_inventory=driver.inventory(batch.directory), capture_config=batch.config,
        detector_kind='ssdlite')
    assert len(events) == len(forged['public']) == len(forged['report']['frames']) == 96
    assert forged['report']['summary']['overall']['all_instances']['candidate_instance_pairs'] == 792
    forged_output = EVIDENCE/'forged-complete-result'
    driver.save_or_verify(forged_output, forged, verify=False)
    # This low-level derivation intentionally bypasses historical qualification to
    # demonstrate a complete internally coherent candidate, not its authority.
    command, result = cli('original_pin_rejects_rebound_matrix', forged_output, verify=True)
    assert result.returncode != 0 and 'collection external pin differs' in result.stderr, result.stderr
    assert 'R2_COUNTS={"evaluated": 0, "houses": 0, "inferred": 0}' in result.stdout
    write_json(EVIDENCE/'pins-and-result.json', dict(original_pin=original_pin, forged_pin=forged_pin,
        original_inventory=original_inventory, forged_inventory=driver.inventory(batch.directory),
        forged_public_frames=96, forged_sdk_owners=96, rebuilt_observations=288,
        public_transport_geometry_evaluation_passed=True, external_qualification_passed=False,
        command=command, returncode=result.returncode, source_sha='3babc6d1557b4fe54abc6c8ac1f6054cdeb03e57'))
    print(json.dumps(dict(case='all_96_receipts_and_sdk_owners_rebound', result='rejected_by_original_pin',
                         internally_coherent_frames=96, returncode=result.returncode)), flush=True)
assert driver.source_identity(SOURCE) == source_identity
print(json.dumps(dict(complete=True, source_unchanged=True, real_simulator_data_used=False)))
