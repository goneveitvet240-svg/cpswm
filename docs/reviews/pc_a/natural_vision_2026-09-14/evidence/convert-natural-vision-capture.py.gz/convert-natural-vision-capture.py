import hashlib,json
from pathlib import Path
from datetime import datetime,UTC
from uuid import NAMESPACE_URL,uuid5
from cpswm.perception_mapping.adapters.rgbd_capture import adapt_raw_rgbd_capture
root=Path('/private/tmp/cpswm-natural-vision-capture512-01')
out=Path('/private/tmp/cpswm-natural-vision-512-input');out.mkdir(exist_ok=False)
(out/'observations').mkdir()
capture=json.loads((root/'receipt.json').read_text())
assert capture['complete'] is True
scope=uuid5(NAMESPACE_URL,str(root))
entries=[];captures=[]
for row in capture['captures']:
    receipt=(root/'raw/observations'/row['file']).read_bytes()
    assert hashlib.sha256(receipt).hexdigest()==row['sha256']
    body=json.loads(receipt);sensor=(root/'raw/observations'/body['sensor_file']).read_bytes()
    now=datetime.now(UTC)
    observations=adapt_raw_rgbd_capture(receipt_bytes=receipt,sensor_bytes=sensor,
        expected_receipt_sha256=row['sha256'],expected_run_id=root.name,
        household_id=scope,session_id=scope,trace_id=scope,sensor_id='camera-512',
        frame_id='camera-optical',delivered_at=now,cutoff=now)
    for raw in observations:
        env=raw.envelope();oid=str(env.identity.observation_id)
        for suffix,data in (('.json',raw.envelope_json.encode()),('.npy',raw.payload_bytes)):
            filename='observations/'+oid+suffix
            (out/filename).write_bytes(data)
            entries.append({'file':filename,'size_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'capture_ref':row['file']})
    captures.append({'capture_ref':row['file'],'source_receipt_sha256':row['sha256']})
summary={'source_sha':'9d50afb79fdba2e854edddb2f5ec1179e071604c','output_manifest':entries,'captures':captures,
    'capture_manifest_sha256':hashlib.sha256((root/'receipt.json').read_bytes()).hexdigest(),
    'converter_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'new_simulator_run':True}
(out/'receipt.json').write_text(json.dumps(summary,indent=2)+'\n')
print(hashlib.sha256((out/'receipt.json').read_bytes()).hexdigest())
