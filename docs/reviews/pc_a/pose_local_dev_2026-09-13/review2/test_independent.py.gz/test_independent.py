from datetime import datetime, UTC, timezone, timedelta
from uuid import UUID
from zoneinfo import ZoneInfo
from dataclasses import replace
import math
import numpy as np
import pytest
from cpswm.system.structure_two_pose import PoseState, pose_residual, apply_pose_delta
from cpswm.system.structure_two_particle_workspace import ConditionalAnalyticState
from cpswm.system.structure_two_conditional_updates import ConditionalMeasurement, rebuild_conditional_state

def st(q=(0,0,0,1), xyz=(4,-2,8), time=None):
 return PoseState(object_instance_id=UUID(int=43),valid_at=time or datetime(2026,9,13,tzinfo=UTC),pose=dict(frame_id='registered-world',x=xyz[0],y=xyz[1],z=xyz[2],qx=q[0],qy=q[1],qz=q[2],qw=q[3]))
def qmat(q):
 x,y,z,w=q
 return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
def qarr(s):return [getattr(s.pose,k) for k in ('qx','qy','qz','qw')]
@pytest.mark.parametrize('seed',range(100))
def test_independent_rodrigues(seed):
 rng=np.random.default_rng(seed);q=rng.normal(size=4);q/=np.linalg.norm(q);ref=st(q)
 axis=rng.normal(size=3);axis/=np.linalg.norm(axis);theta=rng.uniform(0,math.pi-1e-10);r=theta*axis
 x,y,z=axis; K=np.array([[0,-z,y],[z,0,-x],[-y,x,0]])
 R=np.eye(3)+math.sin(theta)*K+(1-math.cos(theta))*(K@K)
 d=np.r_[rng.normal(size=3),r]; out=apply_pose_delta(ref,tuple(d))
 assert np.allclose(qmat(qarr(out)),qmat(q)@R,atol=1e-12)
 assert np.allclose(pose_residual(ref,out),d,atol=1e-12)
 assert np.allclose(pose_residual(st(-q),out),d,atol=1e-12)

def test_fold_and_same_instant():
 zone=ZoneInfo('America/New_York');t=datetime(2026,11,1,1,30,tzinfo=zone,fold=0)
 assert t==t.replace(fold=1)
 with pytest.raises(ValueError):pose_residual(st(time=t),st(time=t.replace(fold=1)))
 assert pose_residual(st(time=t),st(time=t.astimezone(timezone(timedelta(hours=9)))))==(0.,)*6
@pytest.mark.parametrize('bad', [float('nan'),float('inf'),1e308,-1e308,0.])
def test_mapping_and_forged_quat(bad):
 raw=st().model_dump();raw['pose'].update(qx=0,qy=0,qz=0,qw=bad)
 with pytest.raises(ValueError):PoseState.model_validate(raw)
 forged=st().model_copy(update={'pose':st().pose.model_copy(update={'qw':bad})})
 with pytest.raises(ValueError):apply_pose_delta(forged,(0,)*6)
@pytest.mark.parametrize('axis',[(1,0,0),(0,-1,0),(1/3,2/3,2/3)])
def test_cut_both_signs(axis):
 for sign in (-1,1):
  with pytest.raises(ValueError):pose_residual(st(),st(tuple(sign*x for x in axis)+(0,)))
  with pytest.raises(ValueError):apply_pose_delta(st(),(0,0,0)+tuple(sign*math.pi*x for x in axis))
@pytest.mark.parametrize('field,value',[('object_instance_id',UUID(int=99)),('valid_at',datetime(2026,9,14,tzinfo=UTC))])
def test_binding(field,value):
 with pytest.raises(ValueError):pose_residual(st(),st().model_copy(update={field:value}))
def test_frame():
 with pytest.raises(ValueError):pose_residual(st(),st().model_copy(update={'pose':st().pose.model_copy(update={'frame_id':'camera'})}))
@pytest.mark.parametrize('dims',[(1,6,3),(4,6,2),(7,2,5),(2,1,1)])
def test_rectangular_retract(dims):
 r,g,m=dims;rng=np.random.default_rng(sum(dims));H=rng.normal(size=(m,g));L=rng.normal(size=(m,m));R=L@L.T+np.eye(m);z=rng.normal(size=m);x=rng.normal(size=r)
 tup=lambda a:tuple(map(tuple,a))
 p=ConditionalAnalyticState((UUID(int=1),),(1.,),tup(np.eye(r)),(0.,)*r,tup(np.eye(g)),(0.,)*g)
 obs=ConditionalMeasurement(UUID(int=2),(UUID(int=3),),'independent-synthetic',(0.3,),tuple(x),2.,.8,tuple(z),tup(H),tup(R),.7)
 a=rebuild_conditional_state(p,(obs,));assert np.allclose(a.information,np.eye(g)+.7*H.T@np.linalg.inv(R)@H);assert np.allclose(a.information_vector,.7*H.T@np.linalg.inv(R)@z);assert np.allclose(a.a,np.eye(r)+.8*np.outer(x,x));assert np.allclose(a.b,1.6*x)
 other=replace(obs,evidence_cluster_id=UUID(int=4),measurement=tuple(-z));both=rebuild_conditional_state(p,(obs,other));assert np.allclose(both.information_vector,0)
 assert rebuild_conditional_state(p,(obs,))==a;assert rebuild_conditional_state(p,())==p
 with pytest.raises(ValueError):rebuild_conditional_state(p,(obs,obs))
