"""Map the 31 observed older CI failures to exact current terminal records."""
from pathlib import Path
from collections import Counter
import json, re

root = Path(__file__).parent
repository = Path('/private/tmp/cpswm-pc-a-current-validation-inputs-20261001')
old = json.loads((repository/'docs/reviews/pc_a/engineering_regressions_2026-10-01/evidence/failure-triage.json').read_text())
log = (root/'full-regression/execution/pytest.log').read_text()
outcomes = {}
for line in log.splitlines():
    match = re.match(r'^\[gw\d+\]\s+\[\s*\d+%\]\s+(PASSED|FAILED|ERROR|SKIPPED|XFAIL|XPASS)\s+(tests/.*)$',line)
    if match:
        outcomes.setdefault(match[2].strip(),[]).append(match[1])
collection = set(line.strip() for line in (root/'full-regression/collection.log').read_text().splitlines() if line.startswith('tests/') and '::' in line)
rows=[]
for original in old['rows']:
    previous=original['nodeid']; current=previous; reason='same collected node'
    if original['category']=='finite_log_contract':
        step=re.search(r'\[(\d+)-unresolved_underflow\]$',previous)[1]
        current=previous.split('::')[0]+'::test_finite_unresolved_underflow_retains_log_evidence_and_continues['+step+']'
        reason='Explicit finite-log positive contract replacement; original negative expectation is inapplicable'
    assert current in collection, current
    statuses=outcomes.get(current,[])
    status=statuses[0] if len(statuses)==1 else 'NOT_OBSERVED' if not statuses else 'AMBIGUOUS_MULTIPLE_RECORDS'
    rows.append(dict(old_nodeid=previous,current_nodeid=current,mapping=reason,category=original['category'],current_local_logged_status=status))
record=dict(scope='OLD_FAILURE_MAPPING_TO_LOCAL_LOG_NOT_LINUX_ACCEPTANCE',old_ci=old['ci_run'],
            current_functional_source='fd08b59bdc01ca9ffe4e9b159cb1393052711d15',
            counts=dict(Counter(row['current_local_logged_status'] for row in rows)),rows=rows,
            caveat='Use final JUnit reconciliation separately. Passing in this local run does not certify Linux or the new environment-contract branch; old CI timeout left additional nodes unobserved.')
(root/'prior-31-failures-current-outcomes.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record['counts']))
