def test_live():
 raise KeyboardInterrupt()
