def test_live():
 import dependency_ed89214bf5a14f21b7ece9d53130930b
 assert dependency_ed89214bf5a14f21b7ece9d53130930b.VALUE == 9
