def test_live():
 from cpswm import legal_bcd9703a81d94fae96e93ff4c1db13df
 assert legal_bcd9703a81d94fae96e93ff4c1db13df.VALUE == 7
