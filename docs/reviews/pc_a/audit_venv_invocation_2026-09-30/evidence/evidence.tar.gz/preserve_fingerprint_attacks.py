from pathlib import Path
import importlib.util,json,subprocess,copy,hashlib
root=Path('/private/tmp/cpswm-pc-a-audit-venv-invocation-20260930');out=Path(__file__).parent/'fingerprint-originals';out.mkdir(exist_ok=False)
def load(name,filename):
 s=importlib.util.spec_from_file_location(name,root/'apps/evaluation_runner'/filename);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=load('audit_actual','run_structure_two_engineering_audit_receipt.py');b=load('manifest_actual','generate_p0_checkpoint_manifest.py');p=root/'benchmarks/p0_checkpoint/content_manifest_v0_3.json';old=p.read_bytes();manifest=b.build_manifest(repository_root=root);fp=m.build_execution_environment_fingerprint(manifest);m.verify_execution_environment_fingerprint(fp,manifest)
(out/'current-manifest-component-input.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'legitimate-fingerprint.json').write_text(json.dumps(fp,indent=2)+'\n');results=[]
for attack in ('reported_version','invocation'):
 f=copy.deepcopy(fp);t=f['tools']['pytest']
 if attack=='reported_version':t['version']='pytest 0.0-forged';t['version_output_sha256']=hashlib.sha256(b'pytest 0.0-forged\n').hexdigest()
 else:t['invocation_executable']=t['resolved_executable'];t['version_argv'][0]=t['resolved_executable']
 f['content_sha256']=m._canonical_sha256({k:v for k,v in f.items() if k!='content_sha256'});path=out/(attack+'.json');path.write_text(json.dumps(f,indent=2)+'\n')
 try:m.verify_execution_environment_fingerprint(json.loads(path.read_text()),manifest)
 except ValueError as e:
  assert 'fingerprint is stale' in str(e);results.append(dict(attack=attack,status='REJECTED',error=str(e),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
 else:raise AssertionError('forged fingerprint accepted')
assert p.read_bytes()==old
result=dict(actual_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),legitimate_recompute='PASS',cases=results,stored_p0_unchanged=True,stored_p0_sha256=hashlib.sha256(old).hexdigest(),current_manifest_scope='COMPONENT_INPUT_ONLY_NOT_FROZEN_OR_ACCEPTED_CHECKPOINT')
(out/'matrix.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
