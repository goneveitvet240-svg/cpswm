import inspect
import types
from pathlib import Path
import pytest
import test_structure_two_formal_revision_lineage as old
from test_structure_two_w3_native_particles import candidates
from dual_pc_review.test_pc_b_b5_extended_state_machine import _reseal_stored_propensity
from cpswm.system import prototype_spine, structure_two_particle_workspace, structure_two_semantic_identity

ROOT = Path('/private/tmp/cpswm-pc-b-handoff-import-20260913')

def test_loaded_production_functions_equal_fresh_frozen_source():
    checked = 0
    for module in (prototype_spine, structure_two_particle_workspace, structure_two_semantic_identity):
        path = Path(module.__file__).resolve()
        assert path.is_relative_to(ROOT / 'src')
        compiled = compile(path.read_bytes(), str(path), 'exec', dont_inherit=True)
        codes = {}
        def walk(code):
            codes.setdefault(code.co_qualname, []).append(code)
            for child in code.co_consts:
                if isinstance(child, types.CodeType): walk(child)
        walk(compiled)
        for obj in vars(module).values():
            values = vars(obj).values() if inspect.isclass(obj) and obj.__module__ == module.__name__ else (obj,)
            for value in values:
                if isinstance(value, (staticmethod, classmethod)): value = value.__func__
                if isinstance(value, property): value = value.fget
                while inspect.isfunction(value) and value.__module__ == module.__name__:
                    if value.__code__.co_filename != str(path):
                        break  # dataclass-generated methods have no source-file code object
                    assert value.__code__ in codes[value.__code__.co_qualname]
                    checked += 1
                    value = getattr(value, '__wrapped__', None)
    assert checked > 100
    assert '/tools/' not in str(Path(pytest.__file__).resolve())
    print('fresh compiled loaded functions checked:', checked, 'pytest:', pytest.__file__)

def test_receiver_anchor_rollback_after_post_acceptance_failure(monkeypatch):
    core = old._legacy_history(1).system.core
    args = candidates(core)
    original = core._validate_particle_input_anchors
    def fail_after_acceptance():
        original()
        if core._particle_input_anchors:
            raise RuntimeError('receiver injected post-acceptance failure')
    monkeypatch.setattr(core, '_validate_particle_input_anchors', fail_after_acceptance)
    with pytest.raises(RuntimeError, match='receiver injected'):
        core.stage_prepared_particle_candidates(**args)
    assert core._particle_input_anchors == {}
    assert core._particle_workspace.input_journal == {}
    assert core._particle_workspace.records == {}
    monkeypatch.setattr(core, '_validate_particle_input_anchors', original)
    assert core.stage_prepared_particle_candidates(**args).particle_weights
    assert core.semantic_memory_identity()

def test_receiver_repeated_legal_reads_do_not_cache_away_later_reseal():
    core = old._legacy_history(1).system.core
    core.stage_prepared_particle_candidates(**candidates(core))
    for _ in range(3):
        assert core.prepared_particle_location_marginal()[1] > 0
        assert core.semantic_memory_identity()
    _reseal_stored_propensity(core)
    assert core._particle_workspace.state_payload()
    with pytest.raises(ValueError, match='acceptance binding anchors'):
        core.prepared_particle_location_marginal()
    with pytest.raises(ValueError, match='acceptance binding anchors'):
        core.semantic_memory_identity()
