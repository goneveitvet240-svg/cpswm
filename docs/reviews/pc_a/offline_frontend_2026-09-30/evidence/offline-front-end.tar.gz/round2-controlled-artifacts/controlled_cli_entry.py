import atexit, json
from dataclasses import replace
import diagnose_offline_frontend as driver
from test_owned_rgbd_support import RGBDSupportDecoder

counts = dict(houses=0, inferred=0, evaluated=0)
read_json, evaluate = driver._json, driver.evaluate_frame
def factory(weights, kind, scope):
    counts['houses'] += 1
    empty = counts['houses'] == 1
    class Fixture(RGBDSupportDecoder):
        def measurements(self, observations, *, cutoff):
            assert len(observations) == 3
            for raw in observations:
                e = raw.envelope()
                assert (e.identity.household_id, e.identity.session_id, e.identity.trace_id) == scope
            frames = super().measurements(observations, cutoff=cutoff)
            counts['inferred'] += 1
            return tuple(replace(f, candidates=()) for f in frames) if empty else frames
    return Fixture()
def check_read(path):
    if path.name == 'runtime-partition-audit.json' or 'evaluator_only' in path.parts:
        assert counts['inferred'] == 96
    return read_json(path)
def check_evaluate(*args, **kwargs):
    assert counts['inferred'] == 96
    result = evaluate(*args, **kwargs)
    counts['evaluated'] += 1
    return result
driver.make_decoder = factory
driver._json = check_read
driver.evaluate_frame = check_evaluate
atexit.register(lambda: print('R2_COUNTS=' + json.dumps(counts, sort_keys=True)))
driver.main()
