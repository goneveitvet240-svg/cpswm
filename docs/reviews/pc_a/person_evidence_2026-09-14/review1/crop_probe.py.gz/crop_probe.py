import subprocess,hashlib
p='/private/tmp/cpswm-hoh-public/01.mp4'
def decode(filter):
 return subprocess.check_output(['ffmpeg','-v','error','-ss','0','-i',p,'-frames:v','1','-vf',filter,'-f','rawvideo','-pix_fmt','rgb24','pipe:1'])
a=decode('crop=100:100:0:0'); b=decode('crop=100:100:1:0'); c=decode('crop=100:100:1:0:exact=1')
print('REQUESTED_X0_EQ_X1_WITH_CURRENT_FILTER',a==b)
print('REQUESTED_X1_DIFFERS_FROM_EXACT_X1',b!=c)
print('BYTE_LENGTHS',len(a),len(b),len(c))
print('SHA256',*[hashlib.sha256(x).hexdigest() for x in (a,b,c)])
assert a==b and b!=c
