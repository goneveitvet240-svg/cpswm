from pathlib import Path, PurePosixPath
import json,hashlib,tarfile,subprocess
root=Path('/private/tmp/cpswm-pc-a-camera-checkpoint-fixture-20260930');out=Path(__file__).parent
names=['rgbd_camera_geometry','owned_visual_neural','portable_checkpoints','ci_action_report','positive_call_observation','ci_failure_artifacts','ci_history','audit_venv_invocation','comparison_test_context','camera_checkpoint_fixture']
results=[]
for name in names:
 d=root/'docs/reviews/pc_a'/(name+'_2026-09-30')/'evidence';a=json.loads((d/'archive.json').read_text());i=json.loads((d/'inventory.json').read_text());rows=i if isinstance(i,dict) else {r['path']:r for r in i}; archives=list(d.glob('*.tar.gz'));assert len(archives)==1;p=archives[0]
 digest=hashlib.sha256(p.read_bytes()).hexdigest();assert digest==a.get('sha256',a.get('archive_sha256'))
 seen=set();total=0
 with tarfile.open(p,'r:gz') as t:
  for member in t:
   path=PurePosixPath(member.name);assert member.isfile() and not path.is_absolute() and '..' not in path.parts and member.name not in seen
   seen.add(member.name);assert member.name in rows
   b=t.extractfile(member).read();record=rows[member.name];assert len(b)==record['bytes'] and hashlib.sha256(b).hexdigest()==record['sha256'];total+=len(b)
 assert seen==set(rows) and len(seen)==a['files'] and total==a['raw_bytes']
 row={'phase':name,'files':len(seen),'raw_bytes':total,'archive_sha256':digest,'all_members_readback':True,'original_source_bindings':{k:v for k,v in a.items() if any(x in k for x in ['source','head','method','probe','review_sha'])}}
 results.append(row);print(name,len(seen),'verified',flush=True)
report={'delivery_tree_checked':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'phase_count':len(results),'member_count':sum(r['files'] for r in results),'raw_bytes':sum(r['raw_bytes'] for r in results),'phases':results,'not_independent_custody':True,'not_scientific_acceptance':True}
(out/'all-phase-archive-readback.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='phases'}),flush=True)
