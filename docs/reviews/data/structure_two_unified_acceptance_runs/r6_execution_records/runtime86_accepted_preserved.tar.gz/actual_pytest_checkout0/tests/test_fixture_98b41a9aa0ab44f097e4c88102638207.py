def test_live():
 from cpswm import read_race
 assert read_race.VALUE == 9
