def test_live():
 import cpswm
 assert cpswm.VALUE == 7
